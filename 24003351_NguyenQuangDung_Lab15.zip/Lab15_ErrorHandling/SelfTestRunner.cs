using System.Data.SqlClient;
using System.Diagnostics;
using System.IO.Compression;
using System.Text;
using Lab15.BUS;
using Lab15.DAL;

namespace Lab15_ErrorHandling;

internal static class SelfTestRunner
{
    private sealed record TestResult(string Id, string Name, bool Passed, string Detail, long ElapsedMs);

    public static int Run(string? outputFolder)
    {
        var results = new List<TestResult>();
        var service = new StudentService();
        var validator = new StudentValidator();
        var config = AppConfig.Current;
        SqlException? capturedSql = null;
        string? tempCode = null;

        void Add(string id, string name, Func<string> test)
        {
            var watch = Stopwatch.StartNew();
            try
            {
                var detail = test();
                watch.Stop();
                results.Add(new TestResult(id, name, true, detail, watch.ElapsedMilliseconds));
                AppLogger.Info($"[SELFTEST] {id} PASS – {name}", LogCategories.App, detail);
                Console.WriteLine($"[PASS] {id} ({watch.ElapsedMilliseconds} ms)");
            }
            catch (Exception ex)
            {
                watch.Stop();
                results.Add(new TestResult(id, name, false,
                    ex.GetType().Name + ": " + ex.Message, watch.ElapsedMilliseconds));
                AppLogger.Error($"[SELFTEST] {id} FAIL – {name}: {ex.Message}", LogCategories.App, ex);
                Console.WriteLine($"[FAIL] {id} ({watch.ElapsedMilliseconds} ms): {ex.GetType().Name}: {ex.Message}");
            }
        }

        AppLogger.Info("Bắt đầu bộ kiểm thử tự động Lab 15.", LogCategories.App,
            $"BaseDirectory={AppContext.BaseDirectory}");

        Add("CFG01", "Đọc cấu hình App.config và tạo thư mục", () =>
        {
            Require(File.Exists(config.ConfigFilePath), "Không tìm thấy App.config: " + config.ConfigFilePath);
            Require(!string.IsNullOrWhiteSpace(config.ReportFolder), "ReportFolder rỗng.");
            Require(!string.IsNullOrWhiteSpace(config.LogFolder), "LogFolder rỗng.");
            Directory.CreateDirectory(config.ReportFolder);
            Directory.CreateDirectory(config.LogFolder);
            return $"Config={config.ConfigFilePath}; Reports={config.ReportFolder}; Logs={config.LogFolder}; " +
                   $"LogLevel={config.LogLevelText}; MaxKB={config.LogMaxSizeKB}";
        });

        Add("VAL01", "Kiểm tra dữ liệu trả về nhiều lỗi cùng lúc", () =>
        {
            var input = new StudentInput
            {
                MaSV = "SV@",
                HoTen = "12345",
                NgaySinh = "31/02/2020",
                MaKhoa = "",
                DiemTB = "12,5",
                Email = "email-sai",
                IsActive = true
            };
            var result = validator.Validate(input);
            Require(result.ErrorCount >= 5,
                $"Chỉ phát hiện {result.ErrorCount} lỗi, cần ít nhất 5. {result.Summary}");
            foreach (var field in new[] { "MaSV", "HoTen", "NgaySinh", "MaKhoa", "DiemTB", "Email" })
                Require(result[field] != null, "Thiếu lỗi ở trường " + field + ".");
            return $"{result.ErrorCount} lỗi: " + string.Join(" | ", result.Errors.Keys);
        });

        Add("VAL02", "Kiểm tra trùng mã sinh viên trong CSDL", () =>
        {
            var faculties = service.GetFaculties();
            Require(faculties.Count > 0, "Không có khoa nào trong CSDL.");
            var input = new StudentInput
            {
                MaSV = "SV001",
                HoTen = "Sinh viên kiểm thử trùng mã",
                NgaySinh = "20/05/2004",
                MaKhoa = faculties[0].MaKhoa,
                DiemTB = "8.0",
                Email = "",
                IsActive = true
            };
            var result = service.Validate(input, checkDatabase: true);
            Require(result["MaSV"] != null, "Không phát hiện mã SV001 bị trùng.");
            return "Đã phát hiện: " + result["MaSV"];
        });

        Add("CRUD01", "Thêm, sửa, đổi trạng thái và xóa sinh viên tạm", () =>
        {
            var faculties = service.GetFaculties();
            Require(faculties.Count > 0, "Không có khoa nào trong CSDL.");

            var repository = new SinhVienRepository();
            tempCode = "ZZT" + DateTime.Now.ToString("HHmmss");
            if (repository.ExistsCode(tempCode)) repository.HardDeleteForTest(tempCode);
            var email = $"zzt.{DateTime.Now:HHmmss}.{Environment.ProcessId}@eaut.edu.vn";
            var faculty = faculties[0].MaKhoa;

            try
            {
                service.Create(new StudentInput
                {
                    MaSV = tempCode,
                    HoTen = "Sinh viên kiểm thử Lab15",
                    NgaySinh = "20/05/2004",
                    GioiTinh = true,
                    MaKhoa = faculty,
                    DiemTB = "8,5",
                    Email = email,
                    IsActive = true
                });

                var created = service.GetByCode(tempCode);
                Require(created != null, "Không đọc lại được sinh viên vừa thêm.");
                Require(created!.HoTen == "Sinh viên kiểm thử Lab15", "Họ tên không khớp sau khi thêm.");
                Require(created.DiemTB == 8.5m, "Điểm trung bình không khớp sau khi thêm.");

                service.Update(new StudentInput
                {
                    MaSV = tempCode,
                    HoTen = "Sinh viên kiểm thử (đã sửa)",
                    NgaySinh = "21/05/2004",
                    GioiTinh = false,
                    MaKhoa = faculty,
                    DiemTB = "9.25",
                    Email = email,
                    IsActive = true
                });

                var updated = service.GetByCode(tempCode);
                Require(updated != null && updated.HoTen.EndsWith("(đã sửa)"), "Cập nhật họ tên thất bại.");
                Require(updated!.DiemTB == 9.25m, "Cập nhật điểm thất bại.");

                service.SetActive(tempCode, false);
                var inactive = service.GetByCode(tempCode);
                Require(inactive != null && !inactive.IsActive, "Đổi trạng thái ngừng học thất bại.");

                service.Delete(tempCode);
                Require(service.GetByCode(tempCode) == null, "Sinh viên tạm vẫn còn sau khi xóa.");
                tempCode = null;
                return "Thêm → đọc → sửa → ngừng học → xóa thành công; đã dọn dữ liệu tạm.";
            }
            finally
            {
                try
                {
                    if (tempCode != null && repository.ExistsCode(tempCode))
                        repository.HardDeleteForTest(tempCode);
                }
                catch
                {
                    // Bỏ qua lỗi dọn dẹp.
                }
            }
        });

        Add("BIZ01", "BusinessException khi xóa sinh viên còn đăng ký", () =>
        {
            var registrations = service.CountRegistrations("SV001");
            Require(registrations > 0, "SV001 không có đăng ký nên không minh họa được quy tắc.");
            try
            {
                service.Delete("SV001");
                throw new InvalidOperationException("Đáng lẽ phải ném BusinessException.");
            }
            catch (BusinessException ex)
            {
                Require(ex.Code == "SV_HAS_REGISTRATION", "Mã lỗi không đúng: " + ex.Code);
                Require(!string.IsNullOrWhiteSpace(ex.Hint), "BusinessException thiếu gợi ý xử lý.");
                return $"Code={ex.Code}; Đăng ký={registrations}; Message={ex.Message}";
            }
        });

        Add("SQL01", "SqlException 547 khi xóa trực tiếp vi phạm khóa ngoại", () =>
        {
            try
            {
                service.DeleteUnsafeForDemo("SV001");
                throw new InvalidOperationException("Đáng lẽ CSDL phải từ chối xóa.");
            }
            catch (SqlException ex)
            {
                capturedSql = ex;
                Require(ex.Number == 547, "Mã lỗi SQL mong đợi 547, nhận được " + ex.Number);
                return $"SqlNumber={ex.Number}; Class={ex.Class}; {FirstLine(ex.Message)}";
            }
        });

        Add("SQL02", "SqlException 208 khi truy vấn bảng không tồn tại", () =>
        {
            try
            {
                service.TriggerDatabaseError();
                throw new InvalidOperationException("Đáng lẽ phải có SqlException.");
            }
            catch (SqlException ex)
            {
                capturedSql ??= ex;
                Require(ex.Number == 208, "Mã lỗi SQL mong đợi 208, nhận được " + ex.Number);
                return $"SqlNumber={ex.Number}; {FirstLine(ex.Message)}";
            }
        });

        Add("LOG01", "Ghi nhật ký có cấu trúc vào tệp", () =>
        {
            var marker = "SELFTEST-LOG-" + Guid.NewGuid().ToString("N")[..8];
            AppLogger.Info(marker, LogCategories.App, "Key=Value; Purpose=SelfTest");
            AppLogger.Warn(marker + "-WARN", LogCategories.Validation);
            Require(File.Exists(AppLogger.CurrentFile), "Tệp nhật ký chưa được tạo.");
            var text = File.ReadAllText(AppLogger.CurrentFile, Encoding.UTF8);
            Require(text.Contains(marker), "Không tìm thấy dấu kiểm thử trong tệp nhật ký.");
            Require(AppLogger.GetRecent(10).Count > 0, "Bộ đệm nhật ký gần đây rỗng.");
            return $"Tệp={AppLogger.CurrentFile}; Kích thước={new FileInfo(AppLogger.CurrentFile).Length} byte";
        });

        Add("LOG02", "Xoay vòng nhật ký theo dung lượng", () =>
        {
            var before = AppLogger.GetLogFiles().Count(p => Path.GetFileName(p).StartsWith("lab15-"));
            AppLogger.Configure(config.LogFolder, 16, config.LogRetentionDays, LogLevel.Debug);
            try
            {
                var payload = new string('x', 320);
                for (var i = 0; i < 90; i++)
                    AppLogger.Debug($"Rotation test #{i}: {payload}", "RotationTest");
            }
            finally
            {
                AppLogger.Configure(config);
            }

            var after = AppLogger.GetLogFiles().Count(p => Path.GetFileName(p).StartsWith("lab15-"));
            Require(after > before, $"Không tạo tệp xoay vòng (trước={before}, sau={after}).");
            var cleaned = AppLogger.CleanupOldFiles();
            AppLogger.Info("Đã khôi phục cấu hình logger sau kiểm thử xoay vòng.", LogCategories.App);
            return $"Tệp lưu trữ trước={before}, sau={after}; đã dọn {cleaned} tệp cũ.";
        });

        Add("SEC01", "Mã hóa và giải mã chuỗi kết nối bằng DPAPI", () =>
        {
            var path = ConnectionStringProtector.ProtectedFilePath;
            string? backup = File.Exists(path) ? File.ReadAllText(path, Encoding.UTF8) : null;
            try
            {
                var original = config.GetConnectionString();
                var written = ConnectionStringProtector.Protect(original);
                Require(File.Exists(written), "Không tạo được tệp bảo vệ.");
                var decoded = ConnectionStringProtector.TryReadProtected();
                Require(decoded == original, "Chuỗi kết nối giải mã không khớp.");
                ConnectionStringProtector.RemoveProtection();
                Require(!File.Exists(path), "Tệp bảo vệ vẫn còn sau khi gỡ.");
                return "Protect → Unprotect → so sánh thành công; đã gỡ tệp thử nghiệm.";
            }
            finally
            {
                if (backup != null)
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(path)!);
                    File.WriteAllText(path, backup, new UTF8Encoding(false));
                }
                else if (File.Exists(path))
                {
                    File.Delete(path);
                }
            }
        });

        Add("EXP01", "Xuất CSV và XLSX vào thư mục Reports", () =>
        {
            var students = service.Search(null, null, true).Take(6).ToList();
            Require(students.Count > 0, "Không có dữ liệu để xuất.");
            var csvPath = StudentExportService.BuildFilePath(config.ReportFolder, "KiemThu_DanhSachSinhVien", "csv");
            var xlsxPath = StudentExportService.BuildFilePath(config.ReportFolder, "KiemThu_DanhSachSinhVien", "xlsx");
            StudentExportService.ExportStudentsCsv(students, csvPath);
            StudentExportService.ExportStudentsXlsx(students, xlsxPath);
            Require(File.Exists(csvPath) && new FileInfo(csvPath).Length > 100, "Tệp CSV không hợp lệ.");
            Require(File.Exists(xlsxPath) && new FileInfo(xlsxPath).Length > 500, "Tệp XLSX quá nhỏ.");

            using var zip = ZipFile.OpenRead(xlsxPath);
            Require(zip.Entries.Any(e => e.FullName == "xl/worksheets/sheet1.xml"), "XLSX thiếu sheet1.xml.");
            Require(zip.Entries.Any(e => e.FullName == "xl/workbook.xml"), "XLSX thiếu workbook.xml.");
            return "CSV=" + csvPath + "; XLSX=" + xlsxPath;
        });

        Add("PRE01", "Màn hình kiểm tra trước khi chạy", () =>
        {
            var report = new PreflightService(config).RunAll();
            Require(report.Checks.Count >= 8, "Số hạng mục kiểm tra quá ít: " + report.Checks.Count);
            Require(report.Checks.Any(c => c.Name == "Tệp cấu hình" && c.Status == CheckStatus.Pass),
                "Không đọc được tệp cấu hình.");
            var database = report.Checks.FirstOrDefault(c => c.Name == "Kết nối SQL Server");
            Require(database is { Status: CheckStatus.Pass },
                "Không kết nối được CSDL: " + database?.Message);

            var path = StudentExportService.ExportTextReport(report.ToText(),
                Path.Combine(config.ReportFolder, "KiemThu_KiemTraTruocKhiChay.txt"));
            return $"{report.OverallText}; đạt={report.PassCount}; cảnh báo={report.WarningCount}; " +
                   $"lỗi={report.FailCount}; báo cáo={path}";
        });

        Add("ERR01", "Phân loại BusinessException / SqlException / Exception", () =>
        {
            var business = new BusinessException("TEST", "Lỗi nghiệp vụ kiểm thử.", hint: "Không có.");
            Require(ErrorPresenter.Classify(business).StartsWith("BusinessException"), "Phân loại BusinessException sai.");
            Require(ErrorPresenter.KindOf(business) == ErrorKind.Business, "KindOf BusinessException sai.");
            Require(ErrorPresenter.Describe(business).Contains("Mã lỗi"), "Mô tả BusinessException thiếu mã lỗi.");

            Require(capturedSql != null, "Chưa có SqlException từ kiểm thử SQL01/SQL02.");
            Require(ErrorPresenter.Classify(capturedSql!).StartsWith("SqlException"), "Phân loại SqlException sai.");

            var general = new InvalidOperationException("Lỗi hệ thống kiểm thử.");
            Require(ErrorPresenter.Classify(general) == "Exception", "Phân loại Exception sai.");
            return "BusinessException → Business; SqlException → Database; Exception → Unexpected.";
        });

        Add("DEP01", "Sinh biên bản kiểm thử triển khai", () =>
        {
            var report = new PreflightService(config).RunAll();
            var snapshot = DeploymentService.Capture(config);
            var checklist = DeploymentService.BuildChecklist(report);
            var text = DeploymentService.BuildReportText(snapshot, report, checklist);
            Require(text.Contains("BIÊN BẢN KIỂM THỬ TRIỂN KHAI"), "Biên bản thiếu tiêu đề.");
            Require(text.Contains("Nguyễn Quang Dũng"), "Biên bản thiếu tên sinh viên.");
            Require(checklist.Count >= 10, "Danh mục kiểm thử triển khai quá ít.");
            var path = DeploymentService.WriteReport(config.ReportFolder, config, report);
            Require(File.Exists(path), "Không ghi được biên bản triển khai.");
            return $"{checklist.Count} hạng mục; biên bản={path}";
        });

        AppLogger.Configure(config);
        var passed = results.Count(r => r.Passed);
        var total = results.Count;
        var reportFolder = string.IsNullOrWhiteSpace(outputFolder)
            ? config.ReportFolder
            : Path.GetFullPath(outputFolder);
        Directory.CreateDirectory(reportFolder);
        var reportPath = Path.Combine(reportFolder, "KetQuaKiemThuTuDong.txt");

        var builder = new StringBuilder();
        builder.AppendLine("KẾT QUẢ KIỂM THỬ TỰ ĐỘNG – LAB 15");
        builder.AppendLine("Học phần: Lập trình .NET (IT3212)");
        builder.AppendLine("Sinh viên: Nguyễn Quang Dũng – MSSV 24003351");
        builder.AppendLine("Thời điểm: " + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
        builder.AppendLine("Máy: " + Environment.MachineName + " · Tài khoản: " + Environment.UserName);
        builder.AppendLine("Nền tảng: " + System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription);
        builder.AppendLine("Thư mục chạy: " + AppContext.BaseDirectory);
        builder.AppendLine("Tệp cấu hình: " + config.ConfigFilePath);
        builder.AppendLine(new string('=', 110));
        builder.AppendLine($"{"Mã",-8} {"Kết quả",-8} {"Thời gian",-10} Hạng mục");
        builder.AppendLine(new string('-', 110));
        foreach (var result in results)
        {
            builder.AppendLine($"{result.Id,-8} {(result.Passed ? "PASS" : "FAIL"),-8} {result.ElapsedMs + " ms",-10} {result.Name}");
            builder.AppendLine("         " + result.Detail);
        }
        builder.AppendLine(new string('=', 110));
        builder.AppendLine($"TỔNG KẾT: {passed}/{total} kiểm thử đạt.");
        builder.AppendLine(passed == total ? "KẾT LUẬN: TẤT CẢ KIỂM THỬ ĐỀU ĐẠT." : "KẾT LUẬN: CÒN KIỂM THỬ CHƯA ĐẠT.");
        builder.AppendLine();
        builder.AppendLine("Ghi chú: bộ kiểm thử dùng dữ liệu tạm mã ZZT…, tự dọn sau khi chạy; " +
                           "không thay đổi dữ liệu sinh viên hiện có.");
        StudentExportService.ExportTextReport(builder.ToString(), reportPath);

        Console.WriteLine();
        Console.WriteLine($"RESULT: {passed}/{total} passed");
        Console.WriteLine("REPORT: " + reportPath);
        return passed == total ? 0 : 1;
    }

    private static void Require(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }

    private static string FirstLine(string text)
    {
        var line = (text ?? "").Replace("\r", "").Split('\n').FirstOrDefault()?.Trim() ?? "";
        return line.Length > 220 ? line[..220] + "…" : line;
    }
}
