using System.Diagnostics;
using Lab15.BUS;

namespace Lab15_ErrorHandling;

public partial class MainForm
{
    private DataGridView _logGrid = null!;
    private ComboBox _cboLogLevel = null!;
    private Label _lblLogInfo = null!;
    private RichTextBox _richLogDetail = null!;
    private List<LogEntry> _logEntries = new();

    private void BuildLogTab()
    {
        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 2,
            BackColor = UiTheme.Background,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 46));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        root.Controls.Add(BuildLogToolbar(), 0, 0);

        var content = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 2,
            BackColor = UiTheme.Background,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };
        content.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        content.RowStyles.Add(new RowStyle(SizeType.Absolute, 190));

        var gridCard = UiTheme.Card(10);
        gridCard.Dock = DockStyle.Fill;
        gridCard.Margin = new Padding(0, 0, 0, 10);
        gridCard.Padding = new Padding(10);

        _logGrid = new DataGridView { Dock = DockStyle.Fill };
        UiTheme.StyleGrid(_logGrid);
        _logGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        _logGrid.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = "ThoiGian", HeaderText = "Thời gian", FillWeight = 90, MinimumWidth = 90,
            ReadOnly = true, SortMode = DataGridViewColumnSortMode.NotSortable
        });
        _logGrid.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = "Muc", HeaderText = "Mức", FillWeight = 50, MinimumWidth = 55,
            ReadOnly = true, SortMode = DataGridViewColumnSortMode.NotSortable
        });
        _logGrid.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = "Nhom", HeaderText = "Nhóm", FillWeight = 80, MinimumWidth = 90,
            ReadOnly = true, SortMode = DataGridViewColumnSortMode.NotSortable
        });
        _logGrid.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = "ThongDiep", HeaderText = "Thông điệp",
            FillWeight = 400, MinimumWidth = 200, ReadOnly = true,
            SortMode = DataGridViewColumnSortMode.NotSortable
        });
        _logGrid.SelectionChanged += (_, _) => ShowLogDetail();
        gridCard.Controls.Add(_logGrid);

        var detailCard = UiTheme.Card(10);
        detailCard.Dock = DockStyle.Fill;
        detailCard.Padding = new Padding(10);
        var detailLayout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 2,
            BackColor = UiTheme.Surface,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };
        detailLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 24));
        detailLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        var detailTitle = UiTheme.Label("Chi tiết bản ghi (detail / exception)", UiTheme.SmallBold, UiTheme.Muted);
        _richLogDetail = new RichTextBox
        {
            Dock = DockStyle.Fill,
            ReadOnly = true,
            BorderStyle = BorderStyle.None,
            BackColor = Color.FromArgb(248, 250, 252),
            ForeColor = Color.FromArgb(30, 41, 59),
            Font = UiTheme.Mono,
            WordWrap = true,
            DetectUrls = false
        };
        detailLayout.Controls.Add(detailTitle, 0, 0);
        detailLayout.Controls.Add(_richLogDetail, 0, 1);
        detailCard.Controls.Add(detailLayout);

        content.Controls.Add(gridCard, 0, 0);
        content.Controls.Add(detailCard, 0, 1);
        root.Controls.Add(content, 0, 1);
        _tabLogs.Controls.Add(root);

        RefreshLogs();
    }

    private Control BuildLogToolbar()
    {
        var toolbar = new Panel
        {
            Dock = DockStyle.Fill,
            BackColor = UiTheme.Background,
            Padding = new Padding(0, 8, 0, 4)
        };
        var flow = new FlowLayoutPanel
        {
            Dock = DockStyle.Left,
            AutoSize = true,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false,
            BackColor = Color.Transparent,
            Padding = new Padding(0),
            Margin = new Padding(0)
        };

        var levelLabel = UiTheme.Label("Mức log", UiTheme.SmallBold, UiTheme.Muted);
        levelLabel.Margin = new Padding(0, 9, 8, 0);
        _cboLogLevel = UiTheme.ComboBox();
        _cboLogLevel.Width = 120;
        _cboLogLevel.Margin = new Padding(0, 3, 12, 0);
        _cboLogLevel.Items.AddRange(new object[] { "Tất cả", "DEBUG", "INFO", "WARN", "ERROR", "FATAL" });
        _cboLogLevel.SelectedIndex = 0;
        _cboLogLevel.SelectedIndexChanged += (_, _) => RefreshLogs();

        var btnRefresh = UiTheme.Button("Làm mới", UiTheme.Accent, Color.White, (_, _) => RefreshLogs());
        btnRefresh.Margin = new Padding(0, 2, 6, 0);
        var btnFolder = UiTheme.Button("Mở thư mục Logs", null, null, (_, _) => OpenLogFolder());
        btnFolder.Margin = new Padding(0, 2, 6, 0);
        var btnRotate = UiTheme.Button("Xoay vòng ngay", null, null, (_, _) => RotateLog());
        btnRotate.Margin = new Padding(0, 2, 6, 0);
        var btnExport = UiTheme.Button("Xuất CSV", null, null, (_, _) => ExportLogCsv());
        btnExport.Margin = new Padding(0, 2, 6, 0);

        flow.Controls.AddRange(new Control[]
        {
            levelLabel, _cboLogLevel, btnRefresh, btnFolder, btnRotate, btnExport
        });

        _lblLogInfo = new Label
        {
            Dock = DockStyle.Right,
            Width = 420,
            TextAlign = ContentAlignment.MiddleRight,
            Font = UiTheme.Small,
            ForeColor = UiTheme.Muted,
            Padding = new Padding(0, 7, 2, 0)
        };

        toolbar.Controls.Add(flow);
        toolbar.Controls.Add(_lblLogInfo);
        return toolbar;
    }

    public void RefreshLogs()
    {
        if (_logGrid == null) return;

        var selectedLevel = _cboLogLevel.SelectedItem?.ToString() ?? "Tất cả";
        var all = AppLogger.GetRecent(800);
        _logEntries = selectedLevel == "Tất cả"
            ? all.ToList()
            : all.Where(e => string.Equals(e.LevelText, selectedLevel, StringComparison.OrdinalIgnoreCase)).ToList();

        var selectedIndex = _logGrid.CurrentRow?.Index ?? -1;
        _logGrid.Rows.Clear();
        foreach (var entry in _logEntries)
        {
            var index = _logGrid.Rows.Add(
                entry.Timestamp.ToString("dd/MM HH:mm:ss.fff"),
                entry.LevelText,
                entry.Category,
                entry.Message);

            var row = _logGrid.Rows[index];
            switch (entry.Level)
            {
                case LogLevel.Error:
                case LogLevel.Fatal:
                    row.DefaultCellStyle.ForeColor = UiTheme.Danger;
                    row.DefaultCellStyle.BackColor = UiTheme.DangerSoft;
                    break;
                case LogLevel.Warn:
                    row.DefaultCellStyle.ForeColor = UiTheme.Warning;
                    row.DefaultCellStyle.BackColor = UiTheme.WarningSoft;
                    break;
                case LogLevel.Debug:
                    row.DefaultCellStyle.ForeColor = UiTheme.Muted;
                    break;
            }
        }

        if (selectedIndex >= 0 && selectedIndex < _logGrid.Rows.Count)
            _logGrid.CurrentCell = _logGrid.Rows[selectedIndex].Cells[0];

        var fileInfo = "";
        try
        {
            if (File.Exists(AppLogger.CurrentFile))
            {
                var length = new FileInfo(AppLogger.CurrentFile).Length;
                fileInfo = $" · tệp hiện tại {length / 1024.0:0.0} KB";
            }
            else
            {
                fileInfo = " · tệp hiện tại chưa có";
            }
        }
        catch
        {
            // Bỏ qua.
        }

        _lblLogInfo.Text = $"{_logEntries.Count} bản ghi (tối đa 800) · {Path.GetFileName(AppLogger.CurrentFile)}{fileInfo}";
        if (_logEntries.Count > 0) ShowLogDetail();
        else
        {
            _richLogDetail.Text = "Chưa có bản ghi phù hợp bộ lọc.\n" +
                                  "Thực hiện thao tác trên ứng dụng hoặc dùng tab Kiểm thử lỗi để tạo log.";
        }
    }

    private void ShowLogDetail()
    {
        if (_logGrid.CurrentRow == null) return;
        var index = _logGrid.CurrentRow.Index;
        if (index < 0 || index >= _logEntries.Count) return;
        var entry = _logEntries[index];

        _richLogDetail.Text =
            $"Thời gian : {entry.Timestamp:dd/MM/yyyy HH:mm:ss.fff}" + Environment.NewLine +
            $"Mức       : {entry.LevelText}" + Environment.NewLine +
            $"Nhóm      : {entry.Category}" + Environment.NewLine +
            $"Thông điệp: {entry.Message}" + Environment.NewLine +
            (string.IsNullOrWhiteSpace(entry.Detail) ? "" : "Chi tiết  : " + entry.Detail + Environment.NewLine) +
            (string.IsNullOrWhiteSpace(entry.ExceptionText)
                ? ""
                : Environment.NewLine + "Ngoại lệ:" + Environment.NewLine + entry.ExceptionText);
    }

    private void OpenLogFolder()
    {
        try
        {
            Directory.CreateDirectory(AppLogger.DirectoryPath);
            Process.Start(new ProcessStartInfo
            {
                FileName = AppLogger.DirectoryPath,
                UseShellExecute = true
            });
        }
        catch (Exception ex)
        {
            ErrorPresenter.Show(this, ex, "Mở thư mục nhật ký", _silent);
        }
    }

    private void RotateLog()
    {
        try
        {
            var archive = AppLogger.RotateNow();
            RefreshLogs();
            if (string.IsNullOrWhiteSpace(archive))
                ShowInfo("Tệp nhật ký đang trống nên chưa cần xoay vòng.", "Xoay vòng nhật ký");
            else
                ShowInfo("Đã xoay vòng nhật ký sang tệp:\n" + archive, "Xoay vòng nhật ký");
        }
        catch (Exception ex)
        {
            ErrorPresenter.Show(this, ex, "Xoay vòng nhật ký", _silent);
        }
    }

    private void ExportLogCsv()
    {
        try
        {
            var path = StudentExportService.BuildFilePath(_config.ReportFolder, "NhatKy", "csv");
            StudentExportService.ExportLogsCsv(_logEntries, path);
            ShowInfo($"Đã xuất {_logEntries.Count} bản ghi nhật ký ra:\n{path}", "Xuất nhật ký");
        }
        catch (Exception ex)
        {
            ErrorPresenter.Show(this, ex, "Xuất nhật ký", _silent);
        }
    }
}
