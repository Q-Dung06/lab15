using System.Drawing.Imaging;
using Lab15.BUS;

namespace Lab15_ErrorHandling;

public partial class MainForm : Form
{
    private AppConfig _config;
    private readonly StudentService _studentService = new();
    private readonly bool _silent;

    private TabControl _tabs = null!;
    private TabPage _tabStudents = null!;
    private TabPage _tabErrorLab = null!;
    private TabPage _tabLogs = null!;
    private TabPage _tabSettings = null!;
    private TabPage _tabPreflight = null!;
    private TabPage _tabDeployment = null!;
    private Label _statusMain = null!;
    private Label _statusRight = null!;
    private Panel _statusPanel = null!;
    private System.Windows.Forms.Timer _logTimer = null!;

    public MainForm(bool silent = false)
    {
        _silent = silent;
        _config = AppConfig.Current;

        Text = "Lab 15 – Xử lý lỗi nâng cao, logging, cấu hình và đóng gói";
        StartPosition = FormStartPosition.CenterScreen;
        var workingArea = Screen.PrimaryScreen?.WorkingArea ?? new Rectangle(0, 0, 1360, 860);
        var initialWidth = Math.Min(1420, Math.Max(1180, workingArea.Width - 24));
        var initialHeight = Math.Min(880, Math.Max(690, workingArea.Height - 44));
        ClientSize = new Size(initialWidth, initialHeight);
        MinimumSize = new Size(1180, 690);
        BackColor = UiTheme.Background;
        Font = UiTheme.Body;
        AutoScaleMode = AutoScaleMode.None;
        KeyPreview = true;

        BuildShell();
        BuildStudentTab();
        BuildErrorLabTab();
        BuildLogTab();
        BuildSettingsTab();
        BuildPreflightTab();
        BuildDeploymentTab();

        _tabs.SelectedIndex = 0;
        Shown += OnFormShown;
        FormClosing += (_, _) => AppLogger.Info("Đóng ứng dụng.", LogCategories.App);
    }

    public bool SilentMode => _silent;

    private void BuildShell()
    {
        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 4,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 82));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 4));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 26));

        var header = new Panel { Dock = DockStyle.Fill, BackColor = UiTheme.Header, Padding = new Padding(24, 7, 24, 6) };
        var headerLayout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 1,
            BackColor = Color.Transparent,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };
        headerLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        headerLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 350));

        var titlePanel = new Panel { Dock = DockStyle.Fill, BackColor = Color.Transparent };
        var title = UiTheme.Label("LAB 15 · XỬ LÝ LỖI NÂNG CAO, LOGGING & ĐÓNG GÓI",
            new Font("Segoe UI", 15.5f, FontStyle.Bold), Color.White);
        title.Location = new Point(0, 0);
        var subtitle = UiTheme.Label("Lập trình .NET (IT3212) · Kiểm soát lỗi theo tầng · Nhật ký có cấu trúc · Cấu hình & triển khai",
            new Font("Segoe UI", 8.5f), Color.FromArgb(191, 219, 254));
        subtitle.Location = new Point(2, 28);
        var student = UiTheme.Label("Sinh viên: Nguyễn Quang Dũng · MSSV 24003351", new Font("Segoe UI", 8f), Color.FromArgb(148, 187, 233));
        student.Location = new Point(2, 47);
        titlePanel.Controls.Add(title);
        titlePanel.Controls.Add(subtitle);
        titlePanel.Controls.Add(student);

        var badgePanel = new Panel { Dock = DockStyle.Fill, BackColor = Color.Transparent };
        var badge = new Label
        {
            Text = "●  QLSinhVien\n.NET 10 · WinForms",
            Dock = DockStyle.Right,
            Width = 190,
            TextAlign = ContentAlignment.MiddleRight,
            Font = UiTheme.SmallBold,
            ForeColor = Color.FromArgb(187, 247, 208)
        };
        badgePanel.Controls.Add(badge);

        headerLayout.Controls.Add(titlePanel, 0, 0);
        headerLayout.Controls.Add(badgePanel, 1, 0);
        header.Controls.Add(headerLayout);

        var accentBar = new Panel { Dock = DockStyle.Fill, BackColor = UiTheme.HeaderAccent };

        _tabs = UiTheme.Tabs();
        _tabs.Dock = DockStyle.Fill;

        _tabStudents = new TabPage("Sinh viên") { BackColor = UiTheme.Background, Padding = new Padding(14) };
        _tabErrorLab = new TabPage("Kiểm thử lỗi") { BackColor = UiTheme.Background, Padding = new Padding(14) };
        _tabLogs = new TabPage("Nhật ký") { BackColor = UiTheme.Background, Padding = new Padding(14) };
        _tabSettings = new TabPage("Cấu hình") { BackColor = UiTheme.Background, Padding = new Padding(14) };
        _tabPreflight = new TabPage("Kiểm tra") { BackColor = UiTheme.Background, Padding = new Padding(14) };
        _tabDeployment = new TabPage("Triển khai") { BackColor = UiTheme.Background, Padding = new Padding(14) };
        _tabs.TabPages.AddRange(new[] { _tabStudents, _tabErrorLab, _tabLogs, _tabSettings, _tabPreflight, _tabDeployment });

        var status = new Panel
        {
            Dock = DockStyle.Fill,
            BackColor = UiTheme.Surface,
            Padding = new Padding(12, 0, 12, 0)
        };
        _statusPanel = status;
        var statusTopBorder = new Panel { Dock = DockStyle.Top, Height = 1, BackColor = UiTheme.Border };
        _statusMain = new Label
        {
            Dock = DockStyle.Left,
            Width = 700,
            AutoSize = false,
            Font = UiTheme.Small,
            ForeColor = UiTheme.Muted,
            TextAlign = ContentAlignment.MiddleLeft,
            Text = "Sẵn sàng."
        };
        _statusRight = new Label
        {
            Dock = DockStyle.Fill,
            AutoSize = false,
            Font = UiTheme.Small,
            ForeColor = UiTheme.Muted,
            TextAlign = ContentAlignment.MiddleRight
        };
        status.Controls.Add(_statusRight);
        status.Controls.Add(_statusMain);
        status.Controls.Add(statusTopBorder);

        root.Controls.Add(header, 0, 0);
        root.Controls.Add(accentBar, 0, 1);
        root.Controls.Add(_tabs, 0, 2);
        root.Controls.Add(status, 0, 3);
        Controls.Add(root);
    }

    private void OnFormShown(object? sender, EventArgs e)
    {
        SetStatus("Sẵn sàng. Dữ liệu: QLSinhVien · Nhật ký: " + _config.LogFolder, false);

        _logTimer = new System.Windows.Forms.Timer { Interval = 3000 };
        _logTimer.Tick += (_, _) =>
        {
            if (_tabs.SelectedTab == _tabLogs) RefreshLogs();
        };
        _logTimer.Start();

        if (!_silent)
        {
            BeginInvoke(new Action(() =>
            {
                RunPreflight();
                var report = _lastPreflight;
                if (report != null && report.Overall == CheckStatus.Fail)
                {
                    ErrorPresenter.Show(this,
                        new BusinessException("PREFLIGHT_FAILED",
                            "Môi trường chưa sẵn sàng. Xem tab Kiểm tra để biết chi tiết.",
                            hint: "Khắc phục các hạng mục LỖI rồi chạy kiểm tra lại."),
                        "Kiểm tra trước khi chạy", silent: false);
                }
            }));
        }
    }

    public void SetStatus(string text, bool error = false)
    {
        if (InvokeRequired)
        {
            BeginInvoke(new Action(() => SetStatus(text, error)));
            return;
        }
        _statusMain.Text = text.Replace('\r', ' ').Replace('\n', ' ').Trim();
        _statusMain.ForeColor = error ? UiTheme.Danger : UiTheme.Muted;
        _statusRight.Text = "Nhật ký: " + Path.GetFileName(AppLogger.CurrentFile);
    }

    private void ShowInfo(string message, string title = "Thông báo")
    {
        SetStatus(message.Replace(Environment.NewLine, " "));
        if (!_silent)
            MessageBox.Show(this, message, title, MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    // ---------------------------------------------------------------------
    // API phục vụ chế độ --capture
    // ---------------------------------------------------------------------

    public void SelectTab(int index)
    {
        if (index < 0 || index >= _tabs.TabPages.Count) return;
        _tabs.SelectedIndex = index;
        _tabs.SelectedTab?.PerformLayout();
        Application.DoEvents();
    }

    public string CaptureCurrentTab(string filePath)
    {
        _tabs.SelectedTab?.PerformLayout();
        PerformLayout();
        Application.DoEvents();
        Thread.Sleep(120);
        Application.DoEvents();

        var folder = Path.GetDirectoryName(filePath);
        if (!string.IsNullOrWhiteSpace(folder)) Directory.CreateDirectory(folder);

        // Vẽ trực tiếp control gốc (vùng client) để tránh vệt sơn của DrawToBitmap khi lấy cả khung cửa sổ.
        using var bitmap = new Bitmap(ClientSize.Width, ClientSize.Height);
        if (Controls.Count > 0)
            Controls[0].DrawToBitmap(bitmap, new Rectangle(0, 0, bitmap.Width, bitmap.Height));
        else
            DrawToBitmap(bitmap, new Rectangle(0, 0, bitmap.Width, bitmap.Height));

        // DrawToBitmap có thể vẽ đè nội dung tab đang tràn xuống đáy; vẽ lại thanh trạng thái
        // một lần nữa để ảnh luôn sạch và thể hiện đúng dòng trạng thái.
        if (_statusPanel != null)
            _statusPanel.DrawToBitmap(bitmap, _statusPanel.Bounds);

        bitmap.Save(filePath, ImageFormat.Png);
        return filePath;
    }

    public PreflightReport? LastPreflight => _lastPreflight;

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            _logTimer?.Stop();
            _logTimer?.Dispose();
        }
        base.Dispose(disposing);
    }
}
