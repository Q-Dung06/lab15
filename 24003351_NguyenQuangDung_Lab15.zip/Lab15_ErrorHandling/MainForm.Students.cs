using System.Data.SqlClient;
using System.Globalization;
using Lab15.BUS;

namespace Lab15_ErrorHandling;

public partial class MainForm
{
    private DataGridView _studentGrid = null!;
    private TextBox _txtKeyword = null!;
    private ComboBox _cboFacultyFilter = null!;
    private CheckBox _chkIncludeInactive = null!;
    private Label _lblStudentCount = null!;
    private TextBox _txtMaSV = null!;
    private TextBox _txtHoTen = null!;
    private TextBox _txtNgaySinh = null!;
    private ComboBox _cboGender = null!;
    private ComboBox _cboFaculty = null!;
    private TextBox _txtDiemTB = null!;
    private TextBox _txtEmail = null!;
    private CheckBox _chkActive = null!;
    private Label _lblEditorMode = null!;
    private Label _lblValidation = null!;
    private Button _btnUpdate = null!;
    private Button _btnDelete = null!;
    private ErrorProvider _errorProvider = null!;
    private List<SinhVienDto> _students = new();
    private List<FacultyDto> _faculties = new();
    private SinhVienDto? _currentStudent;
    private bool _suppressSelection;

    private void BuildStudentTab()
    {
        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 2,
            BackColor = UiTheme.Background,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 46));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        root.Controls.Add(BuildStudentToolbar(), 0, 0);

        var content = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 1,
            BackColor = UiTheme.Background,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };
        content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        content.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 376));
        content.Controls.Add(BuildStudentGridCard(), 0, 0);
        content.Controls.Add(BuildStudentEditor(), 1, 0);
        root.Controls.Add(content, 0, 1);

        _tabStudents.Controls.Add(root);

        _errorProvider = new ErrorProvider { BlinkStyle = ErrorBlinkStyle.NeverBlink };
        _errorProvider.ContainerControl = this;

        LoadFaculties();
        ShowNewStudentEditor();
        RefreshStudentGrid();
    }

    private Control BuildStudentToolbar()
    {
        var toolbar = new Panel
        {
            Dock = DockStyle.Fill,
            BackColor = UiTheme.Background,
            Padding = new Padding(0, 8, 0, 4)
        };

        var flow = new FlowLayoutPanel
        {
            Dock = DockStyle.Left,
            AutoSize = true,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false,
            BackColor = Color.Transparent,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };

        var searchLabel = UiTheme.Label("Tìm kiếm", UiTheme.SmallBold, UiTheme.Muted);
        searchLabel.Margin = new Padding(0, 9, 8, 0);
        _txtKeyword = UiTheme.TextBox("Mã SV hoặc họ tên…");
        _txtKeyword.Width = 190;
        _txtKeyword.Margin = new Padding(0, 4, 12, 0);
        _txtKeyword.KeyDown += (_, e) =>
        {
            if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; RefreshStudentGrid(); }
        };

        var facultyLabel = UiTheme.Label("Khoa", UiTheme.SmallBold, UiTheme.Muted);
        facultyLabel.Margin = new Padding(0, 9, 8, 0);
        _cboFacultyFilter = UiTheme.ComboBox();
        _cboFacultyFilter.Width = 170;
        _cboFacultyFilter.Margin = new Padding(0, 3, 12, 0);
        _cboFacultyFilter.SelectedIndexChanged += (_, _) => { if (_cboFacultyFilter.Focused) RefreshStudentGrid(); };

        _chkIncludeInactive = new CheckBox
        {
            Text = "Gồm ngừng học",
            AutoSize = true,
            Font = UiTheme.Small,
            ForeColor = UiTheme.Muted,
            Margin = new Padding(0, 8, 12, 0)
        };
        _chkIncludeInactive.CheckedChanged += (_, _) => RefreshStudentGrid();

        var btnSearch = UiTheme.Button("Tìm", UiTheme.Accent, Color.White, (_, _) => RefreshStudentGrid());
        btnSearch.Margin = new Padding(0, 2, 6, 0);
        var btnReload = UiTheme.Button("Tải lại", null, null, (_, _) =>
        {
            LoadFaculties();
            RefreshStudentGrid();
        });
        btnReload.Margin = new Padding(0, 2, 6, 0);
        var btnCsv = UiTheme.Button("Xuất CSV", null, null, (_, _) => ExportStudents("csv"));
        btnCsv.Margin = new Padding(0, 2, 6, 0);
        var btnXlsx = UiTheme.Button("Xuất XLSX", null, null, (_, _) => ExportStudents("xlsx"));
        btnXlsx.Margin = new Padding(0, 2, 6, 0);

        flow.Controls.AddRange(new Control[]
        {
            searchLabel, _txtKeyword, facultyLabel, _cboFacultyFilter,
            _chkIncludeInactive, btnSearch, btnReload, btnCsv, btnXlsx
        });

        toolbar.Controls.Add(flow);
        return toolbar;
    }

    private Control BuildStudentGridCard()
    {
        var card = UiTheme.Card(12);
        card.Dock = DockStyle.Fill;
        card.Margin = new Padding(0, 0, 12, 0);
        card.Padding = new Padding(12);

        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 2,
            BackColor = UiTheme.Surface,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 32));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        var header = new Panel { Dock = DockStyle.Fill, BackColor = UiTheme.Surface };
        var title = UiTheme.Label("Danh sách sinh viên", new Font("Segoe UI", 10.5f, FontStyle.Bold), UiTheme.Primary);
        title.Location = new Point(0, 4);
        var hint = new Label
        {
            Text = "Chọn một dòng để sửa · nhấn Enter ở ô tìm kiếm để lọc",
            AutoSize = true,
            Font = UiTheme.Small,
            ForeColor = UiTheme.Muted,
            Location = new Point(180, 7)
        };
        _lblStudentCount = new Label
        {
            Dock = DockStyle.Right,
            Width = 210,
            TextAlign = ContentAlignment.MiddleRight,
            Font = UiTheme.SmallBold,
            ForeColor = UiTheme.Muted,
            Padding = new Padding(0, 2, 2, 0)
        };
        header.Controls.Add(title);
        header.Controls.Add(hint);
        header.Controls.Add(_lblStudentCount);

        _studentGrid = new DataGridView { Dock = DockStyle.Fill };
        UiTheme.StyleGrid(_studentGrid);
        _studentGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        AddGridColumn("MaSV", "Mã SV", 60, 55);
        AddGridColumn("HoTen", "Họ tên", 160, 110);
        AddGridColumn("NgaySinh", "Ngày sinh", 80, 78);
        AddGridColumn("GioiTinh", "Giới tính", 60, 58);
        AddGridColumn("MaKhoa", "Mã khoa", 60, 55);
        AddGridColumn("TenKhoa", "Tên khoa", 150, 110);
        AddGridColumn("DiemTB", "Điểm TB", 55, 52);
        AddGridColumn("Email", "Email", 150, 120);
        AddGridColumn("TrangThai", "Trạng thái", 80, 74);
        AddGridColumn("SoDangKy", "Đăng ký", 50, 48);
        _studentGrid.SelectionChanged += (_, _) => OnStudentSelectionChanged();
        _studentGrid.CellDoubleClick += (_, _) => _txtHoTen.Focus();

        layout.Controls.Add(header, 0, 0);
        layout.Controls.Add(_studentGrid, 0, 1);
        card.Controls.Add(layout);
        return card;
    }

    private Control BuildStudentEditor()
    {
        var card = UiTheme.Card(12);
        card.Dock = DockStyle.Fill;
        card.Padding = new Padding(12);

        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 4,
            BackColor = UiTheme.Surface,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 30));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 72));

        var header = new Panel { Dock = DockStyle.Fill, BackColor = UiTheme.Surface };
        _lblEditorMode = UiTheme.Label("Thêm sinh viên mới", new Font("Segoe UI", 10.5f, FontStyle.Bold), UiTheme.Primary);
        _lblEditorMode.Location = new Point(0, 1);
        _chkActive = new CheckBox
        {
            Text = "Đang học",
            AutoSize = false,
            Dock = DockStyle.Right,
            Width = 88,
            TextAlign = ContentAlignment.MiddleLeft,
            Font = UiTheme.Small,
            ForeColor = Color.FromArgb(31, 41, 55),
            Padding = new Padding(0, 3, 0, 0)
        };
        header.Controls.Add(_chkActive);
        header.Controls.Add(_lblEditorMode);

        var fields = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 7,
            BackColor = UiTheme.Surface,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };
        for (var i = 0; i < 7; i++) fields.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));

        _txtMaSV = UiTheme.TextBox("Ví dụ SV031");
        _txtHoTen = UiTheme.TextBox("Họ và tên");
        _txtNgaySinh = UiTheme.TextBox("dd/MM/yyyy");
        _cboGender = UiTheme.ComboBox();
        _cboGender.Items.AddRange(new object[] { "Nam", "Nữ" });
        _cboGender.SelectedIndex = 0;
        _cboFaculty = UiTheme.ComboBox();
        _txtDiemTB = UiTheme.TextBox("0 – 10");
        _txtEmail = UiTheme.TextBox("ten@eaut.edu.vn (không bắt buộc)");

        fields.Controls.Add(Field("Mã sinh viên *", _txtMaSV), 0, 0);
        fields.Controls.Add(Field("Họ và tên *", _txtHoTen), 0, 1);
        fields.Controls.Add(Field("Ngày sinh * (dd/MM/yyyy)", _txtNgaySinh), 0, 2);
        fields.Controls.Add(Field("Giới tính", _cboGender), 0, 3);
        fields.Controls.Add(Field("Khoa *", _cboFaculty), 0, 4);
        fields.Controls.Add(Field("Điểm trung bình * (0 – 10)", _txtDiemTB), 0, 5);
        fields.Controls.Add(Field("Email", _txtEmail), 0, 6);

        var buttons = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = true,
            BackColor = UiTheme.Surface,
            Margin = new Padding(0),
            Padding = new Padding(0, 4, 0, 0)
        };
        var btnAdd = UiTheme.Button("Thêm mới", UiTheme.Accent, Color.White, (_, _) => SaveStudent(false));
        var btnNew = UiTheme.Button("Nhập lại", null, null, (_, _) => ShowNewStudentEditor());
        _btnUpdate = UiTheme.Button("Cập nhật", null, null, (_, _) => SaveStudent(true));
        _btnDelete = UiTheme.Button("Xóa", UiTheme.Danger, Color.White, (_, _) => DeleteStudent());
        foreach (var button in new[] { btnAdd, _btnUpdate, _btnDelete, btnNew })
        {
            button.AutoSize = true;
            button.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            button.MinimumSize = new Size(48, 30);
            button.Padding = new Padding(8, 0, 8, 0);
            button.Margin = new Padding(0, 0, 6, 0);
            button.Font = UiTheme.SmallBold;
        }
        buttons.Padding = new Padding(0, 3, 0, 0);
        buttons.WrapContents = false;
        buttons.Controls.AddRange(new Control[] { btnAdd, _btnUpdate, _btnDelete, btnNew });

        _lblValidation = new Label
        {
            Dock = DockStyle.Fill,
            AutoSize = false,
            Font = new Font("Segoe UI", 7.5f),
            ForeColor = UiTheme.Danger,
            BackColor = Color.Transparent,
            Padding = new Padding(8, 5, 8, 5),
            TextAlign = ContentAlignment.TopLeft,
            Text = ""
        };

        layout.Controls.Add(header, 0, 0);
        layout.Controls.Add(fields, 0, 1);
        layout.Controls.Add(buttons, 0, 2);
        layout.Controls.Add(_lblValidation, 0, 3);
        card.Controls.Add(layout);
        return card;
    }

    private static Control Field(string label, Control input)
    {
        var host = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 2,
            Margin = new Padding(0),
            Padding = new Padding(0),
            BackColor = UiTheme.Surface
        };
        host.RowStyles.Add(new RowStyle(SizeType.Absolute, 15));
        host.RowStyles.Add(new RowStyle(SizeType.Absolute, 27));

        var text = new Label
        {
            Text = label,
            Dock = DockStyle.Fill,
            Font = UiTheme.SmallBold,
            ForeColor = UiTheme.Muted,
            TextAlign = ContentAlignment.MiddleLeft,
            Margin = new Padding(0)
        };
        input.Dock = DockStyle.Fill;
        input.Margin = new Padding(0);
        host.Controls.Add(text, 0, 0);
        host.Controls.Add(input, 0, 1);
        return host;
    }

    private void LoadFaculties()
    {
        try
        {
            _faculties = _studentService.GetFaculties().ToList();
        }
        catch (Exception ex)
        {
            _faculties = new List<FacultyDto>();
            ErrorPresenter.Show(this, ex, "Tải danh sách khoa", _silent);
            return;
        }

        var filterIndex = _cboFacultyFilter.SelectedIndex;
        _cboFacultyFilter.Items.Clear();
        _cboFacultyFilter.Items.Add(new FacultyDto("", "Tất cả khoa"));
        foreach (var faculty in _faculties) _cboFacultyFilter.Items.Add(faculty);
        _cboFacultyFilter.SelectedIndex = filterIndex >= 0 && filterIndex < _cboFacultyFilter.Items.Count ? filterIndex : 0;

        var editorIndex = _cboFaculty.SelectedIndex;
        _cboFaculty.Items.Clear();
        foreach (var faculty in _faculties) _cboFaculty.Items.Add(faculty);
        _cboFaculty.SelectedIndex = editorIndex >= 0 && editorIndex < _cboFaculty.Items.Count ? editorIndex : -1;
    }

    public void RefreshStudentGrid()
    {
        if (_studentGrid == null) return;
        var faculty = _cboFacultyFilter.SelectedItem as FacultyDto;
        var maKhoa = string.IsNullOrWhiteSpace(faculty?.MaKhoa) ? null : faculty.MaKhoa;

        try
        {
            _students = _studentService.Search(_txtKeyword.Text, maKhoa, _chkIncludeInactive.Checked).ToList();
        }
        catch (Exception ex)
        {
            _students = new List<SinhVienDto>();
            ErrorPresenter.Show(this, ex, "Tải danh sách sinh viên", _silent);
            _lblStudentCount.Text = "Không tải được dữ liệu";
        }

        _suppressSelection = true;
        _studentGrid.Rows.Clear();
        foreach (var sv in _students)
        {
            var index = _studentGrid.Rows.Add(
                sv.MaSV,
                sv.HoTen,
                sv.NgaySinh.ToString("dd/MM/yyyy"),
                sv.GioiTinhText,
                sv.MaKhoa,
                sv.TenKhoa,
                sv.DiemTB.ToString("0.##", CultureInfo.InvariantCulture),
                sv.Email ?? "",
                sv.TrangThaiText,
                sv.SoDangKy);

            var row = _studentGrid.Rows[index];
            if (!sv.IsActive)
            {
                row.DefaultCellStyle.ForeColor = UiTheme.Muted;
                row.DefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252);
            }
            if (sv.SoDangKy > 0)
                row.Cells["SoDangKy"].Style.ForeColor = UiTheme.Primary;
        }
        _suppressSelection = false;

        _lblStudentCount.Text = $"{_students.Count} sinh viên · {_faculties.Count} khoa";
        if (_students.Count > 0)
        {
            _studentGrid.ClearSelection();
        }
        else
        {
            ShowNewStudentEditor();
        }
    }

    private void OnStudentSelectionChanged()
    {
        if (_suppressSelection) return;
        if (_studentGrid.CurrentRow == null || _studentGrid.CurrentRow.Index < 0) return;
        var index = _studentGrid.CurrentRow.Index;
        if (index >= _students.Count) return;
        LoadStudentToEditor(_students[index]);
    }

    private void LoadStudentToEditor(SinhVienDto sv)
    {
        _currentStudent = sv;
        _txtMaSV.Text = sv.MaSV;
        _txtMaSV.ReadOnly = true;
        _txtHoTen.Text = sv.HoTen;
        _txtNgaySinh.Text = sv.NgaySinh.ToString("dd/MM/yyyy");
        _cboGender.SelectedIndex = sv.GioiTinh ? 0 : 1;
        _cboFaculty.SelectedItem = _cboFaculty.Items.Cast<FacultyDto>()
            .FirstOrDefault(f => string.Equals(f.MaKhoa, sv.MaKhoa, StringComparison.OrdinalIgnoreCase));
        _txtDiemTB.Text = sv.DiemTB.ToString("0.##", CultureInfo.InvariantCulture);
        _txtEmail.Text = sv.Email ?? "";
        _chkActive.Checked = sv.IsActive;

        _lblEditorMode.Text = "Cập nhật sinh viên " + sv.MaSV;
        _btnUpdate.Enabled = true;
        _btnDelete.Enabled = true;
        ClearValidation();
    }

    public void ShowNewStudentEditor()
    {
        _currentStudent = null;
        _txtMaSV.ReadOnly = false;
        _txtMaSV.Text = "";
        _txtHoTen.Text = "";
        _txtNgaySinh.Text = DateTime.Today.AddYears(-18).ToString("dd/MM/yyyy");
        _cboGender.SelectedIndex = 0;
        _cboFaculty.SelectedIndex = -1;
        _txtDiemTB.Text = "0";
        _txtEmail.Text = "";
        _chkActive.Checked = true;
        _lblEditorMode.Text = "Thêm sinh viên mới";
        _btnUpdate.Enabled = false;
        _btnDelete.Enabled = false;
        ClearValidation();
        if (!_silent) _txtMaSV.Focus();
    }

    private StudentInput ReadEditor(bool isEdit) => new()
    {
        MaSV = _txtMaSV.Text,
        HoTen = _txtHoTen.Text,
        NgaySinh = _txtNgaySinh.Text,
        GioiTinh = _cboGender.SelectedIndex == 0,
        MaKhoa = (_cboFaculty.SelectedItem as FacultyDto)?.MaKhoa ?? "",
        DiemTB = _txtDiemTB.Text,
        Email = _txtEmail.Text,
        IsActive = _chkActive.Checked,
        IsEdit = isEdit
    };

    private void SaveStudent(bool isEdit)
    {
        if (isEdit && _currentStudent == null)
        {
            ShowInfo("Chưa chọn sinh viên để cập nhật.", "Thiếu dữ liệu");
            return;
        }

        var input = ReadEditor(isEdit);
        if (isEdit && _currentStudent != null) input.MaSV = _currentStudent.MaSV;

        try
        {
            if (isEdit) _studentService.Update(input);
            else _studentService.Create(input);

            RefreshStudentGrid();
            SelectStudentByCode(input.MaSV.Trim());
            ClearValidation();
            ShowInfo(isEdit
                ? $"Đã cập nhật sinh viên {input.MaSV.Trim()}."
                : $"Đã thêm sinh viên {input.MaSV.Trim()}.", "Thành công");
        }
        catch (ValidationBusinessException ex)
        {
            ApplyValidation(ex.Validation);
            ErrorPresenter.Show(this, ex, isEdit ? "Cập nhật sinh viên" : "Thêm sinh viên", _silent);
        }
        catch (BusinessException ex)
        {
            ApplyValidation(ex.Validation);
            ErrorPresenter.Show(this, ex, isEdit ? "Cập nhật sinh viên" : "Thêm sinh viên", _silent);
        }
        catch (SqlException ex)
        {
            ErrorPresenter.Show(this, ex, isEdit ? "Cập nhật sinh viên" : "Thêm sinh viên", _silent);
        }
        catch (Exception ex)
        {
            ErrorPresenter.Show(this, ex, isEdit ? "Cập nhật sinh viên" : "Thêm sinh viên", _silent);
        }
    }

    private void DeleteStudent()
    {
        if (_currentStudent == null)
        {
            ShowInfo("Chưa chọn sinh viên để xóa.", "Thiếu dữ liệu");
            return;
        }

        if (!_silent)
        {
            var answer = MessageBox.Show(this,
                $"Xóa sinh viên {_currentStudent.MaSV} – {_currentStudent.HoTen}?",
                "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (answer != DialogResult.Yes) return;
        }

        try
        {
            _studentService.Delete(_currentStudent.MaSV);
            RefreshStudentGrid();
            ShowNewStudentEditor();
            ShowInfo($"Đã xóa sinh viên {_currentStudent?.MaSV}.", "Thành công");
        }
        catch (BusinessException ex)
        {
            ErrorPresenter.Show(this, ex, "Xóa sinh viên", _silent);
        }
        catch (SqlException ex)
        {
            ErrorPresenter.Show(this, ex, "Xóa sinh viên", _silent);
        }
        catch (Exception ex)
        {
            ErrorPresenter.Show(this, ex, "Xóa sinh viên", _silent);
        }
    }

    private void ExportStudents(string format)
    {
        try
        {
            var path = format == "xlsx"
                ? StudentExportService.BuildFilePath(_config.ReportFolder, "DanhSachSinhVien", "xlsx")
                : StudentExportService.BuildFilePath(_config.ReportFolder, "DanhSachSinhVien", "csv");

            if (format == "xlsx") StudentExportService.ExportStudentsXlsx(_students, path);
            else StudentExportService.ExportStudentsCsv(_students, path);

            ShowInfo($"Đã xuất {_students.Count} sinh viên ra:\n{path}", "Xuất dữ liệu");
        }
        catch (Exception ex)
        {
            ErrorPresenter.Show(this, ex, "Xuất danh sách sinh viên", _silent);
        }
    }

    public void ApplyValidation(ValidationResult? result)
    {
        ClearValidation();
        if (result == null || result.IsValid) return;

        _errorProvider.SetError(_txtMaSV, result["MaSV"] ?? "");
        _errorProvider.SetError(_txtHoTen, result["HoTen"] ?? "");
        _errorProvider.SetError(_txtNgaySinh, result["NgaySinh"] ?? "");
        _errorProvider.SetError(_cboFaculty, result["MaKhoa"] ?? "");
        _errorProvider.SetError(_txtDiemTB, result["DiemTB"] ?? "");
        _errorProvider.SetError(_txtEmail, result["Email"] ?? "");

        _lblValidation.BackColor = UiTheme.DangerSoft;
        _lblValidation.ForeColor = UiTheme.Danger;

        var lines = new List<string> { $"Dữ liệu chưa hợp lệ ({result.ErrorCount} lỗi):" };
        foreach (var pair in result.Errors.Take(3))
        {
            var raw = pair.Value;
            var message = raw.Length > 40 ? raw[..40] + "…" : raw;
            lines.Add("• " + FieldLabel(pair.Key) + ": " + message);
        }

        var remaining = result.Errors.Keys.Skip(3).Select(FieldLabel).ToList();
        if (remaining.Count > 0)
            lines.Add("• Còn lại: " + string.Join(", ", remaining));

        _lblValidation.Text = string.Join(Environment.NewLine, lines);
    }

    private static string FieldLabel(string field) => field switch
    {
        "MaSV" => "Mã SV",
        "HoTen" => "Họ tên",
        "NgaySinh" => "Ngày sinh",
        "MaKhoa" => "Khoa",
        "DiemTB" => "Điểm TB",
        "Email" => "Email",
        _ => field
    };

    public void ClearValidation()
    {
        _errorProvider.SetError(_txtMaSV, "");
        _errorProvider.SetError(_txtHoTen, "");
        _errorProvider.SetError(_txtNgaySinh, "");
        _errorProvider.SetError(_cboFaculty, "");
        _errorProvider.SetError(_txtDiemTB, "");
        _errorProvider.SetError(_txtEmail, "");
        _lblValidation.BackColor = Color.Transparent;
        _lblValidation.Text = "";
    }

    public bool SelectStudentByCode(string maSV)
    {
        var index = _students.FindIndex(s =>
            string.Equals(s.MaSV, maSV, StringComparison.OrdinalIgnoreCase));
        if (index < 0) return false;

        _suppressSelection = true;
        _studentGrid.ClearSelection();
        _studentGrid.CurrentCell = _studentGrid.Rows[index].Cells[0];
        _studentGrid.Rows[index].Selected = true;
        _suppressSelection = false;
        LoadStudentToEditor(_students[index]);
        return true;
    }

    /// <summary>Chuẩn bị màn hình minh họa Bài 2: nhiều lỗi nhập liệu cùng lúc.</summary>
    public ValidationResult PrepareValidationDemo()
    {
        ShowNewStudentEditor();
        _txtMaSV.Text = "SV@";
        _txtHoTen.Text = "12345";
        _txtNgaySinh.Text = "31/02/2020";
        _cboFaculty.SelectedIndex = -1;
        _txtDiemTB.Text = "12,5";
        _txtEmail.Text = "email-sai";
        var result = _studentService.Validate(ReadEditor(false), checkDatabase: false);
        ApplyValidation(result);
        AppLogger.Warn("Minh họa kiểm tra dữ liệu: " + result.ErrorCount + " lỗi cùng lúc.",
            LogCategories.Validation, result.Summary);
        SetStatus($"Minh họa kiểm tra dữ liệu: phát hiện {result.ErrorCount} lỗi cùng lúc.", false);
        return result;
    }

    private void AddGridColumn(string name, string header, int weight, int minimum)
    {
        _studentGrid.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = name,
            HeaderText = header,
            FillWeight = weight,
            MinimumWidth = minimum,
            SortMode = DataGridViewColumnSortMode.NotSortable,
            ReadOnly = true
        });
    }
}
