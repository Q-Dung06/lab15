using System.Diagnostics;
using Lab15.BUS;

namespace Lab15_ErrorHandling;

public partial class MainForm
{
    private DataGridView _deploymentGrid = null!;
    private Label _lblDeployEnvironment = null!;
    private Label _lblDeployPublish = null!;
    private Label _lblDeployStatus = null!;
    private string _lastDeploymentReportPath = "";

    private void BuildDeploymentTab()
    {
        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 3,
            BackColor = UiTheme.Background,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 118));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 46));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.Controls.Add(BuildDeploymentSummaryCard(), 0, 0);
        root.Controls.Add(BuildDeploymentToolbar(), 0, 1);
        root.Controls.Add(BuildDeploymentGridCard(), 0, 2);
        _tabDeployment.Controls.Add(root);

        RefreshDeploymentView();
    }

    private Control BuildDeploymentSummaryCard()
    {
        var card = UiTheme.Card(16);
        card.Dock = DockStyle.Fill;
        card.Margin = new Padding(0, 0, 0, 10);
        card.Padding = new Padding(16, 10, 16, 10);

        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 1,
            BackColor = UiTheme.Surface,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 330));

        var left = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 2,
            BackColor = UiTheme.Surface,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };
        left.RowStyles.Add(new RowStyle(SizeType.Absolute, 30));
        left.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        var title = UiTheme.Label("Triển khai & kiểm thử trên máy đích (Bài 10)",
            new Font("Segoe UI", 11f, FontStyle.Bold), UiTheme.Primary);
        title.Dock = DockStyle.Fill;

        _lblDeployEnvironment = new Label
        {
            Dock = DockStyle.Fill,
            AutoSize = false,
            Font = UiTheme.Small,
            ForeColor = UiTheme.Muted,
            TextAlign = ContentAlignment.TopLeft,
            Padding = new Padding(0, 2, 0, 0)
        };
        left.Controls.Add(title, 0, 0);
        left.Controls.Add(_lblDeployEnvironment, 0, 1);

        _lblDeployPublish = new Label
        {
            Dock = DockStyle.Fill,
            AutoSize = false,
            Font = UiTheme.Small,
            ForeColor = UiTheme.Muted,
            TextAlign = ContentAlignment.MiddleLeft,
            Padding = new Padding(14, 4, 4, 4),
            BackColor = Color.FromArgb(248, 250, 252)
        };

        layout.Controls.Add(left, 0, 0);
        layout.Controls.Add(_lblDeployPublish, 1, 0);
        card.Controls.Add(layout);
        return card;
    }

    private Control BuildDeploymentToolbar()
    {
        var toolbar = new Panel
        {
            Dock = DockStyle.Fill,
            BackColor = UiTheme.Background,
            Padding = new Padding(0, 2, 0, 6)
        };
        var flow = new FlowLayoutPanel
        {
            Dock = DockStyle.Left,
            AutoSize = true,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false,
            BackColor = Color.Transparent,
            Padding = new Padding(0),
            Margin = new Padding(0)
        };
        var export = UiTheme.Button("Xuất biên bản kiểm thử", UiTheme.Accent, Color.White, (_, _) => ExportDeploymentReport());
        var refresh = UiTheme.Button("Tải lại thông tin", null, null, (_, _) => RefreshDeploymentView());
        var publish = UiTheme.Button("Mở thư mục Publish", null, null, (_, _) => OpenPublishFolder());
        var reports = UiTheme.Button("Mở thư mục Reports", null, null, (_, _) => OpenFolder(_config.ReportFolder));
        export.Margin = new Padding(0, 2, 6, 0);
        refresh.Margin = new Padding(0, 2, 6, 0);
        publish.Margin = new Padding(0, 2, 6, 0);
        reports.Margin = new Padding(0, 2, 6, 0);
        flow.Controls.AddRange(new Control[] { export, refresh, publish, reports });

        _lblDeployStatus = new Label
        {
            Dock = DockStyle.Right,
            Width = 520,
            AutoSize = false,
            TextAlign = ContentAlignment.MiddleRight,
            Font = UiTheme.Small,
            ForeColor = UiTheme.Muted,
            Padding = new Padding(0, 4, 2, 0),
            Text = "Biên bản ghi vào thư mục Reports · Publish: dotnet publish -c Release -o Publish"
        };

        toolbar.Controls.Add(flow);
        toolbar.Controls.Add(_lblDeployStatus);
        return toolbar;
    }

    private Control BuildDeploymentGridCard()
    {
        var card = UiTheme.Card(12);
        card.Dock = DockStyle.Fill;
        card.Padding = new Padding(12);

        _deploymentGrid = new DataGridView { Dock = DockStyle.Fill };
        UiTheme.StyleGrid(_deploymentGrid);
        _deploymentGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        _deploymentGrid.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = "Id", HeaderText = "Mã", FillWeight = 40, MinimumWidth = 45,
            ReadOnly = true, SortMode = DataGridViewColumnSortMode.NotSortable
        });
        _deploymentGrid.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = "HangMuc", HeaderText = "Hạng mục kiểm thử", FillWeight = 190, MinimumWidth = 170,
            ReadOnly = true, SortMode = DataGridViewColumnSortMode.NotSortable
        });
        _deploymentGrid.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = "KyVong", HeaderText = "Kỳ vọng", FillWeight = 250, MinimumWidth = 220,
            ReadOnly = true, SortMode = DataGridViewColumnSortMode.NotSortable
        });
        _deploymentGrid.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = "KetQua", HeaderText = "Kết quả", FillWeight = 70, MinimumWidth = 75,
            ReadOnly = true, SortMode = DataGridViewColumnSortMode.NotSortable
        });
        _deploymentGrid.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = "GhiChu", HeaderText = "Ghi chú", FillWeight = 230, MinimumWidth = 200,
            ReadOnly = true, SortMode = DataGridViewColumnSortMode.NotSortable
        });
        _deploymentGrid.CellFormatting += (_, e) =>
        {
            if (e.RowIndex < 0 || e.ColumnIndex != 3) return;
            var text = Convert.ToString(e.Value) ?? "";
            e.CellStyle!.Font = UiTheme.BodyBold;
            e.CellStyle.ForeColor = text == "ĐẠT" ? UiTheme.Success : UiTheme.Danger;
        };

        card.Controls.Add(_deploymentGrid);
        return card;
    }

    public void RefreshDeploymentView()
    {
        if (_deploymentGrid == null) return;
        var snapshot = DeploymentService.Capture(_config);
        var checklist = DeploymentService.BuildChecklist(_lastPreflight);

        _lblDeployEnvironment.Text =
            $"Máy: {snapshot.MachineName}  ·  Tài khoản: {snapshot.UserName}  ·  {snapshot.Architecture}" + Environment.NewLine +
            $"{snapshot.OperatingSystem}" + Environment.NewLine +
            $"{snapshot.DotNetVersion}  ·  Phiên bản ứng dụng: {snapshot.AppVersion}" + Environment.NewLine +
            $"Thư mục chạy: {snapshot.BaseDirectory}" + Environment.NewLine +
            $"Cấu hình: {snapshot.ConfigFile}";

        _lblDeployPublish.Text =
            (snapshot.PublishFolderExists ? "●  Thư mục Publish: đã có" : "○  Thư mục Publish: chưa tạo") + Environment.NewLine +
            $"Thư mục: {snapshot.PublishFolder}" + Environment.NewLine +
            $"Số tệp trong thư mục chạy: {snapshot.ApplicationFileCount}  ·  Tệp log: {snapshot.LogFileCount}" + Environment.NewLine +
            $"Chuỗi kết nối: {(snapshot.ProtectedConnection ? "đã bảo vệ (DPAPI)" : "chưa bảo vệ")}";
        _lblDeployPublish.ForeColor = snapshot.PublishFolderExists ? UiTheme.Success : UiTheme.Warning;

        _deploymentGrid.Rows.Clear();
        foreach (var item in checklist)
        {
            var index = _deploymentGrid.Rows.Add(
                item.Id, item.Title, item.Expected, item.Passed ? "ĐẠT" : "LỖI", item.Note);
            if (!item.Passed)
                _deploymentGrid.Rows[index].DefaultCellStyle.BackColor = UiTheme.DangerSoft;
        }

        _lblDeployStatus.Text = _lastPreflight == null
            ? "Chưa chạy kiểm tra trước khi chạy · biên bản sẽ ghi nhận trạng thái hiện tại."
            : "Kiểm tra trước khi chạy: " + _lastPreflight.OverallText + " · xuất biên bản để lưu minh chứng.";
        SetStatus("Đã cập nhật thông tin triển khai.", false);
    }

    private void ExportDeploymentReport()
    {
        try
        {
            _lastDeploymentReportPath = DeploymentService.WriteReport(_config.ReportFolder, _config, _lastPreflight);
            _lblDeployStatus.Text = "Đã xuất biên bản: " + Path.GetFileName(_lastDeploymentReportPath);
            ShowInfo("Đã xuất biên bản kiểm thử triển khai:\n" + _lastDeploymentReportPath, "Biên bản triển khai");
        }
        catch (Exception ex)
        {
            ErrorPresenter.Show(this, ex, "Xuất biên bản triển khai", _silent);
        }
    }

    public void ExportDeploymentReportForDemo() => ExportDeploymentReport();

    private void OpenPublishFolder()
    {
        try
        {
            var snapshot = DeploymentService.Capture(_config);
            if (!Directory.Exists(snapshot.PublishFolder))
            {
                ShowInfo("Chưa có thư mục Publish:\n" + snapshot.PublishFolder +
                         "\n\nTạo bằng lệnh: dotnet publish -c Release -o Publish", "Thiếu gói phát hành");
                return;
            }
            Process.Start(new ProcessStartInfo { FileName = snapshot.PublishFolder, UseShellExecute = true });
        }
        catch (Exception ex)
        {
            ErrorPresenter.Show(this, ex, "Mở thư mục Publish", _silent);
        }
    }
}
