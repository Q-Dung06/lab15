using System.Configuration;
using System.Data.SqlClient;
using System.Text;
using Lab15.BUS;

namespace Lab15_ErrorHandling;

public enum ErrorKind
{
    Business,
    Database,
    Configuration,
    Unexpected
}

/// <summary>
/// Bài 4 – Xử lý lỗi tập trung tại tầng giao diện.
/// Phân loại BusinessException / SqlException / Exception, ghi log và hiển thị
/// thông điệp phù hợp cho từng nhóm.
/// </summary>
internal static class ErrorPresenter
{
    public static string Classify(Exception exception) => exception switch
    {
        ValidationBusinessException => "BusinessException (ValidationBusinessException)",
        BusinessException => "BusinessException",
        SqlException => "SqlException",
        ConfigurationErrorsException => "ConfigurationException",
        _ => "Exception"
    };

    public static ErrorKind KindOf(Exception exception) => exception switch
    {
        BusinessException => ErrorKind.Business,
        SqlException => ErrorKind.Database,
        ConfigurationErrorsException => ErrorKind.Configuration,
        _ => ErrorKind.Unexpected
    };

    public static string Describe(Exception exception)
    {
        var builder = new StringBuilder();
        switch (exception)
        {
            case BusinessException business:
                builder.AppendLine("Loại lỗi   : BusinessException");
                builder.AppendLine("Mã lỗi     : " + business.Code);
                builder.AppendLine("Thông điệp : " + business.Message);
                if (!string.IsNullOrWhiteSpace(business.Hint))
                    builder.AppendLine("Gợi ý      : " + business.Hint);
                if (business.Validation is { IsValid: false } validation)
                {
                    builder.AppendLine();
                    builder.AppendLine("Chi tiết kiểm tra dữ liệu (" + validation.ErrorCount + " lỗi):");
                    foreach (var error in validation.Errors)
                        builder.AppendLine($"  • {error.Key}: {error.Value}");
                }
                break;

            case SqlException sql:
                builder.AppendLine("Loại lỗi   : SqlException");
                builder.AppendLine("Mã lỗi SQL : " + sql.Number);
                builder.AppendLine("Mức độ     : " + sql.Class + " | Server: " + sql.Server);
                if (!string.IsNullOrWhiteSpace(sql.Procedure))
                    builder.AppendLine("Thủ tục    : " + sql.Procedure + " (dòng " + sql.LineNumber + ")");
                builder.AppendLine("Thông điệp : " + FirstLine(sql.Message));
                builder.AppendLine("Hướng xử lý: " + SqlHint(sql.Number));
                break;

            case ConfigurationErrorsException configuration:
                builder.AppendLine("Loại lỗi   : ConfigurationException");
                builder.AppendLine("Thông điệp : " + configuration.Message);
                builder.AppendLine("Hướng xử lý: Kiểm tra App.config (connectionStrings/appSettings) rồi tải lại cấu hình.");
                break;

            default:
                builder.AppendLine("Loại lỗi   : Exception");
                builder.AppendLine("Kiểu lỗi   : " + exception.GetType().FullName);
                builder.AppendLine("Thông điệp : " + exception.Message);
                builder.AppendLine("Hướng xử lý: Xem tệp nhật ký để biết chi tiết và liên hệ giảng viên nếu cần.");
                break;
        }

        builder.AppendLine();
        builder.AppendLine("Nhật ký    : " + AppLogger.CurrentFile);
        return builder.ToString().TrimEnd();
    }

    /// <summary>Ghi log + hiển thị hộp thoại (trừ khi đang chạy ở chế độ im lặng).</summary>
    public static string Show(IWin32Window? owner, Exception exception, string context, bool silent)
    {
        var description = Describe(exception);
        var kind = KindOf(exception);

        switch (kind)
        {
            case ErrorKind.Business:
                AppLogger.Warn($"{context}: {Classify(exception)} – {exception.Message}", LogCategories.Ui,
                    (exception as BusinessException)?.Code);
                break;
            case ErrorKind.Database:
                AppLogger.Error($"{context}: SqlException – {FirstLine(exception.Message)}", LogCategories.Ui,
                    exception, DescribeSqlDetail((SqlException)exception));
                break;
            case ErrorKind.Configuration:
                AppLogger.Error($"{context}: ConfigurationException – {exception.Message}", LogCategories.Ui, exception);
                break;
            default:
                AppLogger.Error($"{context}: Exception – {exception.Message}", LogCategories.Ui, exception);
                break;
        }

        if (!silent)
        {
            var (icon, title) = kind switch
            {
                ErrorKind.Business => (MessageBoxIcon.Warning, "Không thể thực hiện"),
                ErrorKind.Database => (MessageBoxIcon.Error, "Lỗi cơ sở dữ liệu"),
                ErrorKind.Configuration => (MessageBoxIcon.Error, "Lỗi cấu hình"),
                _ => (MessageBoxIcon.Error, "Lỗi hệ thống")
            };

            var text = description;
            if (kind == ErrorKind.Unexpected)
                text += Environment.NewLine + Environment.NewLine +
                        "Ứng dụng vẫn tiếp tục chạy. Chi tiết đã được ghi vào tệp nhật ký.";

            if (owner == null)
                MessageBox.Show(text, title, MessageBoxButtons.OK, icon);
            else
                MessageBox.Show(owner, text, title, MessageBoxButtons.OK, icon);
        }

        return description;
    }

    public static string SqlHint(int number) => number switch
    {
        208 => "Bảng hoặc view không tồn tại. Kiểm tra tên bảng và script tạo CSDL.",
        547 => "Vi phạm khóa ngoại: bản ghi đang được bảng khác tham chiếu. Xóa dữ liệu liên quan trước.",
        2601 or 2627 => "Vi phạm ràng buộc duy nhất: mã sinh viên hoặc email đã tồn tại.",
        4060 => "Không mở được CSDL. Kiểm tra tên CSDL và quyền truy cập.",
        18456 => "Đăng nhập SQL thất bại. Kiểm tra tài khoản/mật khẩu trong chuỗi kết nối.",
        53 or 10061 => "Không tìm thấy SQL Server hoặc dịch vụ chưa chạy. Kiểm tra Data Source và dịch vụ SQL.",
        -2 => "Hết thời gian chờ. Kiểm tra kết nối mạng hoặc tải của SQL Server.",
        _ => "Xem thông điệp gốc, kiểm tra kết nối CSDL và dữ liệu liên quan."
    };

    private static string DescribeSqlDetail(SqlException sql) =>
        $"SqlNumber={sql.Number}; Class={sql.Class}; Server={sql.Server}; Procedure={sql.Procedure}; Line={sql.LineNumber}";

    private static string FirstLine(string text)
    {
        if (string.IsNullOrWhiteSpace(text)) return "(không có thông điệp)";
        var line = text.Replace("\r", "").Split('\n')[0].Trim();
        return line.Length > 400 ? line[..400] + "…" : line;
    }
}
