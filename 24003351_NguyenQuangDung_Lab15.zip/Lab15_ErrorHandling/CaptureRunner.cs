using System.Text;
using Lab15.BUS;

namespace Lab15_ErrorHandling;

/// <summary>
/// Chế độ --capture: mở giao diện ở chế độ im lặng, thực hiện lần lượt các kịch bản
/// và lưu ảnh chụp từng tab vào thư mục Screenshots.
/// </summary>
internal static class CaptureRunner
{
    private sealed record Shot(string FileName, string Description);

    public static int Run(string? outputFolder)
    {
        var folder = string.IsNullOrWhiteSpace(outputFolder)
            ? Path.Combine(AppContext.BaseDirectory, "Screenshots")
            : Path.GetFullPath(outputFolder);
        Directory.CreateDirectory(folder);

        var shots = new List<Shot>();
        MainForm? form = null;
        try
        {
            form = new MainForm(silent: true);
            form.Show();
            Application.DoEvents();
            Console.WriteLine($"FORM client={form.ClientSize}; size={form.Size}; screen={Screen.PrimaryScreen?.WorkingArea}");
            if (form.Controls.Count > 0 && form.Controls[0] is TableLayoutPanel shell)
            {
                foreach (Control child in shell.Controls)
                    Console.WriteLine($"  {child.GetType().Name,-18} bounds={child.Bounds}");
            }

            form.RunPreflight();
            form.RefreshStudentGrid();
            form.SelectStudentByCode("SV001");

            form.SelectTab(0);
            shots.Add(Save(form, folder, "01_TongQuan_SinhVien.png",
                "Tab Sinh viên: danh sách, bộ lọc, biểu mẫu nhập và các nút thao tác."));

            form.PrepareValidationDemo();
            shots.Add(Save(form, folder, "02_KiemTraDuLieu_NhieuLoi.png",
                "Bài 2: một lần nhập báo nhiều lỗi, đánh dấu từng ô và liệt kê chi tiết."));
            form.ShowNewStudentEditor();
            form.RefreshStudentGrid();
            form.SelectStudentByCode("SV001");

            form.SelectTab(1);
            form.RunDemoBusinessError();
            shots.Add(Save(form, folder, "03_LoiNghiepVu_BusinessException.png",
                "Bài 1/4: BusinessException khi xóa sinh viên còn đăng ký học phần."));

            form.RunDemoForeignKeyError();
            shots.Add(Save(form, folder, "04_LoiCSDL_KhoaNgoai.png",
                "Bài 4: SqlException 547 – vi phạm khóa ngoại, có hướng xử lý riêng."));

            form.RunDemoMissingTableError();
            shots.Add(Save(form, folder, "05_LoiCSDL_BangKhongTonTai.png",
                "Bài 4: SqlException 208 – bảng không tồn tại."));

            form.RunDemoUnexpectedError();
            shots.Add(Save(form, folder, "06_LoiHeThong_Exception.png",
                "Bài 4/6: Exception không lường trước được phân loại và ghi log."));

            form.RunDemoValidation();
            shots.Add(Save(form, folder, "07_KiemTraNhieuLoi.png",
                "Bài 2: ValidationResult liệt kê toàn bộ lỗi trước khi ghi CSDL."));

            form.SelectTab(2);
            form.WriteSampleLogs();
            form.RefreshLogs();
            shots.Add(Save(form, folder, "08_NhatKy_Logging.png",
                "Bài 3: nhật ký có cấu trúc INFO/WARN/ERROR, xem chi tiết và xuất CSV."));

            AppLogger.RotateNow();
            form.RefreshLogs();
            shots.Add(Save(form, folder, "09_NhatKy_XoayVong.png",
                "Bài 7: xoay vòng nhật ký theo dung lượng, dọn tệp cũ theo số ngày."));

            form.SelectTab(3);
            form.RefreshSettingsView();
            shots.Add(Save(form, folder, "10_CauHinh_AppConfig.png",
                "Bài 5: đọc App.config – connection string đã che, ReportFolder, LogFolder, LogLevel."));

            form.TestProtectedConfiguration();
            shots.Add(Save(form, folder, "11_BaoVe_ProtectedConfiguration.png",
                "Bài 8: thử ProtectedConfiguration trên .NET 10 và ghi nhận kết quả."));

            form.ProtectConnectionForDemo();
            shots.Add(Save(form, folder, "12_BaoVe_DPAPI.png",
                "Bài 8: bảo vệ chuỗi kết nối bằng DPAPI – Config/connection.protected."));
            form.RemoveProtectionForDemo();
            form.RefreshSettingsView();

            form.SelectTab(4);
            form.RunPreflight();
            shots.Add(Save(form, folder, "13_KiemTraTruocKhiChay.png",
                "Bài 9: màn hình kiểm tra trước khi chạy với ĐẠT / CẢNH BÁO / LỖI."));

            form.SelectTab(5);
            form.RefreshDeploymentView();
            shots.Add(Save(form, folder, "14_TrienKhai.png",
                "Bài 10: thông tin máy đích, gói Publish và danh mục kiểm thử triển khai."));

            form.ExportDeploymentReportForDemo();
            shots.Add(Save(form, folder, "15_BienBanKiemThuTrienKhai.png",
                "Bài 10: xuất biên bản kiểm thử triển khai vào thư mục Reports."));

            var manifest = new StringBuilder();
            manifest.AppendLine("DANH MỤC ẢNH CHỤP – LAB 15");
            manifest.AppendLine("Sinh viên: Nguyễn Quang Dũng – MSSV 24003351");
            manifest.AppendLine("Thời điểm: " + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
            manifest.AppendLine(new string('-', 100));
            foreach (var shot in shots)
            {
                manifest.AppendLine(shot.FileName);
                manifest.AppendLine("    " + shot.Description);
            }
            File.WriteAllText(Path.Combine(folder, "DanhMucAnh.txt"), manifest.ToString(), new UTF8Encoding(true));

            AppLogger.Info($"Đã chụp {shots.Count} ảnh minh họa vào {folder}.", LogCategories.App);
            Console.WriteLine($"CAPTURED: {shots.Count} screenshots -> {folder}");
            return 0;
        }
        catch (Exception ex)
        {
            AppLogger.Fatal("Chụp ảnh minh họa thất bại.", LogCategories.App, ex);
            Console.WriteLine("CAPTURE_ERROR: " + ex.Message);
            return 1;
        }
        finally
        {
            if (form != null)
            {
                try
                {
                    form.Close();
                    form.Dispose();
                }
                catch
                {
                    // Bỏ qua.
                }
            }
        }
    }

    private static Shot Save(MainForm form, string folder, string fileName, string description)
    {
        var path = Path.Combine(folder, fileName);
        form.CaptureCurrentTab(path);
        Console.WriteLine("  saved " + fileName);
        return new Shot(fileName, description);
    }
}
