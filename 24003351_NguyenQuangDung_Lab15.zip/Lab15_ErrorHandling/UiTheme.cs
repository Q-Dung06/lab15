using System.Drawing.Drawing2D;

namespace Lab15_ErrorHandling;

/// <summary>Bảng màu, font và các hàm tạo điều khiển dùng chung cho giao diện.</summary>
internal static class UiTheme
{
    public static readonly Color Background = Color.FromArgb(244, 246, 251);
    public static readonly Color Surface = Color.White;
    public static readonly Color Header = Color.FromArgb(22, 50, 79);
    public static readonly Color HeaderAccent = Color.FromArgb(37, 99, 235);
    public static readonly Color Primary = Color.FromArgb(31, 78, 121);
    public static readonly Color Accent = Color.FromArgb(37, 99, 235);
    public static readonly Color Success = Color.FromArgb(21, 128, 61);
    public static readonly Color SuccessSoft = Color.FromArgb(220, 252, 231);
    public static readonly Color Warning = Color.FromArgb(180, 83, 9);
    public static readonly Color WarningSoft = Color.FromArgb(254, 249, 195);
    public static readonly Color Danger = Color.FromArgb(185, 28, 28);
    public static readonly Color DangerSoft = Color.FromArgb(254, 226, 226);
    public static readonly Color Muted = Color.FromArgb(100, 116, 139);
    public static readonly Color Border = Color.FromArgb(226, 232, 240);
    public static readonly Color AlternateRow = Color.FromArgb(249, 250, 252);

    public static readonly Font Body = new("Segoe UI", 9.75f);
    public static readonly Font BodyBold = new("Segoe UI", 9.75f, FontStyle.Bold);
    public static readonly Font Small = new("Segoe UI", 8.5f);
    public static readonly Font SmallBold = new("Segoe UI", 8.5f, FontStyle.Bold);
    public static readonly Font Title = new("Segoe UI", 15f, FontStyle.Bold);
    public static readonly Font Subtitle = new("Segoe UI", 9f);
    public static readonly Font Mono = new("Consolas", 9.5f);

    public static Button Button(string text, Color? background = null, Color? foreground = null, EventHandler? onClick = null)
    {
        var button = new Button
        {
            Text = text,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            MinimumSize = new Size(90, 34),
            Padding = new Padding(12, 0, 12, 0),
            FlatStyle = FlatStyle.Flat,
            BackColor = background ?? Surface,
            ForeColor = foreground ?? Primary,
            Font = BodyBold,
            Cursor = Cursors.Hand,
            Margin = new Padding(0, 0, 8, 0),
            UseVisualStyleBackColor = false
        };
        button.FlatAppearance.BorderSize = background.HasValue ? 0 : 1;
        button.FlatAppearance.BorderColor = Border;
        button.FlatAppearance.MouseOverBackColor = background.HasValue
            ? ControlPaint.Light(background.Value, 0.08f)
            : Color.FromArgb(241, 245, 249);
        if (onClick != null) button.Click += onClick;
        return button;
    }

    public static Label Label(string text, Font? font = null, Color? color = null) => new()
    {
        Text = text,
        AutoSize = true,
        Font = font ?? Body,
        ForeColor = color ?? Color.FromArgb(31, 41, 55),
        Margin = new Padding(0),
        BackColor = Color.Transparent
    };

    public static TextBox TextBox(string placeholder = "")
    {
        return new TextBox
        {
            PlaceholderText = placeholder,
            Font = Body,
            BorderStyle = BorderStyle.FixedSingle,
            BackColor = Surface,
            ForeColor = Color.FromArgb(31, 41, 55),
            AutoSize = false,
            Height = 28,
            Margin = new Padding(0)
        };
    }

    public static ComboBox ComboBox()
    {
        return new ComboBox
        {
            Font = Body,
            DropDownStyle = ComboBoxStyle.DropDownList,
            FlatStyle = FlatStyle.Flat,
            BackColor = Surface,
            Height = 28,
            Margin = new Padding(0)
        };
    }

    public static Panel Card(int padding = 16)
    {
        var panel = new Panel
        {
            BackColor = Surface,
            Padding = new Padding(padding),
            Margin = new Padding(0)
        };
        panel.Paint += (_, e) =>
        {
            using var pen = new Pen(Border);
            e.Graphics.DrawRectangle(pen, 0, 0, panel.Width - 1, panel.Height - 1);
        };
        return panel;
    }

    public static Label SectionTitle(string text) => new()
    {
        Text = text,
        AutoSize = true,
        Font = new Font("Segoe UI", 11f, FontStyle.Bold),
        ForeColor = Primary,
        Margin = new Padding(0, 0, 0, 10)
    };

    public static void StyleGrid(DataGridView grid, bool readOnly = true)
    {
        grid.BackgroundColor = Surface;
        grid.BorderStyle = BorderStyle.None;
        grid.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
        grid.GridColor = Border;
        grid.RowHeadersVisible = false;
        grid.AllowUserToAddRows = false;
        grid.AllowUserToDeleteRows = false;
        grid.AllowUserToResizeRows = false;
        grid.ReadOnly = readOnly;
        grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        grid.MultiSelect = false;
        grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;
        grid.EnableHeadersVisualStyles = false;
        grid.ColumnHeadersHeight = 36;
        grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
        grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(241, 245, 249);
        grid.ColumnHeadersDefaultCellStyle.ForeColor = Color.FromArgb(51, 65, 85);
        grid.ColumnHeadersDefaultCellStyle.Font = SmallBold;
        grid.ColumnHeadersDefaultCellStyle.SelectionBackColor = Color.FromArgb(241, 245, 249);
        grid.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
        grid.ColumnHeadersDefaultCellStyle.Padding = new Padding(6, 0, 4, 0);
        grid.DefaultCellStyle.Font = Body;
        grid.DefaultCellStyle.BackColor = Surface;
        grid.DefaultCellStyle.ForeColor = Color.FromArgb(31, 41, 55);
        grid.DefaultCellStyle.SelectionBackColor = Color.FromArgb(219, 234, 254);
        grid.DefaultCellStyle.SelectionForeColor = Color.FromArgb(15, 23, 42);
        grid.DefaultCellStyle.Padding = new Padding(6, 0, 4, 0);
        grid.AlternatingRowsDefaultCellStyle.BackColor = AlternateRow;
        grid.RowTemplate.Height = 28;
        grid.RowTemplate.MinimumHeight = 26;
    }

    public static TabControl Tabs()
    {
        var tabs = new TabControl
        {
            Dock = DockStyle.Fill,
            Font = BodyBold,
            Padding = new Point(18, 6),
            SizeMode = TabSizeMode.Fixed,
            ItemSize = new Size(178, 34),
            Appearance = TabAppearance.Normal
        };
        return tabs;
    }

    public static void RoundedRegion(Control control, int radius = 8)
    {
        using var path = new GraphicsPath();
        var bounds = new Rectangle(0, 0, control.Width, control.Height);
        path.AddArc(bounds.Left, bounds.Top, radius, radius, 180, 90);
        path.AddArc(bounds.Right - radius, bounds.Top, radius, radius, 270, 90);
        path.AddArc(bounds.Right - radius, bounds.Bottom - radius, radius, radius, 0, 90);
        path.AddArc(bounds.Left, bounds.Bottom - radius, radius, radius, 90, 90);
        path.CloseFigure();
        control.Region = new Region(path);
    }

    public static void SetDoubleBuffered(Control control)
    {
        typeof(Control)
            .GetProperty("DoubleBuffered", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic)
            ?.SetValue(control, true);
    }
}
