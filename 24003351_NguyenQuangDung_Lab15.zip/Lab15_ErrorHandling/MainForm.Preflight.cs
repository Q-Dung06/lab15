using System.Diagnostics;
using Lab15.BUS;

namespace Lab15_ErrorHandling;

public partial class MainForm
{
    private DataGridView _preflightGrid = null!;
    private Label _lblPreflightOverall = null!;
    private Label _lblPreflightSummary = null!;
    private Label _lblPreflightTime = null!;
    private PreflightReport? _lastPreflight;

    private void BuildPreflightTab()
    {
        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 3,
            BackColor = UiTheme.Background,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 100));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 46));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        root.Controls.Add(BuildPreflightBanner(), 0, 0);
        root.Controls.Add(BuildPreflightToolbar(), 0, 1);
        root.Controls.Add(BuildPreflightGridCard(), 0, 2);
        _tabPreflight.Controls.Add(root);

        UpdatePreflightPlaceholder();
    }

    private Control BuildPreflightBanner()
    {
        var card = UiTheme.Card(16);
        card.Dock = DockStyle.Fill;
        card.Margin = new Padding(0, 0, 0, 10);
        card.Padding = new Padding(16, 12, 16, 12);

        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 2,
            BackColor = UiTheme.Surface,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 300));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        _lblPreflightOverall = new Label
        {
            Dock = DockStyle.Fill,
            Font = new Font("Segoe UI", 18f, FontStyle.Bold),
            ForeColor = UiTheme.Muted,
            TextAlign = ContentAlignment.MiddleLeft,
            Text = "CHƯA KIỂM TRA"
        };
        _lblPreflightSummary = new Label
        {
            Dock = DockStyle.Fill,
            Font = UiTheme.Body,
            ForeColor = UiTheme.Muted,
            TextAlign = ContentAlignment.TopLeft,
            Text = "Nhấn “Chạy kiểm tra” để đánh giá cấu hình, quyền ghi, CSDL và gói triển khai."
        };
        _lblPreflightTime = new Label
        {
            Dock = DockStyle.Fill,
            Font = UiTheme.Small,
            ForeColor = UiTheme.Muted,
            TextAlign = ContentAlignment.MiddleRight,
            Padding = new Padding(0, 0, 4, 0)
        };

        layout.Controls.Add(_lblPreflightOverall, 0, 0);
        layout.Controls.Add(_lblPreflightSummary, 0, 1);
        layout.Controls.Add(_lblPreflightTime, 1, 0);
        layout.SetRowSpan(_lblPreflightTime, 2);
        card.Controls.Add(layout);
        return card;
    }

    private Control BuildPreflightToolbar()
    {
        var toolbar = new Panel
        {
            Dock = DockStyle.Fill,
            BackColor = UiTheme.Background,
            Padding = new Padding(0, 2, 0, 6)
        };
        var flow = new FlowLayoutPanel
        {
            Dock = DockStyle.Left,
            AutoSize = true,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false,
            BackColor = Color.Transparent,
            Padding = new Padding(0),
            Margin = new Padding(0)
        };
        var run = UiTheme.Button("Chạy kiểm tra", UiTheme.Accent, Color.White, (_, _) => RunPreflight());
        var export = UiTheme.Button("Xuất báo cáo", null, null, (_, _) => ExportPreflightReport());
        var reports = UiTheme.Button("Mở thư mục Reports", null, null, (_, _) => OpenFolder(_config.ReportFolder));
        run.Margin = new Padding(0, 2, 6, 0);
        export.Margin = new Padding(0, 2, 6, 0);
        reports.Margin = new Padding(0, 2, 6, 0);
        flow.Controls.AddRange(new Control[] { run, export, reports });

        var note = new Label
        {
            Dock = DockStyle.Right,
            Width = 650,
            TextAlign = ContentAlignment.MiddleRight,
            Font = UiTheme.Small,
            ForeColor = UiTheme.Muted,
            Padding = new Padding(0, 4, 2, 0),
            Text = "Kiểm tra trước khi chạy (Bài 9) · LỖI sẽ chặn thao tác nghiệp vụ, CẢNH BÁO chỉ nhắc nhở."
        };

        toolbar.Controls.Add(flow);
        toolbar.Controls.Add(note);
        return toolbar;
    }

    private Control BuildPreflightGridCard()
    {
        var card = UiTheme.Card(12);
        card.Dock = DockStyle.Fill;
        card.Padding = new Padding(12);

        _preflightGrid = new DataGridView { Dock = DockStyle.Fill };
        UiTheme.StyleGrid(_preflightGrid);
        _preflightGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        _preflightGrid.RowTemplate.Height = 34;
        _preflightGrid.DefaultCellStyle.WrapMode = DataGridViewTriState.False;
        _preflightGrid.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = "HangMuc", HeaderText = "Hạng mục", FillWeight = 170, MinimumWidth = 150,
            ReadOnly = true, SortMode = DataGridViewColumnSortMode.NotSortable
        });
        _preflightGrid.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = "KetQua", HeaderText = "Kết quả", FillWeight = 80, MinimumWidth = 80,
            ReadOnly = true, SortMode = DataGridViewColumnSortMode.NotSortable
        });
        _preflightGrid.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = "ThongTin", HeaderText = "Thông tin", FillWeight = 300, MinimumWidth = 240,
            ReadOnly = true, SortMode = DataGridViewColumnSortMode.NotSortable
        });
        _preflightGrid.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = "ChiTiet", HeaderText = "Chi tiết", FillWeight = 300, MinimumWidth = 220,
            ReadOnly = true, SortMode = DataGridViewColumnSortMode.NotSortable
        });
        _preflightGrid.CellFormatting += (_, e) =>
        {
            if (e.RowIndex < 0 || e.ColumnIndex != 1) return;
            var value = Convert.ToString(e.Value) ?? "";
            e.CellStyle!.Font = UiTheme.BodyBold;
            e.CellStyle.ForeColor = value switch
            {
                "ĐẠT" => UiTheme.Success,
                "CẢNH BÁO" => UiTheme.Warning,
                "LỖI" => UiTheme.Danger,
                _ => UiTheme.Muted
            };
        };

        card.Controls.Add(_preflightGrid);
        return card;
    }

    public PreflightReport? RunPreflight()
    {
        try
        {
            SetStatus("Đang kiểm tra môi trường trước khi chạy…");
            Application.DoEvents();
            var service = new PreflightService(_config);
            _lastPreflight = service.RunAll();
            UpdatePreflightUi(_lastPreflight);
            SetStatus("Kiểm tra trước khi chạy: " + _lastPreflight.OverallText + ".", !_lastPreflight.CanRun);
            return _lastPreflight;
        }
        catch (Exception ex)
        {
            ErrorPresenter.Show(this, ex, "Kiểm tra trước khi chạy", _silent);
            return null;
        }
    }

    private void UpdatePreflightUi(PreflightReport report)
    {
        _lblPreflightOverall.Text = report.Overall switch
        {
            CheckStatus.Pass => "✔  " + report.OverallText,
            CheckStatus.Warning => "!  " + report.OverallText,
            _ => "✖  " + report.OverallText
        };
        _lblPreflightOverall.ForeColor = report.Overall switch
        {
            CheckStatus.Pass => UiTheme.Success,
            CheckStatus.Warning => UiTheme.Warning,
            _ => UiTheme.Danger
        };
        _lblPreflightSummary.Text =
            $"Đạt {report.PassCount} · Cảnh báo {report.WarningCount} · Lỗi {report.FailCount} · " +
            (report.CanRun ? "Có thể chạy các thao tác nghiệp vụ." : "Cần khắc phục các hạng mục LỖI trước khi chạy.");
        _lblPreflightTime.Text = "Thời điểm: " + report.CheckedAt.ToString("dd/MM/yyyy HH:mm:ss");

        _preflightGrid.Rows.Clear();
        foreach (var check in report.Checks)
        {
            var index = _preflightGrid.Rows.Add(check.Name, check.StatusText, check.Message, check.Detail ?? "");
            var row = _preflightGrid.Rows[index];
            row.Cells["ChiTiet"].ToolTipText = check.Detail ?? "";
            if (check.Status == CheckStatus.Fail)
                row.DefaultCellStyle.BackColor = UiTheme.DangerSoft;
            else if (check.Status == CheckStatus.Warning)
                row.DefaultCellStyle.BackColor = UiTheme.WarningSoft;
        }
    }

    private void UpdatePreflightPlaceholder()
    {
        if (_lblPreflightOverall == null) return;
        _lblPreflightOverall.Text = "CHƯA KIỂM TRA";
        _lblPreflightOverall.ForeColor = UiTheme.Muted;
        _lblPreflightSummary.Text = "Nhấn “Chạy kiểm tra” để đánh giá cấu hình, quyền ghi, CSDL và gói triển khai.";
        _lblPreflightTime.Text = "";
        _preflightGrid.Rows.Clear();
    }

    private void ExportPreflightReport()
    {
        try
        {
            if (_lastPreflight == null)
            {
                ShowInfo("Chưa có kết quả kiểm tra. Hãy chạy kiểm tra trước.", "Thiếu dữ liệu");
                return;
            }

            var path = StudentExportService.BuildFilePath(_config.ReportFolder, "KiemTraTruocKhiChay", "txt");
            StudentExportService.ExportTextReport(_lastPreflight.ToText(), path);
            ShowInfo("Đã xuất báo cáo kiểm tra:\n" + path, "Xuất báo cáo");
        }
        catch (Exception ex)
        {
            ErrorPresenter.Show(this, ex, "Xuất báo cáo kiểm tra", _silent);
        }
    }
}
