using System.Diagnostics;
using Lab15.BUS;
using Lab15.DAL;

namespace Lab15_ErrorHandling;

public partial class MainForm
{
    private DataGridView _settingsGrid = null!;
    private TextBox _txtConnectionMasked = null!;
    private Label _lblProtectionStatus = null!;
    private Label _lblProtectionFile = null!;
    private Label _lblProtectedConfigResult = null!;
    private Label _lblConfigPath = null!;

    private void BuildSettingsTab()
    {
        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 1,
            BackColor = UiTheme.Background,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 55));
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 45));
        root.Controls.Add(BuildConfigValuesCard(), 0, 0);
        root.Controls.Add(BuildProtectionArea(), 1, 0);
        _tabSettings.Controls.Add(root);

        RefreshSettingsView();
    }

    private Control BuildConfigValuesCard()
    {
        var card = UiTheme.Card(16);
        card.Dock = DockStyle.Fill;
        card.Margin = new Padding(0, 0, 12, 0);
        card.Padding = new Padding(16);

        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 4,
            BackColor = UiTheme.Surface,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 34));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 46));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 46));

        var title = UiTheme.SectionTitle("Tệp cấu hình & appSettings (Bài 5)");
        title.Dock = DockStyle.Fill;

        _lblConfigPath = new Label
        {
            Dock = DockStyle.Fill,
            AutoSize = false,
            AutoEllipsis = true,
            Font = UiTheme.Small,
            ForeColor = UiTheme.Muted,
            BackColor = Color.FromArgb(248, 250, 252),
            Padding = new Padding(8, 6, 8, 6),
            TextAlign = ContentAlignment.MiddleLeft,
            Margin = new Padding(0, 0, 0, 8)
        };

        _settingsGrid = new DataGridView { Dock = DockStyle.Fill };
        UiTheme.StyleGrid(_settingsGrid);
        _settingsGrid.RowTemplate.Height = 30;
        _settingsGrid.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = "Khoa", HeaderText = "Khóa cấu hình", Width = 210,
            ReadOnly = true, SortMode = DataGridViewColumnSortMode.NotSortable
        });
        _settingsGrid.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = "GiaTri", HeaderText = "Giá trị đang dùng",
            AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill,
            MinimumWidth = 180, ReadOnly = true,
            SortMode = DataGridViewColumnSortMode.NotSortable
        });

        var buttons = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false,
            BackColor = UiTheme.Surface,
            Padding = new Padding(0, 6, 0, 0),
            Margin = new Padding(0)
        };
        var open = UiTheme.Button("Mở App.config", UiTheme.Accent, Color.White, (_, _) => OpenConfigFile());
        var reload = UiTheme.Button("Tải lại cấu hình", null, null, (_, _) => ReloadConfiguration());
        var reports = UiTheme.Button("Mở thư mục Reports", null, null, (_, _) => OpenFolder(_config.ReportFolder));
        open.Margin = new Padding(0, 0, 6, 0);
        reload.Margin = new Padding(0, 0, 6, 0);
        reports.Margin = new Padding(0, 0, 6, 0);
        buttons.Controls.AddRange(new Control[] { open, reload, reports });

        layout.Controls.Add(title, 0, 0);
        layout.Controls.Add(_lblConfigPath, 0, 1);
        layout.Controls.Add(_settingsGrid, 0, 2);
        layout.Controls.Add(buttons, 0, 3);
        card.Controls.Add(layout);
        return card;
    }

    private Control BuildProtectionArea()
    {
        var area = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 2,
            BackColor = UiTheme.Background,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };
        area.RowStyles.Add(new RowStyle(SizeType.Absolute, 258));
        area.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        area.Controls.Add(BuildConnectionCard(), 0, 0);
        area.Controls.Add(BuildProtectionCard(), 0, 1);
        return area;
    }

    private Control BuildConnectionCard()
    {
        var card = UiTheme.Card(16);
        card.Dock = DockStyle.Fill;
        card.Margin = new Padding(0, 0, 0, 10);
        card.Padding = new Padding(16);

        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 4,
            BackColor = UiTheme.Surface,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 34));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 96));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        var title = UiTheme.SectionTitle("Chuỗi kết nối QLSinhVien");
        title.Dock = DockStyle.Fill;

        _txtConnectionMasked = new TextBox
        {
            Dock = DockStyle.Fill,
            Multiline = true,
            ReadOnly = true,
            ScrollBars = ScrollBars.Vertical,
            Font = UiTheme.Mono,
            BackColor = Color.FromArgb(248, 250, 252),
            ForeColor = Color.FromArgb(30, 41, 59),
            BorderStyle = BorderStyle.FixedSingle,
            Text = "(đang tải…)"
        };

        _lblProtectionStatus = new Label
        {
            Dock = DockStyle.Fill,
            Font = UiTheme.BodyBold,
            TextAlign = ContentAlignment.MiddleLeft,
            Padding = new Padding(2, 0, 0, 0)
        };

        _lblProtectionFile = new Label
        {
            Dock = DockStyle.Fill,
            AutoSize = false,
            AutoEllipsis = true,
            Font = UiTheme.Small,
            ForeColor = UiTheme.Muted,
            TextAlign = ContentAlignment.TopLeft,
            Padding = new Padding(2, 0, 0, 0)
        };

        layout.Controls.Add(title, 0, 0);
        layout.Controls.Add(_txtConnectionMasked, 0, 1);
        layout.Controls.Add(_lblProtectionStatus, 0, 2);
        layout.Controls.Add(_lblProtectionFile, 0, 3);
        card.Controls.Add(layout);
        return card;
    }

    private Control BuildProtectionCard()
    {
        var card = UiTheme.Card(16);
        card.Dock = DockStyle.Fill;
        card.Padding = new Padding(16);

        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 4,
            BackColor = UiTheme.Surface,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 34));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 64));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 82));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        var title = UiTheme.SectionTitle("Bảo vệ thông tin nhạy cảm (Bài 8)");
        title.Dock = DockStyle.Fill;

        var note = new Label
        {
            Dock = DockStyle.Fill,
            AutoSize = false,
            Font = UiTheme.Small,
            ForeColor = UiTheme.Muted,
            Text = "Chuẩn .NET Framework: mã hóa connectionStrings bằng ProtectedConfiguration. " +
                   "Lab 15 thử trên máy này; nếu thiếu hỗ trợ sẽ dùng DPAPI (Config/connection.protected).",
            Padding = new Padding(0, 0, 0, 6)
        };

        var buttons = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = true,
            BackColor = UiTheme.Surface,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };
        var protect = UiTheme.Button("Bảo vệ bằng DPAPI", UiTheme.Accent, Color.White, (_, _) => ProtectConnection());
        var remove = UiTheme.Button("Gỡ bảo vệ", null, null, (_, _) => RemoveProtection());
        var test = UiTheme.Button("Thử ProtectedConfiguration", null, null, (_, _) => TestProtectedConfiguration());
        protect.Margin = new Padding(0, 0, 6, 6);
        remove.Margin = new Padding(0, 0, 6, 6);
        test.Margin = new Padding(0, 0, 6, 6);
        buttons.Controls.AddRange(new Control[] { protect, remove, test });

        _lblProtectedConfigResult = new Label
        {
            Dock = DockStyle.Fill,
            AutoSize = false,
            Font = UiTheme.Small,
            ForeColor = UiTheme.Muted,
            BackColor = Color.FromArgb(248, 250, 252),
            Padding = new Padding(10, 8, 10, 8),
            TextAlign = ContentAlignment.TopLeft,
            Text = "Chưa thực hiện thử nghiệm ProtectedConfiguration.\n" +
                   "Nhấn “Thử ProtectedConfiguration” để xem nền tảng hiện tại có hỗ trợ hay không."
        };

        layout.Controls.Add(title, 0, 0);
        layout.Controls.Add(note, 0, 1);
        layout.Controls.Add(buttons, 0, 2);
        layout.Controls.Add(_lblProtectedConfigResult, 0, 3);
        card.Controls.Add(layout);
        return card;
    }

    public void RefreshSettingsView()
    {
        if (_settingsGrid == null) return;

        _settingsGrid.Rows.Clear();
        foreach (var item in _config.DisplaySettings)
            _settingsGrid.Rows.Add(item.Key, item.Value);

        _lblConfigPath.Text = "Đang dùng: " + _config.ConfigFilePath;
        _txtConnectionMasked.Text = _config.GetMaskedConnectionString();

        var isProtected = ConnectionStringProtector.IsProtected;
        _lblProtectionStatus.Text = isProtected
            ? "●  Chuỗi kết nối đang được bảo vệ bằng DPAPI"
            : "○  Chuỗi kết nối đang đọc trực tiếp từ App.config (chưa mã hóa)";
        _lblProtectionStatus.ForeColor = isProtected ? UiTheme.Success : UiTheme.Warning;
        _lblProtectionFile.Text = "Tệp bảo vệ: " + ConnectionStringProtector.ProtectedFilePath +
                                  (isProtected ? " (đang tồn tại)" : " (chưa có)");
    }

    private void OpenConfigFile()
    {
        try
        {
            var path = _config.ConfigFilePath;
            if (!File.Exists(path))
            {
                ShowInfo("Không tìm thấy tệp cấu hình:\n" + path, "Thiếu tệp");
                return;
            }
            Process.Start(new ProcessStartInfo { FileName = path, UseShellExecute = true });
        }
        catch (Exception ex)
        {
            ErrorPresenter.Show(this, ex, "Mở App.config", _silent);
        }
    }

    private void OpenFolder(string folder)
    {
        try
        {
            Directory.CreateDirectory(folder);
            Process.Start(new ProcessStartInfo { FileName = folder, UseShellExecute = true });
        }
        catch (Exception ex)
        {
            ErrorPresenter.Show(this, ex, "Mở thư mục", _silent);
        }
    }

    private void ReloadConfiguration()
    {
        try
        {
            _config = AppConfig.Reload();
            AppLogger.Configure(_config);
            RefreshSettingsView();
            RefreshStudentGrid();
            ShowInfo("Đã tải lại cấu hình từ App.config.", "Cấu hình");
            AppLogger.Info("Tải lại cấu hình.", LogCategories.Config, _config.Describe());
        }
        catch (Exception ex)
        {
            ErrorPresenter.Show(this, ex, "Tải lại cấu hình", _silent);
        }
    }

    private void ProtectConnection()
    {
        try
        {
            var connectionString = _config.GetConnectionString();
            var path = ConnectionStringProtector.Protect(connectionString);
            AppLogger.Info("Đã bảo vệ chuỗi kết nối bằng DPAPI.", LogCategories.Security, path);
            RefreshSettingsView();
            _lblProtectedConfigResult.BackColor = UiTheme.SuccessSoft;
            _lblProtectedConfigResult.ForeColor = UiTheme.Success;
            _lblProtectedConfigResult.Text =
                "Đã mã hóa chuỗi kết nối bằng DPAPI (DataProtectionScope.CurrentUser).\n" +
                "Tệp: " + path + "\n" +
                "Lưu ý: tệp chỉ giải mã được trên đúng tài khoản Windows hiện tại.";
            ShowInfo("Đã bảo vệ chuỗi kết nối bằng DPAPI.\n" + path, "Bảo vệ cấu hình");
        }
        catch (Exception ex)
        {
            ErrorPresenter.Show(this, ex, "Bảo vệ chuỗi kết nối", _silent);
        }
    }

    private void RemoveProtection()
    {
        try
        {
            var removed = ConnectionStringProtector.RemoveProtection();
            AppLogger.Warn(removed ? "Đã gỡ bảo vệ chuỗi kết nối." : "Không có tệp bảo vệ để gỡ.",
                LogCategories.Security);
            RefreshSettingsView();
            _lblProtectedConfigResult.BackColor = UiTheme.WarningSoft;
            _lblProtectedConfigResult.ForeColor = UiTheme.Warning;
            _lblProtectedConfigResult.Text = removed
                ? "Đã gỡ tệp Config/connection.protected. Ứng dụng quay lại đọc chuỗi kết nối từ App.config."
                : "Không có tệp Config/connection.protected để gỡ.";
            ShowInfo(removed ? "Đã gỡ bảo vệ chuỗi kết nối." : "Chưa có tệp bảo vệ.", "Bảo vệ cấu hình");
        }
        catch (Exception ex)
        {
            ErrorPresenter.Show(this, ex, "Gỡ bảo vệ chuỗi kết nối", _silent);
        }
    }

    public (bool Supported, string Message) TestProtectedConfiguration()
    {
        var result = ConnectionStringProtector.TryProtectAppConfigSection();
        _lblProtectedConfigResult.BackColor = result.Supported ? UiTheme.SuccessSoft : UiTheme.WarningSoft;
        _lblProtectedConfigResult.ForeColor = result.Supported ? UiTheme.Success : UiTheme.Warning;
        _lblProtectedConfigResult.Text = result.Message;
        AppLogger.Warn("Thử ProtectedConfiguration: " + result.Message, LogCategories.Security);
        SetStatus("Thử ProtectedConfiguration: " + (result.Supported ? "hỗ trợ" : "không hỗ trợ") + ".", false);
        return result;
    }

    public void ProtectConnectionForDemo() => ProtectConnection();

    public void RemoveProtectionForDemo() => RemoveProtection();
}
