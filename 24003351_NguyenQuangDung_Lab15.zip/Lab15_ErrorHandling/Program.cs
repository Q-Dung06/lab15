using System.Text;
using Lab15.BUS;

namespace Lab15_ErrorHandling;

internal static class Program
{
    private static bool _handlingGlobalError;

    public static bool SilentMode { get; private set; }

    [STAThread]
    private static int Main(string[] args)
    {
        // Phải đặt trước lần đọc ConfigurationManager đầu tiên.
        var localConfig = Path.Combine(AppContext.BaseDirectory, "App.config");
        if (File.Exists(localConfig))
            Environment.SetEnvironmentVariable("APP_CONFIG_FILE", localConfig);

        try
        {
            Console.OutputEncoding = Encoding.UTF8;
        }
        catch
        {
            // Ứng dụng WinExe có thể không có console thật.
        }

        Application.SetHighDpiMode(HighDpiMode.DpiUnaware);
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);

        var mode = args.Length > 0 ? args[0].Trim().ToLowerInvariant() : "";
        var target = args.Length > 1 ? args[1] : null;
        SilentMode = mode is "--test" or "--capture" or "--protocol";

        InitializeRuntime();

        if (mode == "--test") return SelfTestRunner.Run(target);
        if (mode == "--capture") return CaptureRunner.Run(target);
        if (mode == "--protocol") return RunProtocol(target);

        AttachGlobalHandlers();
        try
        {
            Application.Run(new MainForm(silent: false));
            return 0;
        }
        catch (Exception ex)
        {
            HandleGlobalException(ex, "Khởi động giao diện");
            return 1;
        }
    }

    private static void InitializeRuntime()
    {
        try
        {
            var config = AppConfig.Current;
            AppLogger.Configure(config);
            foreach (var error in config.EnsureDirectories())
                AppLogger.Warn(error, LogCategories.Config);
            AppLogger.Info("Khởi động ứng dụng Lab 15.", LogCategories.App,
                $"Version={typeof(Program).Assembly.GetName().Version}; BaseDirectory={AppContext.BaseDirectory}; " +
                $"Config={config.ConfigFilePath}; Protected={config.IsProtectedConnection}; LogLevel={config.LogLevelText}");
        }
        catch (Exception ex)
        {
            var fallback = Path.Combine(AppContext.BaseDirectory, "Logs");
            AppLogger.Configure(fallback, 2048, 30, LogLevel.Info);
            AppLogger.Fatal("Không khởi tạo được cấu hình ứng dụng.", LogCategories.Config, ex);
            if (!SilentMode)
            {
                MessageBox.Show(
                    "Không đọc được cấu hình App.config.\n\n" + ex.Message +
                    "\n\nỨng dụng sẽ dùng giá trị mặc định. Chi tiết: " + AppLogger.CurrentFile,
                    "Lỗi cấu hình", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }

    private static int RunProtocol(string? folder)
    {
        try
        {
            var config = AppConfig.Current;
            var preflight = new PreflightService(config).RunAll();
            var targetFolder = string.IsNullOrWhiteSpace(folder) ? config.ReportFolder : Path.GetFullPath(folder);
            Directory.CreateDirectory(targetFolder);

            var deploymentPath = DeploymentService.WriteReport(targetFolder, config, preflight);
            var preflightPath = StudentExportService.ExportTextReport(
                preflight.ToText(),
                Path.Combine(targetFolder, "KiemTraTruocKhiChay.txt"));

            Console.WriteLine("PREFLIGHT: " + preflight.OverallText);
            Console.WriteLine("REPORT: " + deploymentPath);
            Console.WriteLine("PREFLIGHT_REPORT: " + preflightPath);
            return preflight.CanRun ? 0 : 1;
        }
        catch (Exception ex)
        {
            AppLogger.Fatal("Xuất biên bản triển khai thất bại.", LogCategories.Deployment, ex);
            Console.WriteLine("ERROR: " + ex.Message);
            return 1;
        }
    }

    private static void AttachGlobalHandlers()
    {
        Application.ThreadException += (_, e) =>
            HandleGlobalException(e.Exception, "Application.ThreadException");

        AppDomain.CurrentDomain.UnhandledException += (_, e) =>
        {
            if (e.ExceptionObject is Exception exception)
                HandleGlobalException(exception, "AppDomain.UnhandledException");
        };

        TaskScheduler.UnobservedTaskException += (_, e) =>
        {
            HandleGlobalException(e.Exception, "TaskScheduler.UnobservedTaskException");
            e.SetObserved();
        };
    }

    /// <summary>
    /// Bài 6 – Bộ xử lý ngoại lệ toàn cục: ghi log FATAL và hiển thị thông điệp
    /// cuối cùng, tránh để ứng dụng thoát mà không có dấu vết.
    /// </summary>
    private static void HandleGlobalException(Exception exception, string source)
    {
        if (_handlingGlobalError) return;
        _handlingGlobalError = true;

        try
        {
            AppLogger.Fatal($"Ngoại lệ toàn cục ({source}): {exception.Message}",
                LogCategories.Global, exception,
                $"Source={source}; Type={exception.GetType().FullName}");

            if (!SilentMode)
            {
                var text = "Ứng dụng gặp lỗi không mong muốn.\n\n" +
                           exception.Message + "\n\n" +
                           "Chi tiết đã được ghi vào nhật ký:\n" + AppLogger.CurrentFile +
                           "\n\nỨng dụng có thể tiếp tục chạy. Nếu lỗi lặp lại, hãy gửi tệp nhật ký cho giảng viên.";
                MessageBox.Show(text, "Lỗi hệ thống (global handler)",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                Console.WriteLine("GLOBAL_ERROR: " + exception.GetType().Name + ": " + exception.Message);
            }
        }
        catch
        {
            // Không để bộ xử lý lỗi tự gây lỗi.
        }
        finally
        {
            _handlingGlobalError = false;
        }
    }
}
