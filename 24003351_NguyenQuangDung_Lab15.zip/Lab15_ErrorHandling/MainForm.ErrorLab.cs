using System.Data.SqlClient;
using Lab15.BUS;

namespace Lab15_ErrorHandling;

public partial class MainForm
{
    private RichTextBox _richErrorOutput = null!;
    private Label _lblErrorKind = null!;
    private Label _lblErrorContext = null!;

    private void BuildErrorLabTab()
    {
        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 2,
            BackColor = UiTheme.Background,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 92));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.Controls.Add(BuildErrorIntroCard(), 0, 0);
        root.Controls.Add(BuildErrorContent(), 0, 1);
        _tabErrorLab.Controls.Add(root);
        SetErrorPlaceholder();
    }

    private Control BuildErrorIntroCard()
    {
        var card = UiTheme.Card(14);
        card.Dock = DockStyle.Fill;
        card.Margin = new Padding(0, 0, 0, 10);
        card.Padding = new Padding(16, 10, 16, 10);

        var title = UiTheme.Label("Phòng kiểm thử lỗi – chiến lược xử lý theo tầng",
            new Font("Segoe UI", 11f, FontStyle.Bold), UiTheme.Primary);
        title.Location = new Point(16, 10);

        var description = new Label
        {
            Text = "Mọi ngoại lệ đều được phân loại tại GUI: BusinessException (nghiệp vụ), SqlException (CSDL) và Exception (hệ thống). " +
                   "Chi tiết được ghi vào nhật ký trước khi hiển thị thông điệp thân thiện.",
            AutoSize = false,
            Location = new Point(16, 38),
            Size = new Size(636, 42),
            Font = UiTheme.Small,
            ForeColor = UiTheme.Muted
        };

        var chips = new FlowLayoutPanel
        {
            Dock = DockStyle.Right,
            Width = 500,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false,
            BackColor = Color.Transparent,
            Padding = new Padding(0, 20, 0, 0)
        };
        chips.Controls.Add(Chip("BusinessException", UiTheme.WarningSoft, UiTheme.Warning));
        chips.Controls.Add(Chip("SqlException", UiTheme.DangerSoft, UiTheme.Danger));
        chips.Controls.Add(Chip("Exception", Color.FromArgb(226, 232, 240), Color.FromArgb(51, 65, 85)));

        card.Controls.Add(title);
        card.Controls.Add(description);
        card.Controls.Add(chips);
        return card;
    }

    private static Label Chip(string text, Color background, Color foreground) => new()
    {
        Text = "  " + text + "  ",
        AutoSize = true,
        BackColor = background,
        ForeColor = foreground,
        Font = UiTheme.SmallBold,
        Padding = new Padding(8, 5, 8, 5),
        Margin = new Padding(0, 0, 8, 0)
    };

    private Control BuildErrorContent()
    {
        var content = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 1,
            BackColor = UiTheme.Background,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };
        content.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 420));
        content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        content.Controls.Add(BuildScenarioCard(), 0, 0);
        content.Controls.Add(BuildErrorOutputCard(), 1, 0);
        return content;
    }

    private Control BuildScenarioCard()
    {
        var card = UiTheme.Card(16);
        card.Dock = DockStyle.Fill;
        card.Margin = new Padding(0, 0, 12, 0);
        card.Padding = new Padding(16);

        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 2,
            BackColor = UiTheme.Surface,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 34));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        var title = UiTheme.SectionTitle("Kịch bản kiểm thử");
        title.Dock = DockStyle.Fill;

        var flow = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            AutoScroll = true,
            BackColor = UiTheme.Surface,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };

        flow.Controls.Add(ScenarioButton("1. Lỗi nghiệp vụ: xóa sinh viên còn đăng ký",
            "BusinessException · mã SV_HAS_REGISTRATION", UiTheme.Warning, RunDemoBusinessError));
        flow.Controls.Add(ScenarioButton("2. Lỗi CSDL: vi phạm khóa ngoại",
            "SqlException 547 · xóa trực tiếp bị CSDL từ chối", UiTheme.Danger, RunDemoForeignKeyError));
        flow.Controls.Add(ScenarioButton("3. Lỗi CSDL: bảng không tồn tại",
            "SqlException 208 · mô phỏng truy vấn sai bảng", UiTheme.Danger, RunDemoMissingTableError));
        flow.Controls.Add(ScenarioButton("4. Lỗi hệ thống không lường trước",
            "Exception · InvalidOperationException", Color.FromArgb(71, 85, 105), RunDemoUnexpectedError));
        flow.Controls.Add(ScenarioButton("5. Kiểm tra dữ liệu: nhiều lỗi cùng lúc",
            "ValidationResult · báo toàn bộ lỗi trong một lần", UiTheme.Accent, () => RunDemoValidation()));
        flow.Controls.Add(ScenarioButton("6. Ghi nhật ký mẫu",
            "INFO + WARN + ERROR vào Logs/lab15.log", UiTheme.Success, WriteSampleLogs));
        flow.Controls.Add(ScenarioButton("7. Xóa nội dung kết quả",
            "Làm sạch vùng hiển thị", UiTheme.Muted, () =>
            {
                SetErrorPlaceholder();
                SetStatus("Đã xóa nội dung kết quả kiểm thử.");
            }));

        layout.Controls.Add(title, 0, 0);
        layout.Controls.Add(flow, 0, 1);
        card.Controls.Add(layout);
        return card;
    }

    private static Button ScenarioButton(string title, string subtitle, Color accent, Action handler)
    {
        var button = new Button
        {
            Text = title + Environment.NewLine + subtitle,
            Width = 356,
            Height = 54,
            TextAlign = ContentAlignment.MiddleLeft,
            FlatStyle = FlatStyle.Flat,
            BackColor = UiTheme.Surface,
            ForeColor = Color.FromArgb(31, 41, 55),
            Font = UiTheme.Body,
            Cursor = Cursors.Hand,
            Margin = new Padding(0, 0, 0, 8),
            Padding = new Padding(10, 0, 6, 0),
            UseVisualStyleBackColor = false
        };
        button.FlatAppearance.BorderColor = UiTheme.Border;
        button.FlatAppearance.BorderSize = 1;
        button.FlatAppearance.MouseOverBackColor = Color.FromArgb(248, 250, 252);
        button.Paint += (_, e) =>
        {
            using var brush = new SolidBrush(accent);
            e.Graphics.FillRectangle(brush, 0, 0, 4, button.Height);
        };
        button.Click += (_, _) => handler();
        return button;
    }

    private Control BuildErrorOutputCard()
    {
        var card = UiTheme.Card(16);
        card.Dock = DockStyle.Fill;
        card.Padding = new Padding(16);

        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 4,
            BackColor = UiTheme.Surface,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 30));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 36));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 26));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        var header = new Panel { Dock = DockStyle.Fill, BackColor = UiTheme.Surface };
        var title = UiTheme.Label("Kết quả phân loại", new Font("Segoe UI", 10.5f, FontStyle.Bold), UiTheme.Primary);
        title.Location = new Point(0, 3);
        header.Controls.Add(title);

        _lblErrorKind = new Label
        {
            Text = "Chưa có lỗi",
            Dock = DockStyle.Fill,
            BackColor = Color.FromArgb(241, 245, 249),
            ForeColor = UiTheme.Muted,
            Font = UiTheme.BodyBold,
            TextAlign = ContentAlignment.MiddleLeft,
            Padding = new Padding(10, 0, 10, 0),
            Margin = new Padding(0, 0, 0, 6)
        };

        _lblErrorContext = new Label
        {
            Text = "Chọn một kịch bản ở cột bên trái để xem cách phân loại và thông điệp.",
            Dock = DockStyle.Fill,
            Font = UiTheme.Small,
            ForeColor = UiTheme.Muted,
            TextAlign = ContentAlignment.MiddleLeft,
            Padding = new Padding(2, 0, 0, 0)
        };

        _richErrorOutput = new RichTextBox
        {
            Dock = DockStyle.Fill,
            ReadOnly = true,
            BorderStyle = BorderStyle.None,
            BackColor = Color.FromArgb(15, 23, 42),
            ForeColor = Color.FromArgb(226, 232, 240),
            Font = UiTheme.Mono,
            WordWrap = true,
            DetectUrls = false,
            ScrollBars = RichTextBoxScrollBars.Vertical,
            Padding = new Padding(10)
        };

        layout.Controls.Add(header, 0, 0);
        layout.Controls.Add(_lblErrorKind, 0, 1);
        layout.Controls.Add(_lblErrorContext, 0, 2);
        layout.Controls.Add(_richErrorOutput, 0, 3);
        card.Controls.Add(layout);
        return card;
    }

    private void SetErrorPlaceholder()
    {
        if (_richErrorOutput == null) return;
        _richErrorOutput.SelectionColor = Color.FromArgb(148, 163, 184);
        _richErrorOutput.Text =
            "Chưa có ngoại lệ nào được kích hoạt.\n\n" +
            "Nguyên tắc xử lý của ứng dụng:\n" +
            "  1. Tầng DAL  : để SqlException lan lên, kèm mã lỗi gốc.\n" +
            "  2. Tầng BUS  : kiểm tra nghiệp vụ, ném BusinessException có mã lỗi.\n" +
            "  3. Tầng GUI  : phân loại, ghi log, hiển thị thông điệp thân thiện.\n\n" +
            "Nhấn một kịch bản để xem kết quả chi tiết.";
        _lblErrorKind.Text = "Chưa có lỗi";
        _lblErrorKind.BackColor = Color.FromArgb(241, 245, 249);
        _lblErrorKind.ForeColor = UiTheme.Muted;
        _lblErrorContext.Text = "Chọn một kịch bản ở cột bên trái để xem cách phân loại và thông điệp.";
    }

    private void ShowDemo(Exception exception, string context)
    {
        var description = ErrorPresenter.Show(this, exception, context, silent: true);
        var kind = ErrorPresenter.KindOf(exception);
        _lblErrorKind.Text = "  " + ErrorPresenter.Classify(exception);
        _lblErrorKind.BackColor = kind switch
        {
            ErrorKind.Business => UiTheme.WarningSoft,
            ErrorKind.Database => UiTheme.DangerSoft,
            ErrorKind.Configuration => Color.FromArgb(255, 237, 213),
            _ => Color.FromArgb(226, 232, 240)
        };
        _lblErrorKind.ForeColor = kind switch
        {
            ErrorKind.Business => UiTheme.Warning,
            ErrorKind.Database => UiTheme.Danger,
            ErrorKind.Configuration => Color.FromArgb(154, 52, 18),
            _ => Color.FromArgb(51, 65, 85)
        };
        _lblErrorContext.Text = context + " · " + DateTime.Now.ToString("HH:mm:ss") +
                                " · đã ghi vào nhật ký";
        _richErrorOutput.Text = description;
        SetStatus(context + ": " + ErrorPresenter.Classify(exception), kind == ErrorKind.Database || kind == ErrorKind.Unexpected);
    }

    public void RunDemoBusinessError()
    {
        try
        {
            _studentService.Delete("SV001");
            ShowInfo("SV001 đã bị xóa (ngoài dự kiến).", "Kết quả");
        }
        catch (Exception ex)
        {
            ShowDemo(ex, "Xóa sinh viên SV001 (còn đăng ký học phần)");
        }
    }

    public void RunDemoForeignKeyError()
    {
        try
        {
            var target = _students.FirstOrDefault(s => s.SoDangKy > 0)?.MaSV;
            if (string.IsNullOrWhiteSpace(target))
            {
                var candidates = _studentService.Search(null, null, true);
                target = candidates.FirstOrDefault(s => s.SoDangKy > 0)?.MaSV;
            }
            if (string.IsNullOrWhiteSpace(target))
            {
                throw new BusinessException("DEMO_NO_DATA",
                    "Không có sinh viên nào đang có đăng ký để minh họa lỗi khóa ngoại.",
                    hint: "Chạy script dữ liệu mẫu trước.");
            }

            _studentService.DeleteUnsafeForDemo(target);
            ShowInfo($"Đã xóa {target} (ngoài dự kiến).", "Kết quả");
        }
        catch (Exception ex)
        {
            ShowDemo(ex, "Xóa trực tiếp sinh viên đang có đăng ký");
        }
    }

    public void RunDemoMissingTableError()
    {
        try
        {
            _studentService.TriggerDatabaseError();
            ShowInfo("Truy vấn bảng không tồn tại lại thành công (ngoài dự kiến).", "Kết quả");
        }
        catch (Exception ex)
        {
            ShowDemo(ex, "Mô phỏng truy vấn bảng không tồn tại");
        }
    }

    public void RunDemoUnexpectedError()
    {
        try
        {
            StudentService.TriggerUnexpectedError();
        }
        catch (Exception ex)
        {
            ShowDemo(ex, "Mô phỏng lỗi hệ thống không lường trước");
        }
    }

    public ValidationResult RunDemoValidation()
    {
        var result = PrepareValidationDemo();
        _lblErrorKind.Text = "  ValidationResult – " + result.ErrorCount + " lỗi";
        _lblErrorKind.BackColor = Color.FromArgb(219, 234, 254);
        _lblErrorKind.ForeColor = UiTheme.Primary;
        _lblErrorContext.Text = "Kiểm tra dữ liệu trước khi ghi CSDL · " + DateTime.Now.ToString("HH:mm:ss");

        var text = "Loại lỗi   : ValidationResult (không ném ngoại lệ ngay)\n" +
                   "Số lỗi     : " + result.ErrorCount + "\n" +
                   "Thông điệp : Dữ liệu nhập chưa hợp lệ.\n\n" +
                   "Chi tiết:\n" +
                   string.Join(Environment.NewLine, result.Errors.Select(e => $"  • {e.Key}: {e.Value}"));
        if (result.Warnings.Count > 0)
            text += "\n\nCảnh báo:\n" + string.Join(Environment.NewLine, result.Warnings.Select(w => "  • " + w));
        text += "\n\nNhật ký    : " + AppLogger.CurrentFile;
        _richErrorOutput.Text = text;
        SetStatus($"Kiểm tra dữ liệu: {result.ErrorCount} lỗi, không ghi CSDL.", false);
        return result;
    }

    public void WriteSampleLogs()
    {
        AppLogger.Info("Ghi nhật ký mẫu: thao tác thành công.", LogCategories.App,
            "Source=Demo; User=" + Environment.UserName);
        AppLogger.Warn("Ghi nhật ký mẫu: dữ liệu gần giới hạn.", LogCategories.Validation,
            "Field=DiemTB; Value=9.8");
        try
        {
            throw new InvalidOperationException("Ngoại lệ mẫu dùng để minh họa log lỗi.");
        }
        catch (Exception ex)
        {
            AppLogger.Error("Ghi nhật ký mẫu: lỗi được bắt và ghi log.", LogCategories.App, ex, "Source=Demo");
        }

        RefreshLogs();
        _lblErrorKind.Text = "  Đã ghi 3 bản ghi nhật ký";
        _lblErrorKind.BackColor = UiTheme.SuccessSoft;
        _lblErrorKind.ForeColor = UiTheme.Success;
        _lblErrorContext.Text = "INFO + WARN + ERROR · " + AppLogger.CurrentFile;
        _richErrorOutput.Text =
            "Đã ghi 3 bản ghi vào tệp nhật ký:\n" +
            "  [INFO ] Ghi nhật ký mẫu: thao tác thành công.\n" +
            "  [WARN ] Ghi nhật ký mẫu: dữ liệu gần giới hạn.\n" +
            "  [ERROR] Ghi nhật ký mẫu: lỗi được bắt và ghi log.\n\n" +
            "Tệp: " + AppLogger.CurrentFile + "\n" +
            "Dung lượng tối đa: " + (AppLogger.MaxBytes / 1024) + " KB · lưu giữ " + AppLogger.RetentionDays + " ngày.\n\n" +
            "Mở tab Nhật ký để xem các dòng vừa ghi.";
        SetStatus("Đã ghi 3 bản ghi nhật ký mẫu.", false);
    }
}
