# BIÊN BẢN KIỂM THỬ TRIỂN KHAI

**Học phần:** Lập trình .NET (IT3212) – Lab 15
**Sinh viên:** Nguyễn Quang Dũng – MSSV 24003351
**Ứng dụng:** Lab15_ErrorHandling (WinForms, .NET 10)
**Cơ sở dữ liệu:** QLSinhVien – SQL Server 2022 Express (.\SQLEXPRESS)
**Thời điểm lập:** 17/11/2026

---

## 1. Thông tin máy đích

| Thành phần | Giá trị |
|---|---|
| Máy tính | DESKTOP-OFTGK30 |
| Tài khoản Windows | Admin |
| Hệ điều hành | Microsoft Windows 10.0.22631 (64-bit) |
| Kiến trúc tiến trình | X64 |
| Nền tảng .NET | .NET 10.0.13 |
| Phiên bản ứng dụng | 1.0.0.0 |
| Thư mục chạy | `D:\Lập trình .NET\lab15\Publish\` |
| Tệp cấu hình | `Publish\App.config` |
| Thư mục Logs | `Publish\Logs` |
| Thư mục Reports | `Publish\Reports` |
| Thư mục Publish | `D:\Lập trình .NET\lab15\Publish` (tồn tại) |
| Số tệp trong thư mục chạy | 12 |
| Bảo vệ chuỗi kết nối | Chưa bật trên gói mới (đọc trực tiếp App.config) |

Chuỗi kết nối (đã che mật khẩu khi hiển thị):

```
Data Source=.\SQLEXPRESS;Initial Catalog=QLSinhVien;Integrated Security=True;
Encrypt=True;TrustServerCertificate=True;Connect Timeout=8;Application Name=Lab15_ErrorHandling
```

## 2. Quy trình triển khai

1. Build Release: `dotnet build .\Lab15_ErrorHandling.slnx -c Release` → 0 cảnh báo, 0 lỗi.
2. Tạo gói: `dotnet publish .\Lab15_ErrorHandling\Lab15_ErrorHandling.csproj -c Release -o .\Publish`.
3. Sao chép thư mục `Publish` sang máy đích (cùng máy hoặc máy khác có SQL Server).
4. Kiểm tra `App.config` nằm cạnh `Lab15_ErrorHandling.exe` và trỏ đúng instance SQL Server.
5. Chạy `Lab15_ErrorHandling.exe`, thực hiện 12 hạng mục kiểm thử bên dưới.
6. Chạy `Lab15_ErrorHandling.exe --test` (bộ kiểm thử tự động) và
   `Lab15_ErrorHandling.exe --protocol` (xuất biên bản + báo cáo preflight).
7. Lưu biên bản và ảnh chụp vào thư mục `Reports`/`Screenshots` để làm minh chứng.

## 3. Kết quả kiểm tra trước khi chạy (preflight)

Kết luận: **SẴN SÀNG (CÓ CẢNH BÁO)** – đạt 9, cảnh báo 1, lỗi 0.

| Hạng mục | Kết quả | Thông tin |
|---|---|---|
| Tệp cấu hình | ĐẠT | Tìm thấy App.config và đọc được appSettings |
| Chuỗi kết nối | ĐẠT | Nạp từ App.config (đã che mật khẩu) |
| Thư mục nhật ký (Logs) | ĐẠT | Tồn tại và có quyền ghi |
| Thư mục báo cáo (Reports) | ĐẠT | Tồn tại và có quyền ghi |
| Kết nối SQL Server | ĐẠT | Kết nối thành công – SQL Server 2022 RTM 16.0.1000.6 |
| Cơ sở dữ liệu | ĐẠT | Đang dùng đúng CSDL QLSinhVien |
| Bảng dữ liệu | ĐẠT | Đủ SinhVien, Khoa, HocPhan, DangKy |
| Dữ liệu mẫu | ĐẠT | SinhVien=30, Khoa=3, HocPhan=5, DangKy=15 |
| Bảo vệ cấu hình | CẢNH BÁO | Chuỗi kết nối đang đọc trực tiếp từ App.config (chưa mã hóa) |
| Gói triển khai | ĐẠT | Đang chạy từ thư mục Publish |

Cảnh báo "Bảo vệ cấu hình" là chủ ý: gói Publish mới giữ `App.config` dạng đọc được để
người chấm kiểm tra; chức năng mã hóa được minh họa ở Bài 8 (ProtectedConfiguration và DPAPI).

## 4. Danh mục kiểm thử chức năng

| Mã | Hạng mục | Kỳ vọng | Kết quả |
|---|---|---|---|
| TC01 | Khởi động ứng dụng từ thư mục Publish | Cửa sổ chính mở, không hộp thoại lỗi khởi động | ĐẠT |
| TC02 | Đọc cấu hình App.config | Tab Cấu hình hiển thị đúng ReportFolder, LogFolder, LogLevel | ĐẠT |
| TC03 | Kết nối CSDL QLSinhVien | Tab Sinh viên tải 30 sinh viên, 3 khoa | ĐẠT |
| TC04 | Ghi nhật ký vào thư mục Logs | `lab15.log` được tạo, có dòng INFO/ERROR | ĐẠT |
| TC05 | Xoay vòng nhật ký | Vượt `LogMaxSizeKB` sinh tệp `lab15-*.log` | ĐẠT |
| TC06 | Kiểm tra dữ liệu nhiều lỗi | Báo tất cả lỗi cùng lúc, đánh dấu ô sai | ĐẠT |
| TC07 | Ngoại lệ nghiệp vụ | Xóa SV còn đăng ký hiện hộp thoại thân thiện, mã `SV_HAS_REGISTRATION` | ĐẠT |
| TC08 | Ngoại lệ CSDL | Lỗi SqlException hiển thị hướng xử lý và được ghi log | ĐẠT |
| TC09 | Bảo vệ chuỗi kết nối bằng DPAPI | Tạo/xóa `Config\connection.protected`, trạng thái cập nhật đúng | ĐẠT |
| TC10 | Xuất báo cáo ra ReportFolder | Tạo được CSV/XLSX trong `Reports` | ĐẠT |
| TC11 | Màn hình kiểm tra trước khi chạy | Hiển thị đủ ĐẠT/CẢNH BÁO/LỖI và kết luận | ĐẠT |
| TC12 | Bộ kiểm thử tự động `--test` | Tất cả PASS, mã thoát 0 | ĐẠT |

**Kết luận mục 4:** đạt 12/12 hạng mục.

## 5. Bộ kiểm thử tự động (--test)

Chạy trên gói Publish:

```
[PASS] CFG01  Cấu hình App.config
[PASS] VAL01  ValidationResult gom nhiều lỗi
[PASS] VAL02  Kiểm tra dữ liệu với CSDL (trùng mã/email)
[PASS] CRUD01 Thêm - sửa - xóa sinh viên tạm
[PASS] BIZ01  BusinessException khi xóa SV còn đăng ký
[PASS] SQL01  SqlException 547 (khóa ngoại)
[PASS] SQL02  SqlException 208 (bảng không tồn tại)
[PASS] LOG01  Ghi nhật ký và đọc lại
[PASS] LOG02  Xoay vòng nhật ký
[PASS] SEC01  Mã hóa/giải mã chuỗi kết nối bằng DPAPI
[PASS] EXP01  Xuất CSV và XLSX
[PASS] PRE01  Kiểm tra trước khi chạy
[PASS] ERR01  Phân loại ngoại lệ tại GUI
[PASS] DEP01  Sinh biên bản triển khai
RESULT: 14/14 passed
```

Mã thoát: 0. Báo cáo chi tiết: `Publish\Reports\KetQuaKiemThuTuDong.txt`.

Dữ liệu sau kiểm thử: 30 sinh viên, SV001 còn nguyên, không còn bản ghi `ZZT%`.

## 6. Minh chứng

- `Screenshots\13_KiemTraTruocKhiChay.png` – màn hình preflight.
- `Screenshots\14_TrienKhai.png` – thông tin máy đích và danh mục TC01–TC12.
- `Screenshots\15_BienBanKiemThuTrienKhai.png` – xuất biên bản thành công.
- `Publish\Reports\BienBanKiemThuTrienKhai-20261117-100827.txt` – biên bản do ứng dụng sinh.
- `Publish\Reports\KiemTraTruocKhiChay.txt` – báo cáo preflight.

## 7. Kết luận

Ứng dụng đáp ứng yêu cầu chạy trên máy đích: khởi động từ thư mục Publish, đọc cấu hình,
kết nối CSDL, ghi nhật ký có xoay vòng, xử lý lỗi theo tầng, kiểm tra trước khi chạy và
xuất biên bản kiểm thử. Đã kiểm thử 12 hạng mục chức năng và 14 kiểm thử tự động, tất cả đạt.

**Người kiểm thử:** Nguyễn Quang Dũng
**Chữ ký:** ....................................................
