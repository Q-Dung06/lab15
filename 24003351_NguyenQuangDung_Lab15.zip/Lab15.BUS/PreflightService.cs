using System.Data;
using System.Text;
using Lab15.DAL;

namespace Lab15.BUS;

public enum CheckStatus
{
    Pass,
    Warning,
    Fail
}

public sealed record PreflightCheck(string Name, CheckStatus Status, string Message, string? Detail = null)
{
    public string StatusText => Status switch
    {
        CheckStatus.Pass => "ĐẠT",
        CheckStatus.Warning => "CẢNH BÁO",
        CheckStatus.Fail => "LỖI",
        _ => "?"
    };

    public string Icon => Status switch
    {
        CheckStatus.Pass => "✔",
        CheckStatus.Warning => "!",
        CheckStatus.Fail => "✖",
        _ => "?"
    };
}

/// <summary>Bài 9 – Kết quả kiểm tra trước khi chạy ứng dụng.</summary>
public sealed class PreflightReport
{
    public DateTime CheckedAt { get; } = DateTime.Now;

    public List<PreflightCheck> Checks { get; } = new();

    public int PassCount => Checks.Count(c => c.Status == CheckStatus.Pass);

    public int WarningCount => Checks.Count(c => c.Status == CheckStatus.Warning);

    public int FailCount => Checks.Count(c => c.Status == CheckStatus.Fail);

    public CheckStatus Overall =>
        FailCount > 0 ? CheckStatus.Fail :
        WarningCount > 0 ? CheckStatus.Warning : CheckStatus.Pass;

    public string OverallText => Overall switch
    {
        CheckStatus.Pass => "SẴN SÀNG CHẠY",
        CheckStatus.Warning => "SẴN SÀNG (CÓ CẢNH BÁO)",
        _ => "CHƯA SẴN SÀNG"
    };

    public bool CanRun => FailCount == 0;

    public PreflightReport Add(string name, CheckStatus status, string message, string? detail = null)
    {
        Checks.Add(new PreflightCheck(name, status, message, detail));
        return this;
    }

    public string ToText()
    {
        var builder = new StringBuilder();
        builder.AppendLine("KIỂM TRA TRƯỚC KHI CHẠY – LAB 15");
        builder.AppendLine("Thời điểm: " + CheckedAt.ToString("dd/MM/yyyy HH:mm:ss"));
        builder.AppendLine("Kết luận: " + OverallText);
        builder.AppendLine(new string('-', 90));
        builder.AppendLine($"{"Hạng mục",-32} {"Kết quả",-12} Thông tin");
        builder.AppendLine(new string('-', 90));
        foreach (var check in Checks)
        {
            builder.AppendLine($"{check.Name,-32} {check.StatusText,-12} {check.Message}");
            if (!string.IsNullOrWhiteSpace(check.Detail))
                builder.AppendLine($"{"",-46}{check.Detail}");
        }
        builder.AppendLine(new string('-', 90));
        builder.AppendLine($"Đạt: {PassCount}   Cảnh báo: {WarningCount}   Lỗi: {FailCount}");
        return builder.ToString();
    }
}

/// <summary>
/// Bài 9 – Màn hình kiểm tra trước khi chạy: cấu hình, quyền ghi thư mục,
/// kết nối CSDL, sự tồn tại của bảng, dữ liệu mẫu và trạng thái bảo vệ cấu hình.
/// </summary>
public sealed class PreflightService
{
    private static readonly string[] RequiredTables = { "SinhVien", "Khoa", "HocPhan", "DangKy" };

    private readonly AppConfig _config;
    private readonly HealthRepository _health;
    private readonly SinhVienRepository _students;

    public PreflightService(AppConfig? config = null, HealthRepository? health = null, SinhVienRepository? students = null)
    {
        _config = config ?? AppConfig.Current;
        _health = health ?? new HealthRepository();
        _students = students ?? new SinhVienRepository();
    }

    public PreflightReport RunAll()
    {
        var report = new PreflightReport();

        CheckConfigFile(report);
        CheckConnectionString(report);
        CheckFolder(report, "Thư mục nhật ký (Logs)", _config.LogFolder);
        CheckFolder(report, "Thư mục báo cáo (Reports)", _config.ReportFolder);

        var databaseReady = CheckDatabase(report);
        if (databaseReady)
        {
            CheckTables(report);
            CheckRowCounts(report);
        }
        else
        {
            report.Add("Bảng dữ liệu", CheckStatus.Fail,
                "Bỏ qua vì chưa kết nối được CSDL.");
            report.Add("Dữ liệu mẫu", CheckStatus.Fail,
                "Bỏ qua vì chưa kết nối được CSDL.");
        }

        CheckProtection(report);
        CheckDeploymentFolder(report);

        var level = report.Overall == CheckStatus.Fail ? LogLevel.Error :
            report.Overall == CheckStatus.Warning ? LogLevel.Warn : LogLevel.Info;
        AppLogger.Write(level, LogCategories.Preflight,
            $"Kiểm tra trước khi chạy: {report.OverallText} " +
            $"(đạt {report.PassCount}, cảnh báo {report.WarningCount}, lỗi {report.FailCount}).",
            string.Join(" | ", report.Checks.Select(c => $"{c.Name}={c.StatusText}")));

        return report;
    }

    private void CheckConfigFile(PreflightReport report)
    {
        try
        {
            if (File.Exists(_config.ConfigFilePath))
            {
                var info = new FileInfo(_config.ConfigFilePath);
                report.Add("Tệp cấu hình", CheckStatus.Pass,
                    "Tìm thấy App.config và đọc được appSettings.",
                    $"{_config.ConfigFilePath} ({info.Length:N0} byte, sửa lúc {info.LastWriteTime:dd/MM/yyyy HH:mm})");
            }
            else
            {
                report.Add("Tệp cấu hình", CheckStatus.Fail,
                    "Không tìm thấy App.config. Ứng dụng sẽ dùng giá trị mặc định.",
                    _config.ConfigFilePath);
            }
        }
        catch (Exception ex)
        {
            report.Add("Tệp cấu hình", CheckStatus.Fail, "Lỗi đọc tệp cấu hình: " + ex.Message,
                _config.ConfigFilePath);
        }
    }

    private void CheckConnectionString(PreflightReport report)
    {
        try
        {
            var connectionString = _config.GetConnectionString();
            if (string.IsNullOrWhiteSpace(connectionString))
            {
                report.Add("Chuỗi kết nối", CheckStatus.Fail,
                    "Chuỗi kết nối QLSinhVien đang trống.");
                return;
            }

            var source = _config.IsProtectedConnection ? "tệp DPAPI Config/connection.protected" : "App.config";
            report.Add("Chuỗi kết nối", CheckStatus.Pass,
                $"Đã nạp chuỗi kết nối từ {source} (đã che mật khẩu).",
                ConnectionStringProtector.Mask(connectionString));
        }
        catch (Exception ex)
        {
            report.Add("Chuỗi kết nối", CheckStatus.Fail,
                "Không đọc được chuỗi kết nối: " + ex.Message,
                _config.GetMaskedConnectionString());
        }
    }

    private void CheckFolder(PreflightReport report, string label, string folder)
    {
        try
        {
            Directory.CreateDirectory(folder);
            var probe = Path.Combine(folder, ".write-test-" + Guid.NewGuid().ToString("N") + ".tmp");
            File.WriteAllText(probe, "lab15");
            File.Delete(probe);
            report.Add(label, CheckStatus.Pass, "Thư mục tồn tại và có quyền ghi.", folder);
        }
        catch (Exception ex)
        {
            report.Add(label, CheckStatus.Fail, "Không ghi được vào thư mục: " + ex.Message, folder);
        }
    }

    private bool CheckDatabase(PreflightReport report)
    {
        try
        {
            var version = _health.GetServerVersion();
            var database = _health.GetDatabaseName();
            report.Add("Kết nối SQL Server", CheckStatus.Pass, "Kết nối thành công.",
                $"{version} | CSDL hiện tại: {database}");

            if (!string.Equals(database, "QLSinhVien", StringComparison.OrdinalIgnoreCase))
            {
                report.Add("Cơ sở dữ liệu", CheckStatus.Warning,
                    $"Đang kết nối CSDL '{database}' thay vì 'QLSinhVien'.", database);
            }
            else
            {
                report.Add("Cơ sở dữ liệu", CheckStatus.Pass, "Đang dùng đúng CSDL QLSinhVien.", database);
            }

            return true;
        }
        catch (Exception ex)
        {
            report.Add("Kết nối SQL Server", CheckStatus.Fail,
                "Không kết nối được SQL Server: " + ex.Message,
                _config.GetMaskedConnectionString());
            AppLogger.Warn("Kiểm tra trước khi chạy: không kết nối được CSDL.", LogCategories.Preflight,
                _config.GetMaskedConnectionString(), ex);
            return false;
        }
    }

    private void CheckTables(PreflightReport report)
    {
        try
        {
            var missing = RequiredTables.Where(table => !_health.TableExists(table)).ToArray();
            if (missing.Length == 0)
            {
                report.Add("Bảng dữ liệu", CheckStatus.Pass,
                    "Đủ các bảng bắt buộc: " + string.Join(", ", RequiredTables) + ".");
            }
            else
            {
                report.Add("Bảng dữ liệu", CheckStatus.Fail,
                    "Thiếu bảng: " + string.Join(", ", missing) + ".",
                    "Chạy script Database/01_QLSinhVien.sql để tạo đủ cấu trúc.");
            }
        }
        catch (Exception ex)
        {
            report.Add("Bảng dữ liệu", CheckStatus.Fail,
                "Không kiểm tra được danh sách bảng: " + ex.Message);
        }
    }

    private void CheckRowCounts(PreflightReport report)
    {
        try
        {
            var table = _health.GetRowCounts();
            var parts = new List<string>();
            var studentCount = 0;
            var registrationCount = 0;
            foreach (DataRow row in table.Rows)
            {
                var name = Convert.ToString(row["TenBang"]) ?? "";
                var count = Convert.ToInt32(row["SoDong"]);
                parts.Add($"{name}={count}");
                if (name == "SinhVien") studentCount = count;
                if (name == "DangKy") registrationCount = count;
            }

            if (studentCount == 0)
            {
                report.Add("Dữ liệu mẫu", CheckStatus.Warning,
                    "Bảng SinhVien đang trống; hãy chạy script dữ liệu mẫu.",
                    string.Join(", ", parts));
            }
            else if (registrationCount == 0)
            {
                report.Add("Dữ liệu mẫu", CheckStatus.Warning,
                    "Chưa có đăng ký học phần; một số tình huống kiểm thử sẽ không có dữ liệu.",
                    string.Join(", ", parts));
            }
            else
            {
                report.Add("Dữ liệu mẫu", CheckStatus.Pass,
                    "Dữ liệu mẫu đã sẵn sàng.", string.Join(", ", parts));
            }
        }
        catch (Exception ex)
        {
            report.Add("Dữ liệu mẫu", CheckStatus.Fail,
                "Không đếm được số dòng: " + ex.Message);
        }
    }

    private void CheckProtection(PreflightReport report)
    {
        if (_config.IsProtectedConnection)
        {
            report.Add("Bảo vệ cấu hình", CheckStatus.Pass,
                "Chuỗi kết nối đang được bảo vệ bằng DPAPI.",
                ConnectionStringProtector.ProtectedFilePath);
        }
        else
        {
            report.Add("Bảo vệ cấu hình", CheckStatus.Warning,
                "Chuỗi kết nối đang đọc trực tiếp từ App.config (chưa mã hóa).",
                "Mở tab Cấu hình để bật bảo vệ bằng DPAPI trước khi triển khai.");
        }
    }

    private void CheckDeploymentFolder(PreflightReport report)
    {
        try
        {
            var baseDirectory = AppContext.BaseDirectory;
            var isPublish = baseDirectory.TrimEnd(Path.DirectorySeparatorChar)
                .EndsWith("Publish", StringComparison.OrdinalIgnoreCase);
            var files = Directory.Exists(baseDirectory)
                ? Directory.EnumerateFiles(baseDirectory, "*", SearchOption.TopDirectoryOnly).Count()
                : 0;

            if (isPublish)
            {
                report.Add("Gói triển khai", CheckStatus.Pass,
                    "Đang chạy từ thư mục Publish.", $"{baseDirectory} ({files} tệp)");
            }
            else
            {
                report.Add("Gói triển khai", CheckStatus.Warning,
                    "Đang chạy từ thư mục build, chưa phải bản Publish.",
                    "Dùng 'dotnet publish -c Release -o Publish' để tạo gói chạy trên máy đích.");
            }
        }
        catch (Exception ex)
        {
            report.Add("Gói triển khai", CheckStatus.Warning,
                "Không kiểm tra được thư mục chạy: " + ex.Message, AppContext.BaseDirectory);
        }
    }
}
