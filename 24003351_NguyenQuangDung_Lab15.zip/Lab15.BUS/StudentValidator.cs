using System.Globalization;
using System.Text.RegularExpressions;

namespace Lab15.BUS;

/// <summary>
/// Bài 2 – Kiểm tra dữ liệu đầu vào. Validator chỉ kiểm tra các quy tắc tĩnh
/// (định dạng, bắt buộc, miền giá trị). Các quy tắc cần truy vấn CSDL
/// (trùng mã, trùng email, khoa tồn tại) do StudentService bổ sung.
/// </summary>
public sealed class StudentValidator
{
    private static readonly Regex CodePattern = new(@"^[A-Za-z0-9]{3,10}$", RegexOptions.Compiled);
    private static readonly Regex EmailPattern =
        new(@"^[^@\s]+@[^@\s]+\.[^@\s]{2,}$", RegexOptions.Compiled | RegexOptions.IgnoreCase);

    private static readonly string[] DateFormats =
    {
        "dd/MM/yyyy", "d/M/yyyy", "dd-MM-yyyy", "d-M-yyyy",
        "yyyy-MM-dd", "MM/dd/yyyy", "M/d/yyyy"
    };

    public ValidationResult Validate(StudentInput input)
    {
        var result = new ValidationResult();

        // 1. Mã sinh viên
        var maSV = (input.MaSV ?? string.Empty).Trim();
        if (maSV.Length == 0)
            result.Add("MaSV", "Mã sinh viên không được để trống.");
        else if (!CodePattern.IsMatch(maSV))
            result.Add("MaSV", "Mã sinh viên phải có 3-10 ký tự, chỉ gồm chữ cái và chữ số (ví dụ SV031).");

        // 2. Họ tên
        var hoTen = (input.HoTen ?? string.Empty).Trim();
        if (hoTen.Length == 0)
            result.Add("HoTen", "Họ tên không được để trống.");
        else if (hoTen.Length < 2 || hoTen.Length > 100)
            result.Add("HoTen", "Họ tên phải từ 2 đến 100 ký tự.");
        else if (hoTen.All(char.IsDigit))
            result.Add("HoTen", "Họ tên không thể chỉ gồm chữ số.");

        // 3. Ngày sinh
        if (!TryParseDate(input.NgaySinh, out var ngaySinh))
        {
            result.Add("NgaySinh", "Ngày sinh không hợp lệ. Dùng định dạng dd/MM/yyyy (ví dụ 15/08/2004).");
        }
        else
        {
            if (ngaySinh > DateTime.Today)
                result.Add("NgaySinh", "Ngày sinh không được lớn hơn ngày hiện tại.");
            else if (ngaySinh < new DateTime(1900, 1, 1))
                result.Add("NgaySinh", "Ngày sinh phải sau ngày 01/01/1900.");
            else if (ngaySinh > DateTime.Today.AddYears(-15))
                result.AddWarning("Sinh viên nhỏ hơn 15 tuổi, hãy kiểm tra lại ngày sinh.");
        }

        // 4. Khoa
        if (string.IsNullOrWhiteSpace(input.MaKhoa))
            result.Add("MaKhoa", "Chưa chọn khoa.");

        // 5. Điểm trung bình
        if (!TryParseScore(input.DiemTB, out var diemTB))
            result.Add("DiemTB", "Điểm trung bình không hợp lệ. Nhập số từ 0 đến 10, ví dụ 7.25.");
        else if (diemTB < 0m || diemTB > 10m)
            result.Add("DiemTB", "Điểm trung bình phải nằm trong khoảng 0 – 10.");

        // 6. Email (không bắt buộc)
        var email = (input.Email ?? string.Empty).Trim();
        if (email.Length > 0)
        {
            if (email.Length > 100)
                result.Add("Email", "Email không được dài quá 100 ký tự.");
            else if (!EmailPattern.IsMatch(email))
                result.Add("Email", "Email không đúng định dạng (ví dụ ten@eaut.edu.vn).");
        }

        return result;
    }

    public static bool TryParseDate(string? text, out DateTime value)
    {
        value = default;
        if (string.IsNullOrWhiteSpace(text)) return false;

        var trimmed = text.Trim();
        if (DateTime.TryParseExact(trimmed, DateFormats, CultureInfo.InvariantCulture,
                DateTimeStyles.None, out value))
            return true;

        return DateTime.TryParse(trimmed, CultureInfo.GetCultureInfo("vi-VN"),
            DateTimeStyles.None, out value);
    }

    public static bool TryParseScore(string? text, out decimal value)
    {
        value = default;
        if (string.IsNullOrWhiteSpace(text)) return false;

        var normalized = text.Trim().Replace(',', '.');
        return decimal.TryParse(normalized, NumberStyles.Number, CultureInfo.InvariantCulture, out value);
    }

    public static string NormalizeCode(string? maSV) => (maSV ?? string.Empty).Trim().ToUpperInvariant();

    public static string NormalizeEmail(string? email) =>
        string.IsNullOrWhiteSpace(email) ? string.Empty : email.Trim().ToLowerInvariant();
}
