using System.Text;

namespace Lab15.BUS;

public enum LogLevel
{
    Debug = 0,
    Info = 1,
    Warn = 2,
    Error = 3,
    Fatal = 4
}

/// <summary>Một bản ghi nhật ký có cấu trúc.</summary>
public sealed record LogEntry(
    DateTime Timestamp,
    LogLevel Level,
    string Category,
    string Message,
    string? Detail = null,
    string? ExceptionText = null)
{
    public string LevelText => Level switch
    {
        LogLevel.Debug => "DEBUG",
        LogLevel.Info => "INFO",
        LogLevel.Warn => "WARN",
        LogLevel.Error => "ERROR",
        LogLevel.Fatal => "FATAL",
        _ => "INFO"
    };

    public string ToDisplayLine() =>
        $"{Timestamp:HH:mm:ss.fff} [{LevelText,-5}] {Category}: {Message}";

    public string ToFileBlock()
    {
        var builder = new StringBuilder();
        builder.Append(Timestamp.ToString("yyyy-MM-dd HH:mm:ss.fff"))
            .Append(" [").Append(LevelText).Append(']')
            .Append(" [").Append(Category).Append("] ")
            .AppendLine(OneLine(Message));

        if (!string.IsNullOrWhiteSpace(Detail))
            builder.Append("    detail: ").AppendLine(OneLine(Detail));

        if (!string.IsNullOrWhiteSpace(ExceptionText))
            builder.Append("    exception: ").AppendLine(OneLine(ExceptionText));

        return builder.ToString();
    }

    private static string OneLine(string value) =>
        value.Replace("\r\n", " | ").Replace('\n', '|').Replace('\r', '|').Trim();
}

/// <summary>
/// Bài 3 + Bài 7 – Ghi nhật ký có cấu trúc vào tệp, tự xoay vòng theo dung lượng
/// và dọn tệp cũ theo số ngày lưu giữ. Logger không bao giờ ném ngoại lệ ra ngoài
/// để tránh làm hỏng luồng nghiệp vụ khi ổ đĩa gặp sự cố.
/// </summary>
public static class AppLogger
{
    private const string BaseFileName = "lab15";
    private const int MaxRecentEntries = 2000;

    private static readonly object Sync = new();
    private static readonly Queue<LogEntry> RecentEntries = new();

    private static string _directory = Path.Combine(AppContext.BaseDirectory, "Logs");
    private static long _maxBytes = 2048L * 1024L;
    private static int _retentionDays = 30;
    private static LogLevel _minimum = LogLevel.Info;
    private static bool _configured;

    public static event Action<LogEntry>? EntryWritten;

    public static string LastWriteError { get; private set; } = "";

    public static string DirectoryPath
    {
        get
        {
            lock (Sync)
            {
                EnsureConfigured();
                return _directory;
            }
        }
    }

    public static long MaxBytes
    {
        get
        {
            lock (Sync)
            {
                EnsureConfigured();
                return _maxBytes;
            }
        }
    }

    public static int RetentionDays
    {
        get
        {
            lock (Sync)
            {
                EnsureConfigured();
                return _retentionDays;
            }
        }
    }

    public static LogLevel MinimumLevel
    {
        get
        {
            lock (Sync)
            {
                EnsureConfigured();
                return _minimum;
            }
        }
    }

    public static string CurrentFile
    {
        get
        {
            lock (Sync)
            {
                EnsureConfigured();
                return Path.Combine(_directory, BaseFileName + ".log");
            }
        }
    }

    public static void Configure(AppConfig config)
    {
        Configure(config.LogFolder, config.LogMaxSizeKB, config.LogRetentionDays, config.MinimumLogLevel);
    }

    public static void Configure(string directory, int maxSizeKB, int retentionDays, LogLevel minimum)
    {
        lock (Sync)
        {
            _directory = string.IsNullOrWhiteSpace(directory)
                ? Path.Combine(AppContext.BaseDirectory, "Logs")
                : Path.GetFullPath(directory);
            _maxBytes = Math.Max(16, maxSizeKB) * 1024L;
            _retentionDays = Math.Max(1, retentionDays);
            _minimum = minimum;
            _configured = true;
        }
    }

    public static LogLevel ParseLevel(string? text) => (text ?? string.Empty).Trim().ToUpperInvariant() switch
    {
        "DEBUG" or "TRACE" => LogLevel.Debug,
        "WARN" or "WARNING" => LogLevel.Warn,
        "ERROR" => LogLevel.Error,
        "FATAL" or "CRITICAL" => LogLevel.Fatal,
        _ => LogLevel.Info
    };

    public static void Debug(string message, string category = LogCategories.App, string? detail = null) =>
        Write(LogLevel.Debug, category, message, detail, null);

    public static void Info(string message, string category = LogCategories.App, string? detail = null) =>
        Write(LogLevel.Info, category, message, detail, null);

    public static void Warn(string message, string category = LogCategories.App, string? detail = null, Exception? exception = null) =>
        Write(LogLevel.Warn, category, message, detail, exception);

    public static void Error(string message, string category = LogCategories.App, Exception? exception = null, string? detail = null) =>
        Write(LogLevel.Error, category, message, detail, exception);

    public static void Fatal(string message, string category = LogCategories.App, Exception? exception = null, string? detail = null) =>
        Write(LogLevel.Fatal, category, message, detail, exception);

    public static void Write(LogLevel level, string category, string message, string? detail = null, Exception? exception = null)
    {
        LogEntry entry;
        lock (Sync)
        {
            EnsureConfigured();
            if (level < _minimum) return;

            entry = new LogEntry(
                DateTime.Now,
                level,
                string.IsNullOrWhiteSpace(category) ? LogCategories.App : category.Trim(),
                message ?? string.Empty,
                detail,
                exception?.ToString());

            try
            {
                Directory.CreateDirectory(_directory);
                var file = Path.Combine(_directory, BaseFileName + ".log");
                var block = entry.ToFileBlock();
                var needed = Encoding.UTF8.GetByteCount(block);
                RotateIfNeeded(file, needed);
                File.AppendAllText(file, block, new UTF8Encoding(false));
                LastWriteError = "";
            }
            catch (Exception ex)
            {
                LastWriteError = ex.Message;
            }

            RecentEntries.Enqueue(entry);
            while (RecentEntries.Count > MaxRecentEntries) RecentEntries.Dequeue();
        }

        try
        {
            EntryWritten?.Invoke(entry);
        }
        catch
        {
            // Không để lỗi của người nghe log ảnh hưởng luồng ghi log.
        }
    }

    private static void RotateIfNeeded(string file, int incomingBytes)
    {
        if (!File.Exists(file)) return;
        var length = new FileInfo(file).Length;
        if (length == 0 || length + incomingBytes <= _maxBytes) return;

        var archive = BuildArchivePath();
        File.Move(file, archive);
    }

    private static string BuildArchivePath()
    {
        var stamp = DateTime.Now.ToString("yyyyMMdd-HHmmss-fff");
        var path = Path.Combine(_directory, $"{BaseFileName}-{stamp}.log");
        var counter = 1;
        while (File.Exists(path))
        {
            path = Path.Combine(_directory, $"{BaseFileName}-{stamp}-{counter++}.log");
        }
        return path;
    }

    /// <summary>Buộc xoay vòng ngay (dùng cho minh họa Bài 7 và bộ kiểm thử).</summary>
    public static string RotateNow()
    {
        lock (Sync)
        {
            EnsureConfigured();
            Directory.CreateDirectory(_directory);
            var file = Path.Combine(_directory, BaseFileName + ".log");
            if (!File.Exists(file) || new FileInfo(file).Length == 0)
            {
                Info("Không có dữ liệu để xoay vòng (tệp log đang trống).", LogCategories.App);
                return "";
            }

            var archive = BuildArchivePath();
            File.Move(file, archive);
            Info($"Đã xoay vòng nhật ký sang tệp {Path.GetFileName(archive)}.", LogCategories.App);
            CleanupOldFilesInternal();
            return archive;
        }
    }

    public static int CleanupOldFiles()
    {
        lock (Sync)
        {
            EnsureConfigured();
            return CleanupOldFilesInternal();
        }
    }

    private static int CleanupOldFilesInternal()
    {
        var removed = 0;
        try
        {
            if (!Directory.Exists(_directory)) return 0;
            var cutoff = DateTime.Now.AddDays(-_retentionDays);
            foreach (var path in Directory.EnumerateFiles(_directory, BaseFileName + "-*.log"))
            {
                try
                {
                    if (File.GetLastWriteTime(path) < cutoff)
                    {
                        File.Delete(path);
                        removed++;
                    }
                }
                catch
                {
                    // Bỏ qua tệp đang bị khóa.
                }
            }
        }
        catch
        {
            // Bỏ qua lỗi duyệt thư mục.
        }
        return removed;
    }

    public static IReadOnlyList<LogEntry> GetRecent(int count = 200)
    {
        lock (Sync)
        {
            if (count <= 0) count = 200;
            var snapshot = RecentEntries.ToArray();
            var start = Math.Max(0, snapshot.Length - count);
            return snapshot.Skip(start).Reverse().ToArray();
        }
    }

    public static IReadOnlyList<string> GetLogFiles()
    {
        lock (Sync)
        {
            EnsureConfigured();
            try
            {
                if (!Directory.Exists(_directory)) return Array.Empty<string>();
                return Directory.EnumerateFiles(_directory, BaseFileName + "*.log")
                    .OrderByDescending(File.GetLastWriteTime)
                    .ToArray();
            }
            catch
            {
                return Array.Empty<string>();
            }
        }
    }

    public static string ReadCurrentFileTail(int maxCharacters = 20000)
    {
        lock (Sync)
        {
            EnsureConfigured();
            try
            {
                var file = Path.Combine(_directory, BaseFileName + ".log");
                if (!File.Exists(file)) return "(tệp nhật ký chưa có nội dung)";
                using var stream = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                using var reader = new StreamReader(stream, Encoding.UTF8);
                var text = reader.ReadToEnd();
                if (text.Length <= maxCharacters) return text;
                return "… (phần đầu đã lược bớt)" + Environment.NewLine +
                       text.Substring(text.Length - maxCharacters);
            }
            catch (Exception ex)
            {
                return "(không đọc được tệp nhật ký: " + ex.Message + ")";
            }
        }
    }

    public static void ClearRecentForTests()
    {
        lock (Sync)
        {
            RecentEntries.Clear();
        }
    }

    private static void EnsureConfigured()
    {
        if (_configured) return;
        _configured = true;
        try
        {
            Directory.CreateDirectory(_directory);
        }
        catch
        {
            // Sẽ được báo qua LastWriteError khi ghi thật sự.
        }
    }
}
