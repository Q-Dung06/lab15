using System.Data;

namespace Lab15.BUS;

/// <summary>Khoa trong hệ thống QLSinhVien.</summary>
public sealed record FacultyDto(string MaKhoa, string TenKhoa)
{
    public override string ToString() => $"{MaKhoa} - {TenKhoa}";
}

/// <summary>Một dòng sinh viên hiển thị trên lưới.</summary>
public sealed class SinhVienDto
{
    public string MaSV { get; init; } = "";
    public string HoTen { get; init; } = "";
    public DateTime NgaySinh { get; init; }
    public bool GioiTinh { get; init; }
    public string GioiTinhText { get; init; } = "";
    public string MaKhoa { get; init; } = "";
    public string TenKhoa { get; init; } = "";
    public decimal DiemTB { get; init; }
    public string? Email { get; init; }
    public bool IsActive { get; init; }
    public int SoDangKy { get; init; }

    public string TrangThaiText => IsActive ? "Đang học" : "Ngừng học";

    public static SinhVienDto FromRow(DataRow row)
    {
        return new SinhVienDto
        {
            MaSV = Convert.ToString(row["MaSV"]) ?? string.Empty,
            HoTen = Convert.ToString(row["HoTen"]) ?? string.Empty,
            NgaySinh = row["NgaySinh"] is DateTime date ? date : Convert.ToDateTime(row["NgaySinh"]),
            GioiTinh = string.Equals(Convert.ToString(row["GioiTinh"]), "Nam", StringComparison.OrdinalIgnoreCase),
            GioiTinhText = Convert.ToString(row["GioiTinh"]) ?? string.Empty,
            MaKhoa = Convert.ToString(row["MaKhoa"]) ?? string.Empty,
            TenKhoa = Convert.ToString(row["TenKhoa"]) ?? string.Empty,
            DiemTB = Convert.ToDecimal(row["DiemTB"]),
            Email = row["Email"] == DBNull.Value ? null : Convert.ToString(row["Email"]),
            IsActive = Convert.ToBoolean(row["IsActive"]),
            SoDangKy = row["SoDangKy"] == DBNull.Value ? 0 : Convert.ToInt32(row["SoDangKy"])
        };
    }
}

/// <summary>
/// Dữ liệu thô từ form nhập. Giữ dạng chuỗi để tầng kiểm tra có thể báo nhiều lỗi
/// trên cùng một lần nhập (Bài 2).
/// </summary>
public sealed class StudentInput
{
    public string MaSV { get; set; } = "";
    public string HoTen { get; set; } = "";
    public string NgaySinh { get; set; } = "";
    public bool GioiTinh { get; set; }
    public string MaKhoa { get; set; } = "";
    public string DiemTB { get; set; } = "";
    public string Email { get; set; } = "";
    public bool IsActive { get; set; } = true;
    public bool IsEdit { get; set; }

    public static StudentInput FromDto(SinhVienDto dto) => new()
    {
        MaSV = dto.MaSV,
        HoTen = dto.HoTen,
        NgaySinh = dto.NgaySinh.ToString("dd/MM/yyyy"),
        GioiTinh = dto.GioiTinh,
        MaKhoa = dto.MaKhoa,
        DiemTB = dto.DiemTB.ToString("0.##"),
        Email = dto.Email ?? "",
        IsActive = dto.IsActive,
        IsEdit = true
    };
}

/// <summary>Tên nhóm log dùng thống nhất trong toàn ứng dụng.</summary>
public static class LogCategories
{
    public const string App = "App";
    public const string Config = "Config";
    public const string Validation = "Validation";
    public const string Student = "StudentService";
    public const string Preflight = "Preflight";
    public const string Export = "Export";
    public const string Deployment = "Deployment";
    public const string Ui = "UI";
    public const string Global = "GlobalException";
    public const string Security = "Security";
}
