using System.Configuration;
using System.Globalization;
using Lab15.DAL;

namespace Lab15.BUS;

/// <summary>
/// Bài 5 – Đọc cấu hình từ App.config (connection string, ReportFolder, LogFolder…).
/// Mọi giá trị đều có mặc định an toàn để ứng dụng vẫn khởi động được khi tệp
/// cấu hình thiếu hoặc sai.
/// </summary>
public sealed class AppConfig
{
    private static readonly object Sync = new();
    private static AppConfig? _current;

    private AppConfig()
    {
    }

    public static AppConfig Current
    {
        get
        {
            lock (Sync)
            {
                return _current ??= Load();
            }
        }
    }

    public static AppConfig Reload()
    {
        lock (Sync)
        {
            ConfigurationManager.RefreshSection("appSettings");
            ConfigurationManager.RefreshSection("connectionStrings");
            _current = Load();
            return _current;
        }
    }

    public string ConfigFilePath { get; private init; } = "";

    public string AppDisplayName { get; private init; } = "Lab 15 - Xử lý lỗi, logging và đóng gói";

    public string RawConnectionString { get; private init; } = "";

    public string LogFolder { get; private init; } = "";

    public string ReportFolder { get; private init; } = "";

    public int LogMaxSizeKB { get; private init; } = 2048;

    public int LogRetentionDays { get; private init; } = 30;

    public LogLevel MinimumLogLevel { get; private init; } = LogLevel.Info;

    public string LogLevelText { get; private init; } = "INFO";

    public bool IsProtectedConnection { get; private init; }

    public IReadOnlyList<KeyValuePair<string, string>> DisplaySettings { get; private set; } = Array.Empty<KeyValuePair<string, string>>();

    public static string ResolveConfigPath()
    {
        var fromEnvironment = Environment.GetEnvironmentVariable("APP_CONFIG_FILE");
        if (!string.IsNullOrWhiteSpace(fromEnvironment)) return Path.GetFullPath(fromEnvironment);

        var local = Path.Combine(AppContext.BaseDirectory, "App.config");
        if (File.Exists(local)) return local;

        try
        {
            return ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None).FilePath;
        }
        catch
        {
            return local;
        }
    }

    private static AppConfig Load()
    {
        var configPath = ResolveConfigPath();
        var reportFolder = ReadString("ReportFolder", "Reports");
        var logFolder = ReadString("LogFolder", "Logs");

        var maxSize = ReadInt("LogMaxSizeKB", 2048, 16, 1024 * 1024);
        var retention = ReadInt("LogRetentionDays", 30, 1, 3650);
        var levelText = ReadString("LogLevel", "INFO").ToUpperInvariant();
        var level = AppLogger.ParseLevel(levelText);

        var connectionString = "";
        try
        {
            connectionString = ConfigurationManager.ConnectionStrings["QLSinhVien"]?.ConnectionString ?? "";
        }
        catch
        {
            // App.config hỏng: để trống, phần kiểm tra trước khi chạy sẽ báo lỗi rõ ràng.
        }

        var config = new AppConfig
        {
            ConfigFilePath = configPath,
            AppDisplayName = ReadString("AppDisplayName", "Lab 15 - Xử lý lỗi, logging và đóng gói"),
            RawConnectionString = connectionString,
            LogFolder = ResolveFolder(logFolder),
            ReportFolder = ResolveFolder(reportFolder),
            LogMaxSizeKB = maxSize,
            LogRetentionDays = retention,
            MinimumLogLevel = level,
            LogLevelText = levelText,
            IsProtectedConnection = ConnectionStringProtector.IsProtected
        };

        config.DisplaySettings = new List<KeyValuePair<string, string>>
        {
            new("Tệp cấu hình", config.ConfigFilePath),
            new("AppDisplayName", config.AppDisplayName),
            new("ReportFolder", config.ReportFolder),
            new("LogFolder", config.LogFolder),
            new("LogMaxSizeKB", config.LogMaxSizeKB.ToString(CultureInfo.InvariantCulture)),
            new("LogRetentionDays", config.LogRetentionDays.ToString(CultureInfo.InvariantCulture)),
            new("LogLevel", config.LogLevelText),
            new("Bảo vệ chuỗi kết nối", config.IsProtectedConnection ? "Có (DPAPI)" : "Không")
        };

        return config;
    }

    private static string ReadString(string key, string fallback)
    {
        try
        {
            var value = ConfigurationManager.AppSettings[key];
            return string.IsNullOrWhiteSpace(value) ? fallback : value.Trim();
        }
        catch
        {
            return fallback;
        }
    }

    private static int ReadInt(string key, int fallback, int min, int max)
    {
        var text = ReadString(key, fallback.ToString(CultureInfo.InvariantCulture));
        if (!int.TryParse(text, NumberStyles.Integer, CultureInfo.InvariantCulture, out var value))
            return fallback;
        return Math.Clamp(value, min, max);
    }

    private static string ResolveFolder(string folder)
    {
        var candidate = string.IsNullOrWhiteSpace(folder) ? "Reports" : folder.Trim();
        return Path.IsPathRooted(candidate)
            ? Path.GetFullPath(candidate)
            : Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, candidate));
    }

    /// <summary>Chuỗi kết nối thực tế (ưu tiên tệp bảo vệ DPAPI rồi mới đến App.config).</summary>
    public string GetConnectionString() => DbConnectionFactory.GetConnectionString();

    /// <summary>Chuỗi kết nối đã che mật khẩu, an toàn để hiển thị và ghi log.</summary>
    public string GetMaskedConnectionString()
    {
        try
        {
            return ConnectionStringProtector.Mask(GetConnectionString());
        }
        catch (Exception ex)
        {
            return $"(không đọc được: {ex.Message})";
        }
    }

    /// <summary>Tạo các thư mục cần thiết; trả về danh sách lỗi (rỗng nếu thành công).</summary>
    public IReadOnlyList<string> EnsureDirectories()
    {
        var errors = new List<string>();
        foreach (var folder in new[] { LogFolder, ReportFolder })
        {
            try
            {
                Directory.CreateDirectory(folder);
            }
            catch (Exception ex)
            {
                errors.Add($"Không tạo được thư mục '{folder}': {ex.Message}");
            }
        }
        return errors;
    }

    public string Describe()
    {
        var builder = new System.Text.StringBuilder();
        foreach (var setting in DisplaySettings)
            builder.AppendLine($"{setting.Key} = {setting.Value}");
        return builder.ToString().TrimEnd();
    }
}
