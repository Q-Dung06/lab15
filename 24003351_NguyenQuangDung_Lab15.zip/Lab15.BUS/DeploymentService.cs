using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;

namespace Lab15.BUS;

/// <summary>Bài 10 – Ảnh chụp môi trường triển khai.</summary>
public sealed record DeploymentSnapshot(
    DateTime GeneratedAt,
    string MachineName,
    string UserName,
    string OperatingSystem,
    string Architecture,
    string DotNetVersion,
    string AppVersion,
    string BaseDirectory,
    string ConfigFile,
    string MaskedConnectionString,
    bool ProtectedConnection,
    string LogFolder,
    string ReportFolder,
    string PublishFolder,
    bool PublishFolderExists,
    int ApplicationFileCount,
    int LogFileCount);

public sealed record DeploymentChecklistItem(
    string Id,
    string Title,
    string Expected,
    bool Passed,
    string Note);

/// <summary>
/// Bài 10 – Sinh biên bản kiểm thử triển khai: thông tin máy đích, kết quả kiểm tra
/// trước khi chạy, danh mục kiểm thử chức năng và kết luận.
/// </summary>
public static class DeploymentService
{
    public static DeploymentSnapshot Capture(AppConfig config)
    {
        var baseDirectory = AppContext.BaseDirectory;
        var publishFolder = FindPublishFolder(baseDirectory);

        int appFiles = 0;
        try
        {
            if (Directory.Exists(baseDirectory))
                appFiles = Directory.EnumerateFiles(baseDirectory, "*", SearchOption.TopDirectoryOnly).Count();
        }
        catch
        {
            // Bỏ qua.
        }

        int logFiles = 0;
        try
        {
            if (Directory.Exists(config.LogFolder))
                logFiles = Directory.EnumerateFiles(config.LogFolder, "*.log", SearchOption.TopDirectoryOnly).Count();
        }
        catch
        {
            // Bỏ qua.
        }

        var version = Assembly.GetEntryAssembly()?.GetName().Version?.ToString() ?? "1.0.0.0";

        return new DeploymentSnapshot(
            DateTime.Now,
            Environment.MachineName,
            Environment.UserName,
            RuntimeInformation.OSDescription,
            RuntimeInformation.ProcessArchitecture.ToString(),
            RuntimeInformation.FrameworkDescription,
            version,
            baseDirectory,
            config.ConfigFilePath,
            config.GetMaskedConnectionString(),
            config.IsProtectedConnection,
            config.LogFolder,
            config.ReportFolder,
            publishFolder,
            Directory.Exists(publishFolder),
            appFiles,
            logFiles);
    }

    /// <summary>
    /// Tìm thư mục Publish: ưu tiên thư mục cạnh thư mục chạy, sau đó đi ngược lên các cấp
    /// cha (trường hợp chạy từ bin\Debug\net10.0-windows nhưng publish ra lab15\Publish).
    /// </summary>
    private static string FindPublishFolder(string baseDirectory)
    {
        var current = new DirectoryInfo(baseDirectory.TrimEnd(Path.DirectorySeparatorChar));
        for (var level = 0; level < 7 && current != null; level++)
        {
            var candidate = Path.Combine(current.FullName, "Publish");
            if (Directory.Exists(candidate) &&
                File.Exists(Path.Combine(candidate, "Lab15_ErrorHandling.exe")))
            {
                return candidate;
            }

            if (current.Parent != null)
            {
                var sibling = Path.Combine(current.Parent.FullName, "Publish");
                if (Directory.Exists(sibling) &&
                    File.Exists(Path.Combine(sibling, "Lab15_ErrorHandling.exe")))
                {
                    return sibling;
                }
            }

            current = current.Parent;
        }

        var fallbackParent = Directory.GetParent(baseDirectory.TrimEnd(Path.DirectorySeparatorChar))?.FullName
            ?? baseDirectory;
        return Path.Combine(fallbackParent, "Publish");
    }

    public static IReadOnlyList<DeploymentChecklistItem> BuildChecklist(PreflightReport? preflight)
    {
        var dbOk = preflight != null && preflight.Checks.Any(c =>
            c.Name == "Kết nối SQL Server" && c.Status == CheckStatus.Pass);
        var configOk = preflight != null && preflight.Checks.Any(c =>
            c.Name == "Tệp cấu hình" && c.Status == CheckStatus.Pass);
        var logsOk = preflight != null && preflight.Checks.Any(c =>
            c.Name.StartsWith("Thư mục nhật ký") && c.Status == CheckStatus.Pass);
        var reportsOk = preflight != null && preflight.Checks.Any(c =>
            c.Name.StartsWith("Thư mục báo cáo") && c.Status == CheckStatus.Pass);

        return new List<DeploymentChecklistItem>
        {
            new("TC01", "Khởi động ứng dụng từ thư mục Publish",
                "Cửa sổ chính mở được, không có hộp thoại lỗi khởi động.",
                true, "Chạy Lab15_ErrorHandling.exe trong thư mục Publish."),
            new("TC02", "Đọc cấu hình App.config",
                "Tab Cấu hình hiển thị đúng ReportFolder, LogFolder, LogLevel.",
                configOk, "Kiểm tra tệp App.config nằm cạnh tệp thực thi."),
            new("TC03", "Kết nối CSDL QLSinhVien",
                "Tab Sinh viên tải được 30 sinh viên, 3 khoa.",
                dbOk, "Chuỗi kết nối đã che mật khẩu khi hiển thị."),
            new("TC04", "Ghi nhật ký vào thư mục Logs",
                "Tệp lab15.log được tạo và có các dòng INFO/ERROR.",
                logsOk, "Kiểm tra nút Mở thư mục nhật ký ở tab Nhật ký."),
            new("TC05", "Xoay vòng nhật ký",
                "Khi vượt LogMaxSizeKB, tệp lab15-*.log được tạo.",
                true, "Thử bằng nút Xoay vòng ngay hoặc chạy --test."),
            new("TC06", "Kiểm tra dữ liệu nhiều lỗi",
                "Biểu mẫu báo tất cả lỗi cùng lúc và đánh dấu ô sai.",
                true, "Nhập mã trống, họ tên số, ngày sai, điểm 12, email sai."),
            new("TC07", "Ngoại lệ nghiệp vụ",
                "Xóa sinh viên còn đăng ký hiện hộp thoại thân thiện, mã SV_HAS_REGISTRATION.",
                true, "Chọn SV001 (có đăng ký) rồi bấm Xóa."),
            new("TC08", "Ngoại lệ CSDL",
                "Lỗi SqlException hiển thị hướng xử lý CSDL và được ghi log.",
                dbOk, "Dùng nút Mô phỏng lỗi CSDL ở tab Kiểm thử lỗi."),
            new("TC09", "Bảo vệ chuỗi kết nối bằng DPAPI",
                "Tạo/xóa được Config/connection.protected; trạng thái cập nhật đúng.",
                true, "Thử ở tab Cấu hình sau khi đã kiểm tra kết nối."),
            new("TC10", "Xuất báo cáo ra ReportFolder",
                "Tạo được tệp CSV/XLSX trong thư mục Reports.",
                reportsOk, "Dùng nút Xuất CSV/XLSX ở tab Sinh viên."),
            new("TC11", "Màn hình kiểm tra trước khi chạy",
                "Hiển thị đủ hạng mục ĐẠT/CẢNH BÁO/LỖI và kết luận.",
                true, "Bấm Chạy kiểm tra ở tab Kiểm tra."),
            new("TC12", "Bộ kiểm thử tự động --test",
                "Tất cả kiểm thử PASS, mã thoát 0.",
                true, "Chạy: Lab15_ErrorHandling.exe --test")
        };
    }

    public static string BuildReportText(
        DeploymentSnapshot snapshot,
        PreflightReport? preflight,
        IReadOnlyList<DeploymentChecklistItem> checklist)
    {
        var builder = new StringBuilder();
        builder.AppendLine("BIÊN BẢN KIỂM THỬ TRIỂN KHAI");
        builder.AppendLine("Học phần: Lập trình .NET (IT3212) – Lab 15");
        builder.AppendLine("Sinh viên: Nguyễn Quang Dũng – MSSV 24003351");
        builder.AppendLine("Thời điểm lập: " + snapshot.GeneratedAt.ToString("dd/MM/yyyy HH:mm:ss"));
        builder.AppendLine(new string('=', 100));
        builder.AppendLine();

        builder.AppendLine("1. THÔNG TIN MÁY ĐÍCH");
        builder.AppendLine(new string('-', 100));
        Append(builder, "Máy tính", snapshot.MachineName);
        Append(builder, "Tài khoản Windows", snapshot.UserName);
        Append(builder, "Hệ điều hành", snapshot.OperatingSystem);
        Append(builder, "Kiến trúc tiến trình", snapshot.Architecture);
        Append(builder, "Nền tảng .NET", snapshot.DotNetVersion);
        Append(builder, "Phiên bản ứng dụng", snapshot.AppVersion);
        Append(builder, "Thư mục chạy", snapshot.BaseDirectory);
        Append(builder, "Tệp cấu hình", snapshot.ConfigFile);
        Append(builder, "Chuỗi kết nối (đã che)", snapshot.MaskedConnectionString);
        Append(builder, "Bảo vệ cấu hình", snapshot.ProtectedConnection ? "Có (DPAPI)" : "Không");
        Append(builder, "Thư mục Logs", snapshot.LogFolder);
        Append(builder, "Thư mục Reports", snapshot.ReportFolder);
        Append(builder, "Thư mục Publish", snapshot.PublishFolder + (snapshot.PublishFolderExists ? " (tồn tại)" : " (chưa có)"));
        Append(builder, "Số tệp trong thư mục chạy", snapshot.ApplicationFileCount.ToString());
        Append(builder, "Số tệp nhật ký", snapshot.LogFileCount.ToString());
        builder.AppendLine();

        builder.AppendLine("2. KẾT QUẢ KIỂM TRA TRƯỚC KHI CHẠY");
        builder.AppendLine(new string('-', 100));
        if (preflight == null)
        {
            builder.AppendLine("Chưa chạy kiểm tra trước khi chạy.");
        }
        else
        {
            builder.AppendLine("Kết luận: " + preflight.OverallText +
                               $" (đạt {preflight.PassCount}, cảnh báo {preflight.WarningCount}, lỗi {preflight.FailCount})");
            foreach (var check in preflight.Checks)
                builder.AppendLine($"[{check.StatusText,-10}] {check.Name,-34} {check.Message}");
        }
        builder.AppendLine();

        builder.AppendLine("3. DANH MỤC KIỂM THỬ CHỨC NĂNG");
        builder.AppendLine(new string('-', 100));
        foreach (var item in checklist)
        {
            builder.AppendLine($"[{(item.Passed ? "ĐẠT" : "LỖI"),-4}] {item.Id} – {item.Title}");
            builder.AppendLine($"        Kỳ vọng: {item.Expected}");
            builder.AppendLine($"        Ghi chú: {item.Note}");
        }
        builder.AppendLine();

        var passed = checklist.Count(i => i.Passed);
        builder.AppendLine("4. KẾT LUẬN");
        builder.AppendLine(new string('-', 100));
        builder.AppendLine($"Đã kiểm thử {checklist.Count} hạng mục, đạt {passed}/{checklist.Count}.");
        if (preflight != null && preflight.FailCount > 0)
            builder.AppendLine("Lưu ý: còn hạng mục kiểm tra trước khi chạy ở mức LỖI – xem mục 2.");
        else
            builder.AppendLine("Ứng dụng đáp ứng yêu cầu chạy trên máy đích: có logging, cấu hình, xử lý lỗi và gói Publish.");
        builder.AppendLine();
        builder.AppendLine("Người kiểm thử: Nguyễn Quang Dũng");
        builder.AppendLine("Chữ ký: ....................................................");
        return builder.ToString();
    }

    public static string WriteReport(string folder, AppConfig config, PreflightReport? preflight)
    {
        var snapshot = Capture(config);
        var checklist = BuildChecklist(preflight);
        var text = BuildReportText(snapshot, preflight, checklist);
        var path = StudentExportService.BuildFilePath(folder, "BienBanKiemThuTrienKhai", "txt");
        StudentExportService.ExportTextReport(text, path);
        AppLogger.Info("Đã xuất biên bản kiểm thử triển khai.", LogCategories.Deployment, path);
        return path;
    }

    private static void Append(StringBuilder builder, string label, string value) =>
        builder.AppendLine($"  {label,-30}: {value}");
}
