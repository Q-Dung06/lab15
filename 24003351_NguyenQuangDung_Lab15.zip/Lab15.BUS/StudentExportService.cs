using System.Globalization;
using System.IO.Compression;
using System.Text;

namespace Lab15.BUS;

/// <summary>
/// Xuất dữ liệu ra thư mục Reports (Bài 5): CSV, XLSX và báo cáo văn bản.
/// XLSX được tạo trực tiếp theo chuẩn OOXML để không phụ thuộc thư viện ngoài.
/// </summary>
public static class StudentExportService
{
    private static readonly string[] StudentHeaders =
    {
        "Mã SV", "Họ tên", "Ngày sinh", "Giới tính", "Mã khoa", "Tên khoa",
        "Điểm TB", "Email", "Trạng thái", "Số đăng ký"
    };

    public static string BuildFilePath(string folder, string prefix, string extension)
    {
        Directory.CreateDirectory(folder);
        var stamp = DateTime.Now.ToString("yyyyMMdd-HHmmss");
        return Path.Combine(folder, $"{prefix}-{stamp}.{extension.TrimStart('.')}");
    }

    public static string ExportStudentsCsv(IEnumerable<SinhVienDto> students, string filePath)
    {
        var builder = new StringBuilder();
        builder.AppendLine(string.Join(",", StudentHeaders.Select(EscapeCsv)));
        foreach (var sv in students)
        {
            builder.AppendLine(string.Join(",",
                EscapeCsv(sv.MaSV),
                EscapeCsv(sv.HoTen),
                EscapeCsv(sv.NgaySinh.ToString("dd/MM/yyyy")),
                EscapeCsv(sv.GioiTinhText),
                EscapeCsv(sv.MaKhoa),
                EscapeCsv(sv.TenKhoa),
                sv.DiemTB.ToString("0.##", CultureInfo.InvariantCulture),
                EscapeCsv(sv.Email ?? ""),
                EscapeCsv(sv.TrangThaiText),
                sv.SoDangKy.ToString(CultureInfo.InvariantCulture)));
        }

        var fullPath = Prepare(filePath);
        File.WriteAllText(fullPath, builder.ToString(), new UTF8Encoding(true));
        AppLogger.Info($"Đã xuất CSV sinh viên: {fullPath}", LogCategories.Export);
        return fullPath;
    }

    public static string ExportStudentsXlsx(IReadOnlyList<SinhVienDto> students, string filePath)
    {
        var fullPath = Prepare(filePath);
        if (File.Exists(fullPath)) File.Delete(fullPath);

        using var archive = ZipFile.Open(fullPath, ZipArchiveMode.Create);
        Write(archive, "[Content_Types].xml", ContentTypes);
        Write(archive, "_rels/.rels", RootRelationships);
        Write(archive, "xl/workbook.xml", Workbook);
        Write(archive, "xl/_rels/workbook.xml.rels", WorkbookRelationships);
        Write(archive, "xl/styles.xml", Styles);
        Write(archive, "xl/worksheets/sheet1.xml", BuildSheet(students));

        AppLogger.Info($"Đã xuất XLSX sinh viên: {fullPath}", LogCategories.Export);
        return fullPath;
    }

    public static string ExportLogsCsv(IEnumerable<LogEntry> entries, string filePath)
    {
        var builder = new StringBuilder();
        builder.AppendLine("Thời gian,Mức,Nhóm,Thông điệp,Chi tiết,Ngoại lệ");
        foreach (var entry in entries)
        {
            builder.AppendLine(string.Join(",",
                EscapeCsv(entry.Timestamp.ToString("yyyy-MM-dd HH:mm:ss.fff")),
                EscapeCsv(entry.LevelText),
                EscapeCsv(entry.Category),
                EscapeCsv(entry.Message),
                EscapeCsv(entry.Detail ?? ""),
                EscapeCsv(entry.ExceptionText ?? "")));
        }

        var fullPath = Prepare(filePath);
        File.WriteAllText(fullPath, builder.ToString(), new UTF8Encoding(true));
        AppLogger.Info($"Đã xuất CSV nhật ký: {fullPath}", LogCategories.Export);
        return fullPath;
    }

    public static string ExportTextReport(string content, string filePath)
    {
        var fullPath = Prepare(filePath);
        File.WriteAllText(fullPath, content, new UTF8Encoding(true));
        AppLogger.Info($"Đã xuất báo cáo văn bản: {fullPath}", LogCategories.Export);
        return fullPath;
    }

    private static string Prepare(string filePath)
    {
        var fullPath = Path.GetFullPath(filePath);
        var folder = Path.GetDirectoryName(fullPath);
        if (!string.IsNullOrWhiteSpace(folder)) Directory.CreateDirectory(folder);
        return fullPath;
    }

    private static string EscapeCsv(string? value)
    {
        var text = value ?? string.Empty;
        if (text.Contains('"')) text = text.Replace("\"", "\"\"");
        if (text.Contains(',') || text.Contains('"') || text.Contains('\n') || text.Contains('\r'))
            return "\"" + text + "\"";
        return text;
    }

    private static void Write(ZipArchive archive, string entryName, string content)
    {
        var entry = archive.CreateEntry(entryName, CompressionLevel.Optimal);
        using var stream = entry.Open();
        using var writer = new StreamWriter(stream, new UTF8Encoding(false));
        writer.Write(content);
    }

    private static string BuildSheet(IReadOnlyList<SinhVienDto> students)
    {
        var builder = new StringBuilder();
        builder.Append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""");
        builder.Append("""<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">""");
        builder.Append("""<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>""");
        builder.Append("<cols>");
        var widths = new[] { 12, 28, 12, 10, 10, 26, 10, 30, 14, 10 };
        for (var i = 0; i < widths.Length; i++)
            builder.Append($"""<col min="{i + 1}" max="{i + 1}" width="{widths[i]}" customWidth="1"/>""");
        builder.Append("</cols><sheetData>");

        // Dòng tiêu đề.
        builder.Append("""<row r="1" ht="20" customHeight="1">""");
        for (var i = 0; i < StudentHeaders.Length; i++)
        {
            builder.Append($"""<c r="{CellRef(i, 1)}" t="inlineStr" s="1"><is><t>{Xml(StudentHeaders[i])}</t></is></c>""");
        }
        builder.Append("</row>");

        var rowIndex = 2;
        foreach (var sv in students)
        {
            builder.Append($"""<row r="{rowIndex}">""");
            var values = new[]
            {
                sv.MaSV, sv.HoTen, sv.NgaySinh.ToString("dd/MM/yyyy"), sv.GioiTinhText,
                sv.MaKhoa, sv.TenKhoa, null, sv.Email ?? "", sv.TrangThaiText, null
            };

            for (var column = 0; column < values.Length; column++)
            {
                var reference = CellRef(column, rowIndex);
                switch (column)
                {
                    case 6:
                        builder.Append($"""<c r="{reference}" s="2"><v>{sv.DiemTB.ToString("0.##", CultureInfo.InvariantCulture)}</v></c>""");
                        break;
                    case 9:
                        builder.Append($"""<c r="{reference}"><v>{sv.SoDangKy.ToString(CultureInfo.InvariantCulture)}</v></c>""");
                        break;
                    default:
                        builder.Append($"""<c r="{reference}" t="inlineStr"><is><t>{Xml(values[column] ?? "")}</t></is></c>""");
                        break;
                }
            }
            builder.Append("</row>");
            rowIndex++;
        }

        builder.Append("</sheetData>");
        if (students.Count > 0)
            builder.Append($"""<autoFilter ref="A1:J{rowIndex - 1}"/>""");
        builder.Append("</worksheet>");
        return builder.ToString();
    }

    private static string CellRef(int columnIndex, int row)
    {
        var name = new StringBuilder();
        var value = columnIndex + 1;
        while (value > 0)
        {
            var remainder = (value - 1) % 26;
            name.Insert(0, (char)('A' + remainder));
            value = (value - 1) / 26;
        }
        return name + row.ToString(CultureInfo.InvariantCulture);
    }

    private static string Xml(string? value) =>
        (value ?? string.Empty)
            .Replace("&", "&amp;")
            .Replace("<", "&lt;")
            .Replace(">", "&gt;")
            .Replace("\"", "&quot;");

    private const string ContentTypes = """
        <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
        <Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
          <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
          <Default Extension="xml" ContentType="application/xml"/>
          <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
          <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
          <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
        </Types>
        """;

    private const string RootRelationships = """
        <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
        <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
          <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
        </Relationships>
        """;

    private const string Workbook = """
        <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
        <workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
                  xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
          <sheets>
            <sheet name="SinhVien" sheetId="1" r:id="rId1"/>
          </sheets>
        </workbook>
        """;

    private const string WorkbookRelationships = """
        <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
        <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
          <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
          <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
        </Relationships>
        """;

    private const string Styles = """
        <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
        <styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
          <fonts count="2">
            <font><sz val="11"/><name val="Calibri"/></font>
            <font><b/><sz val="11"/><name val="Calibri"/></font>
          </fonts>
          <fills count="2">
            <fill><patternFill patternType="none"/></fill>
            <fill><patternFill patternType="gray125"/></fill>
          </fills>
          <borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
          <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
          <cellXfs count="3">
            <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
            <xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/>
            <xf numFmtId="2" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
          </cellXfs>
          <cellStyles count="1">
            <cellStyle name="Normal" xfId="0" builtinId="0"/>
          </cellStyles>
          <dxfs count="0"/>
        </styleSheet>
        """;
}
