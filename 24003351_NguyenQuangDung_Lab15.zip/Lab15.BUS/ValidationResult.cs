using System.Text;

namespace Lab15.BUS;

/// <summary>
/// Bài 2 – Kết quả kiểm tra dữ liệu. Cho phép tích lũy nhiều lỗi cùng lúc
/// thay vì dừng ở lỗi đầu tiên như khi ném ngoại lệ ngay trong vòng lặp.
/// </summary>
public sealed class ValidationResult
{
    private readonly Dictionary<string, string> _errors = new(StringComparer.OrdinalIgnoreCase);
    private readonly List<string> _warnings = new();

    public bool IsValid => _errors.Count == 0;

    public int ErrorCount => _errors.Count;

    public IReadOnlyDictionary<string, string> Errors => _errors;

    public IReadOnlyList<string> Warnings => _warnings;

    public string? this[string field] =>
        _errors.TryGetValue(field, out var message) ? message : null;

    public ValidationResult Add(string field, string message)
    {
        if (string.IsNullOrWhiteSpace(field)) field = "Chung";
        if (string.IsNullOrWhiteSpace(message)) return this;

        if (_errors.TryGetValue(field, out var existing))
            _errors[field] = existing + " " + message.Trim();
        else
            _errors[field] = message.Trim();

        return this;
    }

    public ValidationResult AddWarning(string message)
    {
        if (!string.IsNullOrWhiteSpace(message)) _warnings.Add(message.Trim());
        return this;
    }

    public bool HasError(string field) => _errors.ContainsKey(field);

    public void AddRange(ValidationResult other)
    {
        foreach (var pair in other.Errors) Add(pair.Key, pair.Value);
        foreach (var warning in other.Warnings) AddWarning(warning);
    }

    /// <summary>Tóm tắt nhiều dòng, mỗi dòng một lỗi – dùng cho hộp thoại.</summary>
    public string Summary
    {
        get
        {
            if (IsValid) return "Dữ liệu hợp lệ.";
            var builder = new StringBuilder();
            foreach (var pair in _errors)
                builder.AppendLine("• " + pair.Value);
            foreach (var warning in _warnings)
                builder.AppendLine("• (Cảnh báo) " + warning);
            return builder.ToString().TrimEnd();
        }
    }
}
