namespace Lab15.BUS;

/// <summary>
/// Bài 1 – Ngoại lệ nghiệp vụ tự định nghĩa.
/// Khác với lỗi hệ thống, BusinessException thể hiện quy tắc nghiệp vụ bị vi phạm
/// và luôn có thông điệp thân thiện để hiển thị cho người dùng cuối.
/// </summary>
public class BusinessException : Exception
{
    public BusinessException(
        string code,
        string message,
        ValidationResult? validation = null,
        string? hint = null,
        Exception? inner = null)
        : base(message, inner)
    {
        Code = string.IsNullOrWhiteSpace(code) ? "BUSINESS_ERROR" : code;
        Validation = validation;
        Hint = hint;
    }

    /// <summary>Mã lỗi ổn định để tra cứu trong log và tài liệu.</summary>
    public string Code { get; }

    /// <summary>Danh sách lỗi nhập liệu kèm theo (nếu có).</summary>
    public ValidationResult? Validation { get; }

    /// <summary>Gợi ý xử lý hiển thị cho người dùng.</summary>
    public string? Hint { get; }

    public string UserMessage =>
        string.IsNullOrWhiteSpace(Hint) ? Message : Message + Environment.NewLine + Environment.NewLine + "Gợi ý: " + Hint;
}

/// <summary>Ngoại lệ dùng khi dữ liệu nhập không vượt qua kiểm tra (Bài 2).</summary>
public sealed class ValidationBusinessException : BusinessException
{
    public ValidationBusinessException(ValidationResult result, string message = "Dữ liệu nhập chưa hợp lệ.")
        : base("VALIDATION_FAILED", message, result, "Sửa các ô được đánh dấu đỏ rồi thực hiện lại.")
    {
    }
}
