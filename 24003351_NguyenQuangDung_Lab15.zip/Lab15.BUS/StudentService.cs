using System.Data;
using System.Data.SqlClient;
using Lab15.DAL;

namespace Lab15.BUS;

/// <summary>
/// Bài 1, 2, 4 – Tầng nghiệp vụ sinh viên.
/// Quy ước xử lý lỗi:
///  • Lỗi quy tắc nghiệp vụ  → BusinessException (thông điệp thân thiện, có mã lỗi).
///  • Lỗi CSDL không dịch được → giữ nguyên SqlException để GUI hiển thị hướng xử lý CSDL.
///  • Mọi lỗi đều được ghi log trước khi ném ra tầng trên.
/// </summary>
public sealed class StudentService
{
    private readonly SinhVienRepository _repository;
    private readonly StudentValidator _validator;

    public StudentService(SinhVienRepository? repository = null, StudentValidator? validator = null)
    {
        _repository = repository ?? new SinhVienRepository();
        _validator = validator ?? new StudentValidator();
    }

    public IReadOnlyList<FacultyDto> GetFaculties()
    {
        try
        {
            var table = _repository.GetFaculties();
            return table.Rows.Cast<DataRow>()
                .Select(row => new FacultyDto(
                    Convert.ToString(row["MaKhoa"]) ?? "",
                    Convert.ToString(row["TenKhoa"]) ?? ""))
                .ToList();
        }
        catch (Exception ex)
        {
            AppLogger.Error("Không đọc được danh sách khoa.", LogCategories.Student, ex);
            throw;
        }
    }

    public IReadOnlyList<SinhVienDto> Search(string? keyword, string? maKhoa, bool includeInactive)
    {
        try
        {
            var table = _repository.Search(keyword, maKhoa, includeInactive);
            return table.Rows.Cast<DataRow>().Select(SinhVienDto.FromRow).ToList();
        }
        catch (Exception ex)
        {
            AppLogger.Error("Tìm kiếm sinh viên thất bại.", LogCategories.Student, ex,
                $"Keyword={keyword}; MaKhoa={maKhoa}; IncludeInactive={includeInactive}");
            throw;
        }
    }

    public SinhVienDto? GetByCode(string maSV)
    {
        if (string.IsNullOrWhiteSpace(maSV)) return null;
        try
        {
            var table = _repository.GetByCode(maSV.Trim());
            return table.Rows.Count == 0 ? null : SinhVienDto.FromRow(table.Rows[0]);
        }
        catch (Exception ex)
        {
            AppLogger.Error($"Không đọc được sinh viên {maSV}.", LogCategories.Student, ex);
            throw;
        }
    }

    /// <summary>
    /// Kiểm tra dữ liệu tĩnh + kiểm tra phụ thuộc CSDL, trả về toàn bộ lỗi cùng lúc.
    /// </summary>
    public ValidationResult Validate(StudentInput input, bool checkDatabase = true)
    {
        var result = _validator.Validate(input);
        if (!checkDatabase) return result;

        var maSV = StudentValidator.NormalizeCode(input.MaSV);
        var email = StudentValidator.NormalizeEmail(input.Email);

        try
        {
            var faculties = GetFaculties();
            if (!string.IsNullOrWhiteSpace(input.MaKhoa) &&
                faculties.All(f => !string.Equals(f.MaKhoa, input.MaKhoa.Trim(), StringComparison.OrdinalIgnoreCase)))
            {
                result.Add("MaKhoa", "Khoa được chọn không tồn tại trong hệ thống.");
            }

            if (!string.IsNullOrWhiteSpace(maSV) && result["MaSV"] == null)
            {
                var exists = _repository.ExistsCode(maSV);
                if (!input.IsEdit && exists)
                    result.Add("MaSV", $"Mã sinh viên '{maSV}' đã tồn tại.");
                else if (input.IsEdit && !exists)
                    result.Add("MaSV", $"Không tìm thấy sinh viên '{maSV}' để cập nhật.");
            }

            if (email.Length > 0 && result["Email"] == null)
            {
                if (_repository.ExistsEmail(email, input.IsEdit ? maSV : null))
                    result.Add("Email", $"Email '{email}' đã được sử dụng bởi sinh viên khác.");
            }
        }
        catch (SqlException ex)
        {
            AppLogger.Error("Không kiểm tra được dữ liệu trùng trong CSDL.", LogCategories.Validation, ex);
            result.Add("CSDL", "Không kết nối được CSDL để kiểm tra dữ liệu trùng. " + ex.Message);
        }

        return result;
    }

    public void Create(StudentInput input)
    {
        input.IsEdit = false;
        var validation = Validate(input, checkDatabase: true);
        if (!validation.IsValid)
        {
            AppLogger.Warn("Thêm sinh viên bị từ chối do dữ liệu không hợp lệ.", LogCategories.Validation,
                validation.Summary);
            throw new ValidationBusinessException(validation);
        }

        var maSV = StudentValidator.NormalizeCode(input.MaSV);
        var email = StudentValidator.NormalizeEmail(input.Email);
        StudentValidator.TryParseDate(input.NgaySinh, out var ngaySinh);
        StudentValidator.TryParseScore(input.DiemTB, out var diemTB);

        try
        {
            _repository.Insert(maSV, input.HoTen.Trim(), ngaySinh, input.GioiTinh,
                input.MaKhoa.Trim(), diemTB,
                email.Length == 0 ? null : email, input.IsActive);

            AppLogger.Info($"Đã thêm sinh viên {maSV} – {input.HoTen.Trim()}.", LogCategories.Student,
                $"MaKhoa={input.MaKhoa}; DiemTB={diemTB:0.##}; Email={(email.Length == 0 ? "(trống)" : email)}");
        }
        catch (SqlException ex)
        {
            AppLogger.Error($"Thêm sinh viên {maSV} thất bại.", LogCategories.Student, ex,
                $"SqlNumber={ex.Number}");
            var business = Translate(ex);
            if (business != null) throw business;
            throw;
        }
    }

    public void Update(StudentInput input)
    {
        input.IsEdit = true;
        var validation = Validate(input, checkDatabase: true);
        if (!validation.IsValid)
        {
            AppLogger.Warn("Cập nhật sinh viên bị từ chối do dữ liệu không hợp lệ.", LogCategories.Validation,
                validation.Summary);
            throw new ValidationBusinessException(validation);
        }

        var maSV = StudentValidator.NormalizeCode(input.MaSV);
        var email = StudentValidator.NormalizeEmail(input.Email);
        StudentValidator.TryParseDate(input.NgaySinh, out var ngaySinh);
        StudentValidator.TryParseScore(input.DiemTB, out var diemTB);

        try
        {
            var affected = _repository.Update(maSV, input.HoTen.Trim(), ngaySinh, input.GioiTinh,
                input.MaKhoa.Trim(), diemTB,
                email.Length == 0 ? null : email, input.IsActive);

            if (affected == 0)
                throw new BusinessException("SV_NOT_FOUND",
                    $"Không tìm thấy sinh viên '{maSV}' để cập nhật.",
                    hint: "Tải lại danh sách và chọn đúng sinh viên.");

            AppLogger.Info($"Đã cập nhật sinh viên {maSV}.", LogCategories.Student,
                $"MaKhoa={input.MaKhoa}; DiemTB={diemTB:0.##}; IsActive={input.IsActive}");
        }
        catch (SqlException ex)
        {
            AppLogger.Error($"Cập nhật sinh viên {maSV} thất bại.", LogCategories.Student, ex,
                $"SqlNumber={ex.Number}");
            var business = Translate(ex);
            if (business != null) throw business;
            throw;
        }
    }

    /// <summary>Đổi trạng thái đang học / ngừng học (xóa mềm).</summary>
    public void SetActive(string maSV, bool active)
    {
        var code = StudentValidator.NormalizeCode(maSV);
        if (code.Length == 0)
            throw new BusinessException("SV_EMPTY", "Chưa chọn sinh viên.",
                hint: "Chọn một dòng trên lưới trước khi thực hiện.");

        var current = GetByCode(code);
        if (current == null)
            throw new BusinessException("SV_NOT_FOUND", $"Không tìm thấy sinh viên '{code}'.",
                hint: "Tải lại danh sách để cập nhật dữ liệu mới nhất.");

        if (current.IsActive == active)
        {
            var state = active ? "đang học" : "ngừng học";
            throw new BusinessException("SV_SAME_STATE",
                $"Sinh viên '{code}' đã ở trạng thái {state}.",
                hint: "Chọn thao tác khác hoặc chọn sinh viên khác.");
        }

        try
        {
            _repository.SetActive(code, active);
            AppLogger.Info($"Đổi trạng thái sinh viên {code} thành {(active ? "Đang học" : "Ngừng học")}.",
                LogCategories.Student);
        }
        catch (SqlException ex)
        {
            AppLogger.Error($"Đổi trạng thái sinh viên {code} thất bại.", LogCategories.Student, ex,
                $"SqlNumber={ex.Number}");
            var business = Translate(ex);
            if (business != null) throw business;
            throw;
        }
    }

    /// <summary>
    /// Xóa sinh viên theo quy tắc nghiệp vụ: không cho xóa nếu còn đăng ký học phần.
    /// Đây là ví dụ điển hình của BusinessException (Bài 1).
    /// </summary>
    public void Delete(string maSV)
    {
        var code = StudentValidator.NormalizeCode(maSV);
        if (code.Length == 0)
            throw new BusinessException("SV_EMPTY", "Chưa chọn sinh viên để xóa.",
                hint: "Chọn một dòng trên lưới.");

        var current = GetByCode(code);
        if (current == null)
            throw new BusinessException("SV_NOT_FOUND", $"Không tìm thấy sinh viên '{code}'.",
                hint: "Tải lại danh sách.");

        var registrations = _repository.CountRegistrations(code);
        if (registrations > 0)
        {
            var ex = new BusinessException(
                "SV_HAS_REGISTRATION",
                $"Không thể xóa sinh viên '{code}' vì còn {registrations} đăng ký học phần.",
                hint: "Hãy chuyển sinh viên sang trạng thái Ngừng học hoặc xóa các đăng ký trước.");
            AppLogger.Warn(ex.Message, LogCategories.Student, $"Code={ex.Code}; MaSV={code}");
            throw ex;
        }

        try
        {
            var affected = _repository.HardDeleteForTest(code);
            if (affected == 0)
                throw new BusinessException("SV_NOT_FOUND", $"Không tìm thấy sinh viên '{code}' để xóa.");

            AppLogger.Info($"Đã xóa sinh viên {code}.", LogCategories.Student);
        }
        catch (SqlException ex)
        {
            AppLogger.Error($"Xóa sinh viên {code} thất bại.", LogCategories.Student, ex,
                $"SqlNumber={ex.Number}");
            var business = Translate(ex);
            if (business != null) throw business;
            throw;
        }
    }

    /// <summary>
    /// Cố tình xóa trực tiếp để CSDL trả lỗi khóa ngoại (SqlException 547).
    /// Dùng cho màn hình "Kiểm thử lỗi" nhằm phân biệt lỗi CSDL với BusinessException.
    /// </summary>
    public void DeleteUnsafeForDemo(string maSV)
    {
        var code = StudentValidator.NormalizeCode(maSV);
        try
        {
            _repository.HardDeleteForTest(code);
        }
        catch (SqlException ex)
        {
            AppLogger.Error($"Xóa trực tiếp sinh viên {code} bị CSDL từ chối.", LogCategories.Student, ex,
                $"SqlNumber={ex.Number}; Demo=SqlException");
            throw;
        }
    }

    /// <summary>Mô phỏng lỗi CSDL thật (bảng không tồn tại) để kiểm thử xử lý lỗi tập trung.</summary>
    public void TriggerDatabaseError()
    {
        try
        {
            _repository.RaiseMissingTableError();
        }
        catch (SqlException ex)
        {
            AppLogger.Error("Mô phỏng lỗi CSDL: bảng không tồn tại.", LogCategories.Student, ex,
                $"SqlNumber={ex.Number}; Demo=SqlException");
            throw;
        }
    }

    /// <summary>Mô phỏng lỗi hệ thống không lường trước để kiểm thử nhánh Exception.</summary>
    public static void TriggerUnexpectedError()
    {
        throw new InvalidOperationException(
            "Lỗi mô phỏng: đối tượng chưa được khởi tạo (dùng để kiểm thử nhánh Exception).");
    }

    public int CountRegistrations(string maSV) =>
        _repository.CountRegistrations(StudentValidator.NormalizeCode(maSV));

    private static BusinessException? Translate(SqlException ex)
    {
        return ex.Number switch
        {
            2601 or 2627 => new BusinessException(
                "DB_DUPLICATE_KEY",
                "Dữ liệu vi phạm ràng buộc duy nhất (mã sinh viên hoặc email đã tồn tại).",
                hint: "Kiểm tra lại Mã sinh viên/Email, tải lại danh sách rồi thử lại.",
                inner: ex),
            547 => new BusinessException(
                "DB_FOREIGN_KEY",
                "Dữ liệu đang được tham chiếu bởi bảng khác nên không thể xóa/sửa.",
                hint: "Xóa hoặc cập nhật các bản ghi liên quan trước (ví dụ đăng ký học phần).",
                inner: ex),
            4060 or 18456 => new BusinessException(
                "DB_LOGIN_FAILED",
                "Không đăng nhập được SQL Server.",
                hint: "Kiểm tra chuỗi kết nối và quyền của tài khoản Windows.",
                inner: ex),
            _ => null
        };
    }
}
