using System.Data;
using System.Data.SqlClient;
using System.Reflection;

namespace Lab15.DAL;

/// <summary>Các truy vấn phục vụ màn hình kiểm tra trước khi chạy (Bài 9).</summary>
public sealed class HealthRepository
{
    public string GetServerVersion()
    {
        using var conn = DbConnectionFactory.Create();
        conn.Open();
        using var cmd = new SqlCommand("SELECT @@VERSION", conn) { CommandTimeout = 10 };
        var text = cmd.ExecuteScalar()?.ToString() ?? string.Empty;
        return text.Split('\n').FirstOrDefault()?.Trim() ?? text.Trim();
    }

    public string GetDatabaseName()
    {
        using var conn = DbConnectionFactory.Create();
        conn.Open();
        using var cmd = new SqlCommand("SELECT DB_NAME()", conn) { CommandTimeout = 10 };
        return cmd.ExecuteScalar()?.ToString() ?? string.Empty;
    }

    public DataTable GetRowCounts()
    {
        const string sql = """
            SELECT 'SinhVien' AS TenBang, COUNT(*) AS SoDong FROM dbo.SinhVien
            UNION ALL
            SELECT 'Khoa', COUNT(*) FROM dbo.Khoa
            UNION ALL
            SELECT 'HocPhan', COUNT(*) FROM dbo.HocPhan
            UNION ALL
            SELECT 'DangKy', COUNT(*) FROM dbo.DangKy;
            """;
        var table = new DataTable("RowCounts");
        using var conn = DbConnectionFactory.Create();
        using var adapter = new SqlDataAdapter(sql, conn);
        adapter.Fill(table);
        return table;
    }

    public bool TableExists(string tableName)
    {
        using var conn = DbConnectionFactory.Create();
        conn.Open();
        using var cmd = new SqlCommand(
            "SELECT COUNT(*) FROM sys.tables WHERE name = @Name AND schema_id = SCHEMA_ID('dbo')", conn);
        cmd.Parameters.Add("@Name", SqlDbType.NVarChar, 128).Value = tableName;
        return Convert.ToInt32(cmd.ExecuteScalar()) > 0;
    }

    public string GetSqlClientVersion()
    {
        return typeof(SqlConnection).Assembly.GetName().Version?.ToString() ?? "?";
    }

    public string GetSqlClientAssemblyLocation()
    {
        try
        {
            return typeof(SqlConnection).Assembly.Location;
        }
        catch
        {
            return "(không xác định)";
        }
    }

    public string GetEntryAssemblyVersion()
    {
        var assembly = Assembly.GetEntryAssembly();
        return assembly?.GetName().Version?.ToString() ?? "?";
    }
}
