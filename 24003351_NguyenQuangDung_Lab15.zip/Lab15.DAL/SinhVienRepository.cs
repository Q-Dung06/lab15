using System.Data;
using System.Data.SqlClient;

namespace Lab15.DAL;

/// <summary>
/// Truy cập dữ liệu sinh viên cho Lab 15. Mọi câu lệnh đều dùng tham số hóa.
/// Repository không bắt SqlException để tầng BUS/GUI phân loại lỗi (Bài 4).
/// </summary>
public sealed class SinhVienRepository
{
    private const int CommandTimeout = 20;

    public DataTable GetFaculties()
    {
        const string sql = "SELECT MaKhoa, TenKhoa FROM dbo.Khoa ORDER BY TenKhoa";
        return Fill(sql, "Faculty");
    }

    public DataTable Search(string? keyword, string? maKhoa, bool includeInactive)
    {
        const string sql = """
            SELECT sv.MaSV,
                   sv.HoTen,
                   sv.NgaySinh,
                   CASE sv.GioiTinh WHEN 1 THEN N'Nam' ELSE N'Nữ' END AS GioiTinh,
                   sv.MaKhoa,
                   k.TenKhoa,
                   sv.DiemTB,
                   sv.Email,
                   sv.IsActive,
                   (SELECT COUNT(*) FROM dbo.DangKy dk WHERE dk.MaSV = sv.MaSV) AS SoDangKy
            FROM dbo.SinhVien sv
            JOIN dbo.Khoa k ON k.MaKhoa = sv.MaKhoa
            WHERE (@Keyword IS NULL
                   OR sv.MaSV LIKE '%' + @Keyword + '%'
                   OR sv.HoTen LIKE N'%' + @Keyword + N'%')
              AND (@MaKhoa IS NULL OR sv.MaKhoa = @MaKhoa)
              AND (@IncludeInactive = 1 OR sv.IsActive = 1)
            ORDER BY sv.MaSV;
            """;

        return Fill(sql, "Student", p =>
        {
            p.Add("@Keyword", SqlDbType.NVarChar, 100).Value =
                string.IsNullOrWhiteSpace(keyword) ? DBNull.Value : keyword.Trim();
            p.Add("@MaKhoa", SqlDbType.VarChar, 10).Value =
                string.IsNullOrWhiteSpace(maKhoa) ? DBNull.Value : maKhoa.Trim();
            p.Add("@IncludeInactive", SqlDbType.Bit).Value = includeInactive;
        });
    }

    public DataTable GetByCode(string maSV)
    {
        const string sql = """
            SELECT sv.MaSV,
                   sv.HoTen,
                   sv.NgaySinh,
                   CASE sv.GioiTinh WHEN 1 THEN N'Nam' ELSE N'Nữ' END AS GioiTinh,
                   sv.MaKhoa,
                   k.TenKhoa,
                   sv.DiemTB,
                   sv.Email,
                   sv.IsActive,
                   (SELECT COUNT(*) FROM dbo.DangKy dk WHERE dk.MaSV = sv.MaSV) AS SoDangKy
            FROM dbo.SinhVien sv
            JOIN dbo.Khoa k ON k.MaKhoa = sv.MaKhoa
            WHERE sv.MaSV = @MaSV;
            """;
        return Fill(sql, "Student", p => p.Add("@MaSV", SqlDbType.VarChar, 15).Value = maSV);
    }

    public bool ExistsCode(string maSV)
    {
        const string sql = "SELECT COUNT(*) FROM dbo.SinhVien WHERE MaSV = @MaSV";
        return Convert.ToInt32(Scalar(sql, p => p.Add("@MaSV", SqlDbType.VarChar, 15).Value = maSV)) > 0;
    }

    public bool ExistsEmail(string email, string? excludeMaSV)
    {
        const string sql = """
            SELECT COUNT(*)
            FROM dbo.SinhVien
            WHERE Email = @Email
              AND (@Exclude IS NULL OR MaSV <> @Exclude)
            """;
        return Convert.ToInt32(Scalar(sql, p =>
        {
            p.Add("@Email", SqlDbType.VarChar, 100).Value = email;
            p.Add("@Exclude", SqlDbType.VarChar, 15).Value =
                string.IsNullOrWhiteSpace(excludeMaSV) ? DBNull.Value : excludeMaSV;
        })) > 0;
    }

    public int CountRegistrations(string maSV)
    {
        const string sql = "SELECT COUNT(*) FROM dbo.DangKy WHERE MaSV = @MaSV";
        return Convert.ToInt32(Scalar(sql, p => p.Add("@MaSV", SqlDbType.VarChar, 15).Value = maSV));
    }

    public int Insert(
        string maSV, string hoTen, DateTime ngaySinh, bool gioiTinh,
        string maKhoa, decimal diemTB, string? email, bool isActive)
    {
        const string sql = """
            INSERT INTO dbo.SinhVien (MaSV, HoTen, NgaySinh, GioiTinh, MaKhoa, DiemTB, Email, IsActive)
            VALUES (@MaSV, @HoTen, @NgaySinh, @GioiTinh, @MaKhoa, @DiemTB, @Email, @IsActive);
            """;
        return Execute(sql, p => AddStudentParameters(p, maSV, hoTen, ngaySinh, gioiTinh, maKhoa, diemTB, email, isActive));
    }

    public int Update(
        string maSV, string hoTen, DateTime ngaySinh, bool gioiTinh,
        string maKhoa, decimal diemTB, string? email, bool isActive)
    {
        const string sql = """
            UPDATE dbo.SinhVien
            SET HoTen = @HoTen,
                NgaySinh = @NgaySinh,
                GioiTinh = @GioiTinh,
                MaKhoa = @MaKhoa,
                DiemTB = @DiemTB,
                Email = @Email,
                IsActive = @IsActive
            WHERE MaSV = @MaSV;
            """;
        return Execute(sql, p => AddStudentParameters(p, maSV, hoTen, ngaySinh, gioiTinh, maKhoa, diemTB, email, isActive));
    }

    public int SetActive(string maSV, bool active)
    {
        const string sql = "UPDATE dbo.SinhVien SET IsActive = @Active WHERE MaSV = @MaSV";
        return Execute(sql, p =>
        {
            p.Add("@MaSV", SqlDbType.VarChar, 15).Value = maSV;
            p.Add("@Active", SqlDbType.Bit).Value = active;
        });
    }

    /// <summary>Chỉ dùng cho bộ kiểm thử tự động để dọn bản ghi tạm (Bài 10 / --test).</summary>
    public int HardDeleteForTest(string maSV)
    {
        const string sql = "DELETE FROM dbo.SinhVien WHERE MaSV = @MaSV";
        return Execute(sql, p => p.Add("@MaSV", SqlDbType.VarChar, 15).Value = maSV);
    }

    /// <summary>Mô phỏng lỗi CSDL thật cho màn hình kiểm thử lỗi (Bài 4).</summary>
    public void RaiseMissingTableError()
    {
        using var conn = DbConnectionFactory.Create();
        conn.Open();
        using var cmd = new SqlCommand("SELECT TOP (1) * FROM dbo.BangKhongTonTai_Lab15", conn)
        {
            CommandTimeout = 5
        };
        cmd.ExecuteReader();
    }

    private static void AddStudentParameters(
        SqlParameterCollection p,
        string maSV, string hoTen, DateTime ngaySinh, bool gioiTinh,
        string maKhoa, decimal diemTB, string? email, bool isActive)
    {
        p.Add("@MaSV", SqlDbType.VarChar, 15).Value = maSV;
        p.Add("@HoTen", SqlDbType.NVarChar, 100).Value = hoTen;
        p.Add("@NgaySinh", SqlDbType.Date).Value = ngaySinh.Date;
        p.Add("@GioiTinh", SqlDbType.Bit).Value = gioiTinh;
        p.Add("@MaKhoa", SqlDbType.VarChar, 10).Value = maKhoa;
        p.Add("@DiemTB", SqlDbType.Decimal).Value = diemTB;
        p.Add("@Email", SqlDbType.VarChar, 100).Value =
            string.IsNullOrWhiteSpace(email) ? DBNull.Value : email;
        p.Add("@IsActive", SqlDbType.Bit).Value = isActive;
    }

    private static DataTable Fill(string sql, string tableName, Action<SqlParameterCollection>? addParameters = null)
    {
        var table = new DataTable(tableName);
        using var conn = DbConnectionFactory.Create();
        using var cmd = new SqlCommand(sql, conn) { CommandTimeout = CommandTimeout };
        addParameters?.Invoke(cmd.Parameters);
        using var adapter = new SqlDataAdapter(cmd);
        adapter.Fill(table);
        return table;
    }

    private static object? Scalar(string sql, Action<SqlParameterCollection> addParameters)
    {
        using var conn = DbConnectionFactory.Create();
        conn.Open();
        using var cmd = new SqlCommand(sql, conn) { CommandTimeout = CommandTimeout };
        addParameters(cmd.Parameters);
        return cmd.ExecuteScalar();
    }

    private static int Execute(string sql, Action<SqlParameterCollection> addParameters)
    {
        using var conn = DbConnectionFactory.Create();
        conn.Open();
        using var cmd = new SqlCommand(sql, conn) { CommandTimeout = CommandTimeout };
        addParameters(cmd.Parameters);
        return cmd.ExecuteNonQuery();
    }
}
