using System.Configuration;
using System.Data.SqlClient;

namespace Lab15.DAL;

/// <summary>
/// Tạo kết nối SQL Server cho Lab 15. Chuỗi kết nối được lấy theo thứ tự:
/// 1. Tệp bảo vệ Config/connection.protected (DPAPI, Bài 8) nếu tồn tại;
/// 2. connectionStrings["QLSinhVien"] trong App.config;
/// 3. Chuỗi mặc định dành cho máy thực hành.
/// </summary>
public static class DbConnectionFactory
{
    public const string DefaultConnectionString =
        "Data Source=.\\SQLEXPRESS;Initial Catalog=QLSinhVien;Integrated Security=True;" +
        "Encrypt=True;TrustServerCertificate=True;Connect Timeout=8;Application Name=Lab15_ErrorHandling";

    public static string GetConnectionString()
    {
        var protectedValue = ConnectionStringProtector.TryReadProtected();
        if (!string.IsNullOrWhiteSpace(protectedValue)) return protectedValue;

        var configured = ConfigurationManager.ConnectionStrings["QLSinhVien"]?.ConnectionString;
        if (string.IsNullOrWhiteSpace(configured))
        {
            throw new ConfigurationErrorsException(
                "Thiếu connection string 'QLSinhVien' trong App.config. " +
                "Xem mục Cấu hình để kiểm tra tệp cấu hình.");
        }
        return configured;
    }

    public static SqlConnection Create() => new(GetConnectionString());
}
