using System.Configuration;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;

namespace Lab15.DAL;

/// <summary>
/// Bài 8 – Bảo vệ chuỗi kết nối.
/// Cách chuẩn của .NET Framework là mã hóa section connectionStrings bằng ProtectedConfiguration
/// (DataProtectionConfigurationProvider); Lab 15 thử trực tiếp trên máy đang chạy và ghi nhận kết quả.
/// Lab 15 cũng cài DPAPI (System.Security.Cryptography.ProtectedData) làm giải pháp tương đương,
/// dùng khi nền tảng không hỗ trợ ProtectedConfiguration: dữ liệu được mã hóa theo tài khoản Windows
/// hiện tại và lưu trong Config/connection.protected.
/// </summary>
public static class ConnectionStringProtector
{
    private static readonly byte[] Entropy = Encoding.UTF8.GetBytes("Lab15.QLSinhVien.ProtectedData.v1");

    public static string ConfigDirectory => Path.Combine(AppContext.BaseDirectory, "Config");

    public static string ProtectedFilePath => Path.Combine(ConfigDirectory, "connection.protected");

    public static bool IsProtected => File.Exists(ProtectedFilePath);

    /// <summary>Đọc và giải mã chuỗi kết nối đã bảo vệ; trả null nếu chưa có hoặc không giải mã được.</summary>
    public static string? TryReadProtected()
    {
        if (!IsProtected) return null;
        try
        {
            var text = File.ReadAllText(ProtectedFilePath, Encoding.UTF8);
            var payload = Convert.FromBase64String(text);
            var plain = ProtectedData.Unprotect(payload, Entropy, DataProtectionScope.CurrentUser);
            return Encoding.UTF8.GetString(plain);
        }
        catch
        {
            // Không giải mã được (khác tài khoản/máy): quay về App.config thay vì làm ứng dụng dừng.
            return null;
        }
    }

    /// <summary>Mã hóa chuỗi kết nối bằng DPAPI và ghi ra Config/connection.protected.</summary>
    public static string Protect(string connectionString)
    {
        if (string.IsNullOrWhiteSpace(connectionString))
            throw new ArgumentException("Chuỗi kết nối rỗng, không thể bảo vệ.", nameof(connectionString));

        Directory.CreateDirectory(ConfigDirectory);
        var payload = ProtectedData.Protect(
            Encoding.UTF8.GetBytes(connectionString), Entropy, DataProtectionScope.CurrentUser);
        var filePath = ProtectedFilePath;
        File.WriteAllText(filePath, Convert.ToBase64String(payload), new UTF8Encoding(false));
        return filePath;
    }

    /// <summary>Xóa tệp bảo vệ, quay lại đọc chuỗi kết nối từ App.config.</summary>
    public static bool RemoveProtection()
    {
        if (!File.Exists(ProtectedFilePath)) return false;
        File.Delete(ProtectedFilePath);
        return true;
    }

    /// <summary>Ẩn mật khẩu/thông tin nhạy cảm trước khi hiển thị hoặc ghi log.</summary>
    public static string Mask(string? connectionString)
    {
        if (string.IsNullOrWhiteSpace(connectionString)) return "(chưa cấu hình)";
        try
        {
            var builder = new SqlConnectionStringBuilder(connectionString);
            if (!string.IsNullOrEmpty(builder.Password)) builder.Password = "***";
            if (!string.IsNullOrEmpty(builder.UserID)) builder.UserID = builder.UserID;
            return builder.ConnectionString;
        }
        catch
        {
            return "(chuỗi kết nối không hợp lệ hoặc đã được bảo vệ)";
        }
    }

    /// <summary>
    /// Thử áp dụng ProtectedConfiguration của .NET Framework. Trên .NET 10 thường trả về
    /// PlatformNotSupportedException; kết quả được dùng để giải thích trong báo cáo.
    /// </summary>
    public static (bool Supported, string Message) TryProtectAppConfigSection()
    {
        try
        {
            var config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            var section = config.ConnectionStrings;
            if (section.SectionInformation.IsProtected)
            {
                // Gỡ bảo vệ tạm thời để chứng minh thao tác mã hóa thực sự chạy được trên nền tảng này.
                section.SectionInformation.UnprotectSection();
                config.Save(ConfigurationSaveMode.Modified);
            }

            section.SectionInformation.ProtectSection("DataProtectionConfigurationProvider");
            section.SectionInformation.ForceSave = true;
            config.Save(ConfigurationSaveMode.Modified);

            var provider = section.SectionInformation.ProtectionProvider?.Name ?? "DataProtectionConfigurationProvider";
            return (true,
                $"Đã mã hóa section connectionStrings bằng ProtectedConfiguration ({provider}). " +
                "Tệp cấu hình đang được bảo vệ và vẫn đọc được trên tài khoản Windows hiện tại.");
        }
        catch (Exception ex)
        {
            return (false,
                $"ProtectedConfiguration không khả dụng trên nền tảng này ({ex.GetType().Name}). " +
                "Lab 15 dùng DPAPI (Config/connection.protected) làm giải pháp tương đương.");
        }
    }
}
