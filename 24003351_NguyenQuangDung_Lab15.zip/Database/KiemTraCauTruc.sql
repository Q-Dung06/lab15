-- ============================================================================
-- Lab 15 - Kiểm tra cấu trúc và dữ liệu CSDL QLSinhVien
-- Học phần: Lập trình .NET (IT3212)
-- Sinh viên: Nguyễn Quang Dũng - MSSV 24003351
--
-- Script chỉ ĐỌC, không sửa dữ liệu. Chạy trên instance .\SQLEXPRESS.
-- ============================================================================

USE QLSinhVien;
GO

PRINT N'1. Các bảng bắt buộc';
SELECT name AS Bang
FROM sys.tables
WHERE name IN (N'SinhVien', N'Khoa', N'HocPhan', N'DangKy')
ORDER BY name;
GO

PRINT N'2. Cột của bảng SinhVien';
SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH, IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = N'SinhVien'
ORDER BY ORDINAL_POSITION;
GO

PRINT N'3. Khóa chính, unique và khóa ngoại liên quan';
SELECT name AS Ten, type_desc AS Loai
FROM sys.objects
WHERE name IN (N'PK_SinhVien', N'UX_SinhVien_Email', N'FK_DangKy_SinhVien')
ORDER BY name;
GO

PRINT N'4. Số dòng dữ liệu mẫu';
SELECT N'SinhVien' AS Bang, COUNT(*) AS SoDong FROM dbo.SinhVien
UNION ALL SELECT N'Khoa', COUNT(*) FROM dbo.Khoa
UNION ALL SELECT N'HocPhan', COUNT(*) FROM dbo.HocPhan
UNION ALL SELECT N'DangKy', COUNT(*) FROM dbo.DangKy;
GO

PRINT N'5. Sinh viên dùng cho minh họa lỗi nghiệp vụ (SV001)';
SELECT sv.MaSV, sv.HoTen, COUNT(dk.MaHocPhan) AS SoDangKy
FROM dbo.SinhVien sv
LEFT JOIN dbo.DangKy dk ON dk.MaSV = sv.MaSV
WHERE sv.MaSV = N'SV001'
GROUP BY sv.MaSV, sv.HoTen;
GO

PRINT N'6. Dữ liệu kiểm thử tạm còn sót (nếu có)';
SELECT MaSV, HoTen FROM dbo.SinhVien WHERE MaSV LIKE N'ZZT%';
GO
